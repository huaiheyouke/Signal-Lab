"""信号预设库模块。

输入：预设名称与可选参数（频率/码片速率等）。
运算逻辑：numpy 生成标准教学信号波形。
输出对象：{signal, expression_text, note} —— 前端将 signal 载入全局总线，
expression_text 填入基础分析输入框（可直接继续做谐波/频谱分析）。

预设列表：sine 正弦 / square 方波 / triangle 三角波 / lfm 线性调频 / barker13 Barker 码。
"""
from __future__ import annotations

import numpy as np

from ..errors import AnalysisError

# Barker-13 码序列（自相关副瓣 <= 1 的经典扩频序列）
BARKER13 = [1, 1, 1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 1]


def _pack(t, re, im, fs):
    """统一信号输出格式。"""
    t = np.asarray(t, dtype=float)
    re = np.asarray(re, dtype=float)
    im = np.asarray(im, dtype=float)
    return {
        "t": [float(x) for x in t],
        "re": [float(x) for x in re],
        "im": [float(x) for x in im],
        "sampling_rate": float(fs),
        "t_start": float(t[0]) if len(t) else 0.0,
        "t_end": float(t[-1]) if len(t) else 0.0,
        "n_points": int(len(t)),
    }


def generate_preset(name: str, params: dict | None = None) -> dict:
    """生成预设信号。params 可含 f(Hz)、duration(s)、f0/k(LFM)、rc(码片率) 等。"""
    params = params or {}
    name = (name or "").strip().lower()
    f = float(params.get("f", 100.0))

    if name == "sine":
        duration = float(params.get("duration", 0.05))
        fs = max(64.0, 8.0 * f)
        t = np.arange(0.0, duration, 1.0 / fs)
        re = np.cos(2 * np.pi * f * t)
        expr = f"cos(2*pi*{f:g}*t)"
        note = f"正弦波：频率 {f:g} Hz，时长 {duration:g} s。"
        return {"signal": _pack(t, re, np.zeros_like(re), fs), "expression_text": expr, "note": note}

    if name == "square":
        duration = float(params.get("duration", 0.05))
        fs = max(64.0, 16.0 * f)
        t = np.arange(0.0, duration, 1.0 / fs)
        # 过零点规范化：浮点 sin(2πk)≈±2.4e-16 会让 sign() 在周期边界抖动成 ±1，
        # 破坏方波的严格周期性；把 |sin|<1e-12 的点规范化为 +1 保证周期精确。
        s = np.sin(2 * np.pi * f * t)
        s = np.where(np.abs(s) < 1e-12, 1e-12, s)
        re = np.sign(s)
        expr = f"sign(sin(2*pi*{f:g}*t))"
        note = f"方波：基频 {f:g} Hz（含丰富奇次谐波，适合观察谐波分解）。"
        return {"signal": _pack(t, re, np.zeros_like(re), fs), "expression_text": expr, "note": note}

    if name == "triangle":
        duration = float(params.get("duration", 0.05))
        fs = max(64.0, 16.0 * f)
        t = np.arange(0.0, duration, 1.0 / fs)
        # 三角波 = (2/π)·arcsin(sin(2π f t))，与表达式 asin(sin(...)) 严格一致
        re = (2.0 / np.pi) * np.arcsin(np.sin(2 * np.pi * f * t))
        expr = f"(2/pi)*asin(sin(2*pi*{f:g}*t))"
        note = f"三角波：基频 {f:g} Hz（奇次谐波幅度按 1/k² 衰减）。"
        return {"signal": _pack(t, re, np.zeros_like(re), fs), "expression_text": expr, "note": note}

    if name == "lfm":
        f0 = float(params.get("f0", 100.0))
        k = float(params.get("k", 400.0))          # 扫频速率 Hz/s
        duration = float(params.get("duration", 0.05))
        fmax = f0 + k * duration
        fs = max(256.0, 8.0 * fmax)
        t = np.arange(0.0, duration, 1.0 / fs)
        # 线性调频：相位 = 2π(f0·t + k·t²/2)
        re = np.cos(2 * np.pi * (f0 * t + 0.5 * k * t ** 2))
        expr = f"cos(2*pi*({f0:g}*t + {k / 2:g}*t**2))"
        note = f"线性调频 LFM：起始 {f0:g} Hz，扫频速率 {k:g} Hz/s，终点约 {fmax:g} Hz（非周期信号）。"
        return {"signal": _pack(t, re, np.zeros_like(re), fs), "expression_text": expr, "note": note}

    if name == "barker13":
        rc = float(params.get("rc", 100.0))        # 码片速率 chips/s
        spc = int(params.get("samples_per_chip", 32))  # 每码片采样点数
        fs = rc * spc
        n_chips = len(BARKER13)
        t = np.arange(0.0, n_chips / rc, 1.0 / fs)
        re = np.zeros_like(t)
        for i, a in enumerate(BARKER13):
            mask = (t >= i / rc) & (t < (i + 1) / rc)
            re[mask] = a
        expr = "Heaviside(t)-Heaviside(t-13/rc) 组合（Barker-13 码，长度 13 码片）"
        note = f"Barker-13 扩频码：码片速率 {rc:g} chips/s，每码片 {spc} 点，码长 13，时长 {n_chips / rc:g} s。"
        return {"signal": _pack(t, re, np.zeros_like(re), fs), "expression_text": expr, "note": note}

    raise AnalysisError(f"未知预设信号：{name}",
                        ["可选：sine / square / triangle / lfm / barker13"], "unknown_preset")
