// Tab5 Transformer 等效信道面板
// 数学等效仿真：Attention 算子类比为时变信道，H_eq = softmax(Q Kᵀ / √d) 由输入 Q、K 决定。
import { bus, loadSignal, signalFromResponse, signalToPayload } from '../bus.js';
import { chainCall } from '../api.js';

export default {
  data() {
    return {
      d: 8,
      mode: 'from_bus',           // from_bus | manual
      qText: '1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1',
      kText: '1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1',
      vText: '1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1',
      error: null, busy: false,
    };
  },
  methods: {
    parseMatrixText(text) {
      return text.split(';').map(row => row.trim().split(/[ ,\t]+/).filter(s => s !== '').map(Number)).filter(r => r.length);
    },
    async apply() {
      this.error = null;
      this.busy = true;
      try {
        let payload = { d: this.d, from_bus: this.mode === 'from_bus' };
        if (this.mode === 'manual') {
          const d = this.d;
          payload.q = this.parseMatrixText(this.qText);
          payload.k = this.parseMatrixText(this.kText);
          payload.v = this.parseMatrixText(this.vText);
          if (!payload.q.length || payload.q.length !== d || payload.q[0].length !== d) {
            throw { message: 'Q 矩阵必须为 ' + d + '×' + d, suggestions: [] };
          }
        } else {
          if (!bus.signal) throw { message: '总线为空：请先载入信号（需 ≥ d×d 点）。', suggestions: [] };
          payload.signal = signalToPayload(bus.signal);
        }
        const r = await chainCall('/api/chain/transformer', payload);
        bus.moduleResult.transformer = r;
        if (r.signal) {
          await loadSignal(signalFromResponse(r.signal), 'Transformer 等效信道（d=' + this.d + '）');
        }
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="panel">
    <div class="panel-title-row"><h2>⑤ Transformer 等效信道</h2>
      <help-btn title="Transformer 等效信道" text="数学等效仿真：Attention 算子类比为时变信道，等效信道矩阵 H_eq = softmax(Q·Kᵀ/√d) 由输入 Q、K 决定——输入变化，信道随之改变（与传统时不变多径信道对比）。
- 手动模式：填写 d 与 Q/K/V 矩阵（d×d），观察 H_eq 热力图与特征值谱；
- 自注意力模式：从总线信号前 d×d 点构造 Q=K=V（取实部），等效信道输出写回总线并刷新全部视图。"></help-btn>
    </div>
    <div class="info-box">
      <b>数学等效仿真说明：</b>Attention 算子类比为时变信道 —— 等效信道矩阵
      H_eq = softmax(Q·Kᵀ/√d) 由输入 Q、K 决定：输入变化，信道随之改变
      （与传统时不变多径信道形成对比）。
    </div>

    <div class="field-inline"><label>注意力维度 d</label>
      <input v-model.number="d" type="number" min="2" max="256" step="1" />
    </div>
    <div class="switch-row">
      <label class="switch"><input type="radio" value="from_bus" v-model="mode" /> 从总线信号构造 Q=K=V（自注意力）</label>
      <label class="switch"><input type="radio" value="manual" v-model="mode" /> 手动输入 Q、K、V</label>
    </div>

    <div v-if="mode==='manual'" class="field-block">
      <label>Q 矩阵（{{ d }}×{{ d }}）</label>
      <textarea v-model="qText" rows="4" class="mono"></textarea>
      <label>K 矩阵</label>
      <textarea v-model="kText" rows="4" class="mono"></textarea>
      <label>V 矩阵</label>
      <textarea v-model="vText" rows="4" class="mono"></textarea>
    </div>

    <button class="primary" :disabled="busy" @click="apply">{{ busy ? '计算中…' : '▶ 计算等效信道' }}</button>
    <div v-if="error" class="error-box"><div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions.length"><li v-for="(s,i) in error.suggestions" :key="i">{{ s }}</li></ul>
    </div>
  </div>
  `,
};
