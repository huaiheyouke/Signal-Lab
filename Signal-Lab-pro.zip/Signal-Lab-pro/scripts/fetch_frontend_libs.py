"""下载前端离线依赖库（vue / plotly）到 frontend/vendor/。

本仓库已自带这些文件；仅当 vendor 目录缺失或想升级版本时运行。
用法：python scripts/fetch_frontend_libs.py
"""
import pathlib
import urllib.request

VENDOR = pathlib.Path(__file__).resolve().parents[1] / "frontend" / "vendor"
FILES = {
    "vue.global.prod.js": "https://unpkg.com/vue@3.4.38/dist/vue.global.prod.js",
    "plotly.min.js": "https://unpkg.com/plotly.js-dist-min@2.35.2/plotly.min.js",
}


def main() -> None:
    VENDOR.mkdir(parents=True, exist_ok=True)
    for name, url in FILES.items():
        target = VENDOR / name
        print(f"下载 {name} ...")
        urllib.request.urlretrieve(url, str(target))
        size = target.stat().st_size
        assert size > 100_000, f"{name} 下载异常（{size} 字节）"
        print(f"  OK: {target} ({size:,} 字节)")
    print("完成：前端离线依赖已就绪。")


if __name__ == "__main__":
    main()
