"""矩阵算子工作台模块（矩阵可视化与矩阵变换实验）。

输入：
  - matrix：用户手动输入的二维矩阵（嵌套列表）；
  - vector：可选测试向量（3 维用于三维可视化）；
  - signal：可选总线信号（apply_to_bus=True 时执行 H@x）。
运算逻辑（numpy.linalg）：
  - 秩 matrix_rank、条件数 cond、行列式 det（仅方阵）、特征值 eigvals；
  - 3D 可视化：原点 -> v 与原点 -> Mv 两条向量；
  - 作用于总线信号：y = M @ x[:L]（L = 矩阵阶数），写回总线。
输出对象：{matrix_info, visuals: {heatmap, eig_spectrum, vec3d}, signal?, info}。
"""
from __future__ import annotations

import numpy as np

from ..errors import AnalysisError


def _parse_matrix(data) -> np.ndarray:
    try:
        M = np.asarray(data, dtype=float)
    except (TypeError, ValueError) as exc:
        raise AnalysisError("矩阵格式无法解析：需要数值嵌套列表（如 [[1,0],[0,1]]）",
                            ["矩阵工作台支持格式：1 2 3; 4 5 6; 7 8 9（分号分行）"], "bad_matrix") from exc
    if M.ndim != 2:
        raise AnalysisError("矩阵必须是二维的", ["请检查行/列结构是否整齐"], "bad_matrix")
    if M.shape[0] == 0 or M.shape[1] == 0:
        raise AnalysisError("矩阵不能为空", [], "bad_matrix")
    if M.shape[0] > 256 or M.shape[1] > 256:
        raise AnalysisError("矩阵规模过大（超过 256×256）", ["请缩小矩阵规模"], "bad_matrix")
    return M


def analyze_matrix(matrix_data, vector_data=None, signal=None, apply_to_bus: bool = False) -> dict:
    """矩阵分析与可选信号变换。"""
    M = _parse_matrix(matrix_data)
    nrows, ncols = M.shape
    info: dict = {"shape": [int(nrows), int(ncols)]}
    visuals: dict = {}

    # ---- 数值计算（注意 JSON 序列化：inf/NaN 需转换为 null） ----
    info["rank"] = int(np.linalg.matrix_rank(M))
    if nrows == ncols:
        info["is_square"] = True
        try:
            d = float(np.linalg.det(M))
            info["determinant"] = d if np.isfinite(d) else None
        except np.linalg.LinAlgError:
            info["determinant"] = None
        try:
            c = float(np.linalg.cond(M))          # 奇异矩阵条件数 = inf
            info["condition_number"] = c if np.isfinite(c) else None
            info["is_singular"] = (c is None) or (c > 1e15)
        except np.linalg.LinAlgError:
            info["condition_number"] = None
            info["is_singular"] = True
        try:
            ev = np.linalg.eigvals(M)
            info["eigenvalues"] = [float(abs(x)) for x in ev
                                   if np.isfinite(x.real) and np.isfinite(x.imag)]
        except np.linalg.LinAlgError:
            info["eigenvalues"] = []
    else:
        info["is_square"] = False
        info["determinant"] = None
        info["condition_number"] = None
        info["is_singular"] = False
        info["eigenvalues"] = []

    # ---- 可视化数据 ----
    visuals["heatmap"] = [[float(x) for x in row] for row in M]
    if info["eigenvalues"]:
        visuals["eig_spectrum"] = [
            {"index": i + 1, "magnitude": float(m)}
            for i, m in enumerate(sorted(info["eigenvalues"], reverse=True))
        ]
    # 3D 向量变换（仅测试向量为 3 维时可用）
    if vector_data is not None:
        v = np.asarray(vector_data, dtype=float).ravel()
        if v.shape[0] == 3:
            if ncols == 3:
                Mv = M @ v
                visuals["vec3d"] = {
                    "v": [float(x) for x in v],
                    "Mv": [float(x) for x in Mv],
                    "note": "蓝色=原向量 v，橙色=M@v",
                }
            elif ncols != v.shape[0]:
                raise AnalysisError(f"矩阵列数 {ncols} 与测试向量维度 {v.shape[0]} 不匹配",
                                    ["测试向量长度必须等于矩阵列数（三维可视化需 3 列）"], "bad_vector")

    # ---- 作用于总线信号 ----
    out_signal = None
    if apply_to_bus:
        if signal is None:
            raise AnalysisError("总线为空：请先载入信号（运行基础分析或预设）", [], "empty_bus")
        s = np.asarray(signal["re"], dtype=float) + 1j * np.asarray(signal["im"], dtype=float)
        if nrows != ncols:
            raise AnalysisError("矩阵必须为方阵才能作用于信号向量", [], "matrix_not_square")
        L = nrows
        if L > len(s):
            raise AnalysisError(f"矩阵阶数 {L} 大于总线信号点数 {len(s)}",
                                ["请减小矩阵规模"], "matrix_too_large")
        x = s[:L]
        y = M @ x
        out_signal = {
            "t": [float(x) for x in np.asarray(signal["t"], dtype=float)[:L]],
            "re": [float(x) for x in y.real],
            "im": [float(x) for x in y.imag],
            "sampling_rate": float(signal["sampling_rate"]),
            "t_start": 0.0, "t_end": float(np.asarray(signal["t"], dtype=float)[L - 1]), "n_points": int(L),
        }
        info["applied_note"] = f"已执行 y = H @ x（截取总线前 {L} 点），结果写回全局总线。"

    return {"matrix_info": info, "visuals": visuals, "signal": out_signal, "info": info}
