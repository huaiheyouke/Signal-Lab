@echo off
chcp 65001
:: 解释器路径
set PY="E:\anaconda\python.exe"
::主程序py，现在是run.py
set MAIN="%~dp0run.py"
cd /d "%~dp0"
%PY% %MAIN%
::pause