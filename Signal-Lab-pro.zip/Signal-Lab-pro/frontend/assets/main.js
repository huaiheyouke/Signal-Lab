// 应用入口：注册全部组件并挂载（v2：通信链路仿真工作台）
import App from './components/App.js';
import InputPanel from './components/InputPanel.js';
import PlotTabs from './components/PlotTabs.js';
import TimePlot from './components/TimePlot.js';
import SpectrumPlots from './components/SpectrumPlots.js';
import TrajectoryPlot from './components/TrajectoryPlot.js';
import ReportPanel from './components/ReportPanel.js';
// ---- 通信链路工作台 ----
import BusBar from './components/BusBar.js';
import BusMonitor from './components/BusMonitor.js';
import NoiseFilterPanel from './components/NoiseFilterPanel.js';
import ModulationPanel from './components/ModulationPanel.js';
import ChannelPanel from './components/ChannelPanel.js';
import MatrixPanel from './components/MatrixPanel.js';
import TransformerPanel from './components/TransformerPanel.js';
import NoiseViews from './components/NoiseViews.js';
import ModViews from './components/ModViews.js';
import ChannelViews from './components/ChannelViews.js';
import MatrixViews from './components/MatrixViews.js';
import TransformerViews from './components/TransformerViews.js';
import ConstellationPlot from './components/ConstellationPlot.js';
import MatrixVisuals from './components/MatrixVisuals.js';
import FloatCard from './components/FloatCard.js';
import HelpButton from './components/HelpButton.js';

// 离线依赖缺失时的引导提示（正常情况下不会出现）
const missing = [];
if (typeof window.Vue === 'undefined') missing.push('Vue (vue.global.prod.js)');
if (typeof window.Plotly === 'undefined') missing.push('Plotly (plotly.min.js)');

if (missing.length) {
  document.getElementById('app').innerHTML =
    '<div class="fatal">前端离线依赖库缺失：' + missing.join('、') +
    '。<br/>请先运行 <code>python scripts/fetch_frontend_libs.py</code>（需联网一次），' +
    '然后刷新本页面。</div>';
} else {
  const app = Vue.createApp(App);
  app.component('input-panel', InputPanel);
  app.component('plot-tabs', PlotTabs);
  app.component('time-plot', TimePlot);
  app.component('spectrum-plots', SpectrumPlots);
  app.component('trajectory-plot', TrajectoryPlot);
  app.component('report-panel', ReportPanel);
  app.component('bus-bar', BusBar);
  app.component('bus-monitor', BusMonitor);
  app.component('noise-filter-panel', NoiseFilterPanel);
  app.component('modulation-panel', ModulationPanel);
  app.component('channel-panel', ChannelPanel);
  app.component('matrix-panel', MatrixPanel);
  app.component('transformer-panel', TransformerPanel);
  app.component('noise-views', NoiseViews);
  app.component('mod-views', ModViews);
  app.component('channel-views', ChannelViews);
  app.component('matrix-views', MatrixViews);
  app.component('transformer-views', TransformerViews);
  app.component('constellation-plot', ConstellationPlot);
  app.component('matrix-visuals', MatrixVisuals);
  app.component('float-card', FloatCard);
  app.component('help-btn', HelpButton);
  try {
    app.mount('#app');
  } catch (err) {
    // 挂载失败兜底：把错误显示在页面上（配合 index.html 的全局错误条）
    const box = document.createElement('div');
    box.style.cssText = 'position:fixed;left:0;right:0;top:40px;z-index:99998;background:#7f1d1d;color:#fff;' +
      'padding:10px 14px;font:12px/1.6 Consolas,monospace;white-space:pre-wrap;';
    box.textContent = '[SignalLab Pro 启动失败] ' + (err && err.message ? err.message : err);
    document.body.appendChild(box);
  }
}

