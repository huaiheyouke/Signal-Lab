"""周期检测与复数形式傅里叶级数分解（核心算法模块）。

两条路径：
1. symbolic —— 表达式可展开为 Σ c_k·exp(j2π f_k t) 时，符号级精确提取谐波
   （覆盖余弦/正弦/复指数/三角恒等式展开后的任意有限和）；
2. numeric  —— 符号路径失败（方波 sign(sin(..))、整流 abs(sin(..))、
   阶跃 Heaviside、衰减振荡等）时，先用 FFT + 周期性校验检测基频，
   再用每周期 FFT（离散傅里叶级数）数值积分求系数
   c_k = (1/T)∫_0^T s(t)·e^{-j2πk f0 t} dt。

谐波约定（展开式 s(t)=Σ A_k·e^{j(2π f_k t + φ_k)}，统一复数形式）：
- 实信号：输出 k>=0；k>0 时 A_k = 2|c_k|（单边幅度，负频率并入正频率）；
- 复信号：输出 k∈ℤ（双边谱），A_k = |c_k|；
- 两种情形都保留完整复系数 c_k（coeff_re/coeff_im），供扩展模块使用。
"""
from __future__ import annotations

import math
from fractions import Fraction

import numpy as np
import sympy as sp
from scipy import signal as sps

from .signal_parser import VAR

MAX_POINTS = 2_000_000          # 数值检测窗口采样上限
VERIFY_TOL = 0.02               # 周期性校验容差：s(t)≈s(t+T) 的相对误差上限
SPECIAL_FUNCS = (sp.sign, sp.Heaviside, sp.Abs, sp.floor, sp.ceiling,
                 sp.Min, sp.Max, sp.Piecewise, sp.DiracDelta)


# ---------------------------------------------------------------------------
# 频率提取与基频估计
# ---------------------------------------------------------------------------
def _collect_sinusoid_freqs(expr, var):
    """收集表达式中所有 sin/cos/exp(I*w*t) 线性参数的角频率（转 Hz）。"""
    freqs: list[float] = []
    for fn in (sp.sin, sp.cos):
        for atom in expr.atoms(fn):
            try:
                arg = atom.args[0]   # 注意：atoms 返回的是整个 sin/cos 节点，要取其参数
                if arg.diff(var, 2) == 0 and arg.diff(var) != 0:
                    w = sp.simplify(arg.diff(var))
                    freqs.append(abs(float(sp.N(w))) / (2.0 * math.pi))
            except Exception:
                continue
    for e in expr.atoms(sp.exp):
        try:
            a = e.args[0]
            if a.diff(var, 2) == 0 and a.diff(var) != 0:
                w = sp.simplify(a.diff(var))
                if sp.im(w) != 0:
                    freqs.append(abs(float(sp.N(sp.im(w)))) / (2.0 * math.pi))
        except Exception:
            continue
    return freqs


def _frac_gcd(a: Fraction, b: Fraction) -> Fraction:
    """有理数 gcd：gcd(分子)/lcm(分母)。"""
    from math import gcd
    return Fraction(gcd(a.numerator, b.numerator),
                    a.denominator * b.denominator // gcd(a.denominator, b.denominator))


def _gcd_freqs(freqs: list[float], max_den: int = 200, tol: float = 1e-6):
    """频率两两有理可通约时返回有理数 gcd（基频 Hz），否则 None（非周期）。"""
    if not freqs:
        return None
    f_min = min(freqs)
    if f_min <= 0:
        return None
    ratios: list[Fraction] = []
    for f in freqs:
        r = Fraction(f / f_min).limit_denominator(max_den)
        if abs(float(r) - f / f_min) > tol:
            return None                      # 无理数比例 -> 不可通约 -> 非周期
        ratios.append(r)
    g = ratios[0]
    for r in ratios[1:]:
        g = _frac_gcd(g, r)
    f0 = float(g) * f_min
    return f0 if f0 > 0 else None


def estimate_max_frequency(expr):
    """估计信号最高频率（Hz）。无可识别频率成分返回 None。

    特殊函数（方波/整流等）会产生高次谐波，乘以 2 留裕量。
    """
    freqs = _collect_sinusoid_freqs(expr, VAR)
    if not freqs:
        return None
    f = max(freqs)
    if any(expr.has(fn) for fn in SPECIAL_FUNCS):
        f *= 2.0
    return f


def estimate_fundamental(expr):
    """符号级基频估计（Hz），供默认参数推导使用；非周期返回 None。"""
    freqs = _collect_sinusoid_freqs(expr, VAR)
    return _gcd_freqs(freqs) if freqs else None


# ---------------------------------------------------------------------------
# 谐波列表构建（统一约定）
# ---------------------------------------------------------------------------
def _harmonics_from_coeffs(coeffs: dict, f0: float, is_complex: bool, max_harmonics: int):
    """把复系数字典 {k: c_k} 转换为谐波列表，返回 (list, truncated)。"""
    if not coeffs:
        return [], False
    cmax = max(abs(c) for c in coeffs.values()) or 1.0
    items = [(k, c) for k, c in coeffs.items() if abs(c) >= 1e-9 * cmax]

    if is_complex:
        # 复信号：双边（正负 k 都保留），A_k = |c_k|
        items.sort(key=lambda kv: kv[0])
        out = [
            {"k": k, "frequency": float(k * f0), "amplitude": float(abs(c)),
             "phase": float(math.atan2(c.imag, c.real)),
             "coeff_re": float(c.real), "coeff_im": float(c.imag)}
            for k, c in items
        ]
    else:
        # 实信号：单边（负频率并入正频率），k>0 时 A_k = 2|c_k|
        merged: dict[int, complex] = {}
        for k, c in items:
            if k >= 0:
                merged[k] = merged.get(k, 0.0) + c
        out = []
        for k, c in merged.items():
            out.append({"k": k, "frequency": float(k * f0),
                        "amplitude": float(abs(c) * (2 if k != 0 else 1)),
                        "phase": float(math.atan2(c.imag, c.real)),
                        "coeff_re": float(c.real), "coeff_im": float(c.imag)})
        out.sort(key=lambda h: h["k"])

    truncated = False
    if len(out) > max_harmonics:
        truncated = True
        out.sort(key=lambda h: -h["amplitude"])
        out = out[:max_harmonics]
        out.sort(key=lambda h: h["k"])
    return out, truncated


# ---------------------------------------------------------------------------
# 符号路径：改写为复指数并提取系数
# ---------------------------------------------------------------------------
def _extract_harmonics_symbolic(expr, var, f0, max_harmonics):
    """尝试把表达式精确改写为 Σ c_k·exp(j2πk f0 t)。

    返回 (coeffs: dict[k->complex] | None, ok: bool)。
    ok=False 表示表达式含无法改写为纯复指数和的成分
    （方波、阶跃、衰减包络、多项式包络等），需要走数值路径。
    """
    # 注意：只做代数展开，不用 expand_trig（会把 cos(200*pi*t) 递归展开
    # 成 cos(pi*t)**200 的组合爆炸）；sin/cos 的幂与乘积在 rewrite(exp)+expand
    # 后自然变成纯复指数和。
    try:
        e = sp.expand(expr)
        e = e.rewrite(sp.exp)          # sin/cos/sinh/cosh -> 复指数
        e = sp.expand(e)
    except Exception:
        return None, False
    if e.has(sp.sin) or e.has(sp.cos):
        return None, False             # rewrite 未完全消除三角（sign 内部等）

    terms = e.as_ordered_terms() if e.is_Add else [e]
    coeffs: dict[int, complex] = {}
    for term in terms:
        exps = list(term.atoms(sp.exp))
        if not exps:
            # 无指数因子 -> 常数项（直流）
            try:
                c = complex(sp.N(term))
            except Exception:
                return None, False
            if not (math.isfinite(c.real) and math.isfinite(c.imag)):
                return None, False
            coeffs[0] = coeffs.get(0, 0.0) + c
            continue
        base = term
        for ex in exps:
            base = base / ex           # 提出指数因子
        base = sp.simplify(base)
        if base.free_symbols & {var}:
            return None, False         # 包络仍含 t（t*exp(..)、exp(-10t)*exp(..)）
        if base.atoms(sp.exp):
            return None, False         # 嵌套指数
        w_sum = 0.0
        phase_sum = 0.0
        for ex in exps:
            a = ex.args[0]
            if a.diff(var, 2) != 0:
                return None, False     # 指数非 t 的线性函数
            w = sp.simplify(a.diff(var))
            if sp.re(w) != 0 or sp.im(w) == 0:
                return None, False     # 指数含实部（衰减/增长）或为常数
            w_sum += float(sp.N(sp.im(w)))
            alpha = sp.simplify(a - w * var)
            phase_sum += float(sp.N(sp.im(alpha)))
        f_hz = w_sum / (2.0 * math.pi)
        k = int(round(f_hz / f0))
        if abs(f_hz / f0 - k) > 1e-6:
            return None, False
        try:
            c = complex(sp.N(base * sp.exp(sp.I * phase_sum)))
        except Exception:
            return None, False
        if not (math.isfinite(c.real) and math.isfinite(c.imag)):
            return None, False
        coeffs[k] = coeffs.get(k, 0.0) + c
    return coeffs, True


# ---------------------------------------------------------------------------
# 数值路径：周期验证 + 数值傅里叶级数
# ---------------------------------------------------------------------------
def _verify_period_numeric(sampler, candidates, max_harmonics, max_window=None):
    """数值周期检测与验证。

    思路：高密度采样 -> FFT 找显著谱峰（抛物线插值细化 + 子谐波）作为候选基频 ->
    逐一验证 s(t) ≈ s(t+T)（T=1/f）-> 返回验证通过的最大基频
    （真实基频的所有约数都满足周期性，取最大者即为基频）。

    max_window：信号实际时长上限（秒）。数值信号分析（analyze_signal）必须
    传入，防止检测窗口超出信号本身导致插值外推产生伪周期。
    """
    fmax_c = max(candidates) if candidates else 100.0
    fmin_c = min(candidates) if candidates else 10.0
    # 高密度采样：采样率越高，整数采样周期与真实周期的偏差越小
    # （离散"恰好对齐"的拟合才会越接近真值）。总点数封顶 MAX_POINTS。
    fs_hi = max(262144.0, 256.0 * fmax_c)
    window = 8.0 / fmin_c                       # >= 8 个最低候选频率周期
    if max_window:
        window = min(window, max_window)        # 检测窗口不超过信号实际时长
    n_hi = int(window * fs_hi)
    if n_hi > MAX_POINTS:
        fs_hi = fs_hi * MAX_POINTS / n_hi       # 窗口不变，降低采样率保点数上限
        n_hi = MAX_POINTS
    if n_hi < 1024:
        fs_hi = max(fs_hi, 1024.0 / window)
        n_hi = int(window * fs_hi)

    t = np.linspace(0.0, window, n_hi, endpoint=False)
    s = np.asarray(sampler(t), dtype=complex)
    amp_scale = max(float(np.max(np.abs(s))), 1e-12)
    s_ac = s - s.mean()
    X = np.fft.fft(s_ac)
    f = np.fft.fftfreq(n_hi, 1.0 / fs_hi)
    half = n_hi // 2
    mag = np.abs(X[:half])
    ff = f[:half]

    cand_set: set[float] = set()
    if float(np.max(mag)) > 1e-9 * amp_scale * n_hi:
        peaks, _ = sps.find_peaks(mag, prominence=max(0.03 * float(np.max(mag)), 1e-12), distance=3)
        for i in sorted(peaks, key=lambda i: -mag[i])[:12]:
            # 抛物线插值细化：FFT bin 只有 Δf 分辨率（非整数周期窗口时峰值
            # 会偏移到相邻 bin），用对数幅度三点抛物线恢复真实峰频率
            refined = i
            if 0 < i < half - 1:
                y0 = math.log(mag[i - 1] + 1e-300)
                y1 = math.log(mag[i] + 1e-300)
                y2 = math.log(mag[i + 1] + 1e-300)
                denom = y0 - 2.0 * y1 + y2
                if abs(denom) > 1e-15:
                    refined = i + 0.5 * (y0 - y2) / denom
            fp = float(ff[i])
            if fp > 0:
                cand_set.add(fp)
                cand_set.add(refined * (fs_hi / n_hi))   # 细化后的真实峰频率
                for nd in range(2, 7):          # 子谐波候选
                    cand_set.add(fp / nd)
                    cand_set.add(refined * (fs_hi / n_hi) / nd)
    for c0 in candidates or []:
        cand_set.add(c0)
        cand_set.add(c0 / 2.0)

    # ---- 验证 + 连续时间细化（两阶段） ----
    # 非整数周期窗口的 FFT 谱峰（sinc 主瓣）与真实频率可偏差 2% 以上，
    # 因此每个候选先做"粗验证"（容差放宽），再在邻域内连续时间细化
    # （直接调用 sampler 求 s(t) 与 s(t+T)，真周期处误差精确为 0），
    # 最后用细化后的周期做严格复验。
    verified: list[float] = []

    def _cont_err(Tj: float, t1: np.ndarray, seg1: np.ndarray, a_scale: float) -> float:
        if Tj <= 0.0 or Tj + t1[-1] > window:
            return float("inf")
        seg2 = np.asarray(sampler(t1 + Tj), dtype=complex)
        if not np.all(np.isfinite(seg2)):
            return float("inf")
        return float(np.mean(np.abs(seg1 - seg2))) / a_scale

    def _refine_period(cand: float):
        """在候选频率 ±10% 范围内连续细化，返回 (best_freq, best_err)。

        范围依据：非整数周期窗口的 FFT 峰经抛物线细化后仍可偏离真实
        频率 3~5%（方波等强谐波信号更甚），±10% 覆盖留足余量；
        离谱候选在粗验证（mean_err<0.25）阶段已被筛除。
        """
        T0 = 1.0 / cand
        half_span = 0.10 * T0
        m = 2048
        t_hi = T0 + half_span
        t1 = np.linspace(0.0, max(window - t_hi, 1e-12), m)
        seg1 = np.asarray(sampler(t1), dtype=complex)
        if not np.all(np.isfinite(seg1)):
            return None, float("inf")
        a_scale = max(float(np.max(np.abs(seg1))), 1e-12)
        best_T, best_err = T0, _cont_err(T0, t1, seg1, a_scale)
        # 阶段 A：粗网格（half_span 均匀 400 份）
        step_a = max(half_span / 400.0, 1e-10)
        for kk in range(-400, 401):
            Tj = T0 + kk * step_a
            err = _cont_err(Tj, t1, seg1, a_scale)
            if err < best_err:
                best_err, best_T = err, Tj
        # 阶段 B：细网格（1/64 采样间隔）
        step_b = (1.0 / 64.0) / fs_hi
        for kk in range(-96, 97):
            Tj = best_T + kk * step_b
            err = _cont_err(Tj, t1, seg1, a_scale)
            if err < best_err:
                best_err, best_T = err, Tj
        return 1.0 / best_T, best_err

    for cand in sorted(cand_set):
        if cand <= 0:
            continue
        T = 1.0 / cand
        if window < 3.0 * T:
            continue
        k = int(round(T * fs_hi))
        if k <= 0 or k >= n_hi:
            continue
        n_use = n_hi - k
        if n_use < 2 * k:                       # 至少比对 2 个完整周期
            continue
        diff = np.abs(s[:n_use] - s[k:k + n_use])
        if not np.all(np.isfinite(diff)):
            continue
        # 粗验证：仅作为筛选器，容差放宽到 25% —— 非整数周期窗口的 FFT
        # 峰（sinc 主瓣）与真实频率可偏差 2.5% 以上，比对误差随之放大；
        # 真正的质量把关在细化后的严格复验（err < VERIFY_TOL）。
        mean_err = float(np.mean(diff)) / amp_scale
        if mean_err < 0.25:
            f_ref, err_ref = _refine_period(cand)
            if err_ref < VERIFY_TOL:                # 严格复验（细化后）
                verified.append(f_ref)

    if not verified:
        return None
    return max(verified)


def _numeric_fourier_series(sampler, f0, max_harmonics):
    """数值求复数傅里叶系数：c_k = (1/T)∫_0^T s(t)e^{-j2πkf0t}dt。

    用每周期 N_pp 点的 FFT 一次得到全部 k（离散傅里叶级数近似）。
    """
    K = min(max_harmonics, 400)
    N_pp = max(4096, 8 * K)
    T = 1.0 / f0
    t_pp = np.linspace(0.0, T, N_pp, endpoint=False)
    s_pp = np.asarray(sampler(t_pp), dtype=complex)
    C = np.fft.fft(s_pp) / N_pp
    coeffs: dict[int, complex] = {}
    for k in range(0, K + 1):
        coeffs[k] = complex(C[k])
        if k:
            coeffs[-k] = complex(C[N_pp - k])
    return coeffs


# ---------------------------------------------------------------------------
# 对外总入口
# ---------------------------------------------------------------------------
def analyze_periodicity(expr, var, sampler, is_complex, f_max_est, max_harmonics) -> dict:
    """周期检测 + 谐波分解总入口。

    返回 {periodicity, period, fundamental_frequency, harmonics, method, warnings}。
    """
    warnings: list[str] = []

    # 常数信号（注意：不能用 expr.is_constant() —— 对含 exp(I*pi*t) 的
    # 表达式它会触发 sympy 慢速化简；free_symbols 为空即与 t 无关，必为常数）
    if not expr.free_symbols:
        return {"periodicity": "constant", "period": None, "fundamental_frequency": None,
                "harmonics": [], "method": "none", "warnings": warnings}

    freqs = _collect_sinusoid_freqs(expr, var)
    special = any(expr.has(fn) for fn in SPECIAL_FUNCS)
    f0 = _gcd_freqs(freqs) if freqs else None

    def _numeric_result(f0v: float):
        coeffs = _numeric_fourier_series(sampler, f0v, max_harmonics)
        hs, truncated = _harmonics_from_coeffs(coeffs, f0v, is_complex, max_harmonics)
        if truncated:
            warnings.append(f"谐波数量超过上限 {max_harmonics}，已按幅度截断")
        return {"periodicity": "periodic", "period": 1.0 / f0v,
                "fundamental_frequency": f0v, "harmonics": hs,
                "method": "numeric", "warnings": warnings}

    if f0 and not special:
        # ---- 符号路径 ----
        coeffs, ok = _extract_harmonics_symbolic(expr, var, f0, max_harmonics)
        if ok:
            hs, truncated = _harmonics_from_coeffs(coeffs, f0, is_complex, max_harmonics)
            if truncated:
                warnings.append(f"谐波数量超过上限 {max_harmonics}，已按幅度截断")
            return {"periodicity": "periodic", "period": 1.0 / f0,
                    "fundamental_frequency": f0, "harmonics": hs,
                    "method": "symbolic", "warnings": warnings}
        # 符号提取失败（衰减/多项式包络等）-> 数值验证兜底
        f0v = _verify_period_numeric(sampler, freqs, max_harmonics)
        if f0v:
            return _numeric_result(f0v)
        warnings.append("表达式含周期性频率成分，但数值验证未通过（如衰减振荡、扫频等），按非周期处理")
        return {"periodicity": "aperiodic", "period": None, "fundamental_frequency": None,
                "harmonics": [], "method": "none", "warnings": warnings}

    # ---- 数值路径（特殊函数 / 不可通约频率 / 无正弦成分） ----
    f0v = _verify_period_numeric(sampler, freqs or None, max_harmonics)
    if f0v:
        return _numeric_result(f0v)
    return {"periodicity": "aperiodic", "period": None, "fundamental_frequency": None,
            "harmonics": [], "method": "none", "warnings": warnings}
