"""FastAPI 入口：/api/analyze 分析接口 + 前端静态托管（本地单机运行）。"""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import schemas
from .chain import analyze_signal as chain_analyze
from .chain import compare as chain_compare_mod
from .chain import matrix_ops as chain_matrix_ops
from .chain import modulation as chain_modulation
from .chain import multipath as chain_multipath
from .chain import noise_filter as chain_noise_filter
from .chain import presets as chain_presets
from .chain import transformer_eq as chain_transformer_eq
from .errors import AnalysisError
from .pipeline import analyze, run_with_timeout
from .schemas import AnalyzeRequest, AnalyzeResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("signallab")

FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"

app = FastAPI(
    title="通信信号分析可视化教学工具 SignalLab Pro",
    version="1.0.0",
    description=(
        "输入时域信号表达式，自动完成信号解析 / 谐波分解 / 示波器指标 / "
        "频谱分析；前端由 Plotly.js 在浏览器本地渲染 2D/3D 交互图。"
    ),
)

# 允许本地跨域（前端单独调试时使用；同源部署时无影响）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "signallab", "version": "1.0.0"}


@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze_endpoint(req: AnalyzeRequest):
    """核心分析接口：POST 表达式与参数 -> 完整分析 JSON。"""
    try:
        return run_with_timeout(45.0, analyze, req)
    except AnalysisError as exc:
        # 结构化错误：{code, error, suggestions}，前端直接展示
        raise HTTPException(status_code=422, detail=exc.to_dict()) from exc
    except Exception as exc:  # 兜底：未预期异常
        logger.exception("分析失败")
        raise HTTPException(
            status_code=500,
            detail={
                "code": "internal_error",
                "error": "服务器内部错误，请查看后端控制台日志",
                "suggestions": ["简化表达式后重试"],
            },
        ) from exc





# ===========================================================================
# 通信链路仿真（chain）端点：全局总线信号处理模块
# ===========================================================================
def _chain_guard():
    """chain 端点统一错误转换（422 + 中文提示）。"""


def _run_chain(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except AnalysisError as exc:
        raise HTTPException(status_code=422, detail=exc.to_dict()) from exc
    except Exception as exc:
        logger.exception("链路模块执行失败")
        raise HTTPException(
            status_code=500,
            detail={"code": "internal_error", "error": "链路模块内部错误，请查看控制台日志",
                    "suggestions": ["检查输入参数后重试"]},
        ) from exc


@app.post("/api/chain/analyze_signal", response_model=AnalyzeResponse)
def chain_analyze_signal(req: schemas.ChainAnalyzeRequest):
    """数值信号全分析：总线信号 -> 谐波/指标/频谱（驱动全部原有视图刷新）。"""
    return _run_chain(chain_analyze.analyze_numeric_signal,
                      req.signal.model_dump(), req.max_harmonics)


@app.post("/api/chain/preset")
def chain_preset(req: schemas.ChainPresetRequest):
    """信号预设库：生成标准教学信号载入总线。"""
    return _run_chain(chain_presets.generate_preset, req.name, req.params)


@app.post("/api/chain/noise")
def chain_noise(req: schemas.ChainNoiseRequest):
    """预处理：加性高斯白噪声。"""
    return _run_chain(chain_noise_filter.add_awgn, req.signal.model_dump(), req.snr_db)


@app.post("/api/chain/filter")
def chain_filter(req: schemas.ChainFilterRequest):
    """预处理：数字滤波（FIR/IIR，低通/高通/带通/带阻）。"""
    return _run_chain(chain_noise_filter.apply_filter, req.signal.model_dump(),
                      req.filter_type, req.kind, req.order, req.cutoff1, req.cutoff2)


@app.post("/api/chain/modulate")
def chain_modulate(req: schemas.ChainModulateRequest):
    """数字调制：生成复基带 I/Q 信号 + 理想星座点。"""
    return _run_chain(chain_modulation.generate_signal,
                      req.modulation, req.symbol_rate, req.samples_per_symbol,
                      req.freq_offset, req.phase_offset, req.num_symbols,
                      req.rolloff, req.seed)


@app.post("/api/chain/channel")
def chain_channel(req: schemas.ChainChannelRequest):
    """传统多径信道（瑞利/莱斯）：输出畸变信号 + CIR + H 矩阵。"""
    taps = [tp.model_dump() for tp in req.taps]
    return _run_chain(chain_multipath.apply_channel, req.signal.model_dump(), taps, req.k_factor)


@app.post("/api/chain/matrix")
def chain_matrix(req: schemas.ChainMatrixRequest):
    """矩阵算子工作台：秩/条件数/行列式/特征值 + 向量变换 + 可选作用于总线。"""
    sig = req.signal.model_dump() if req.signal else None
    return _run_chain(chain_matrix_ops.analyze_matrix, req.matrix, req.vector,
                      sig, req.apply_to_bus)


@app.post("/api/chain/transformer")
def chain_transformer(req: schemas.ChainTransformerRequest):
    """Transformer 等效信道：H_eq = softmax(QKᵀ/√d)。"""
    sig = req.signal.model_dump() if req.signal else None
    return _run_chain(chain_transformer_eq.run_transformer, req.d,
                      req.q, req.k, req.v, sig, req.from_bus)


@app.post("/api/chain/compare")
def chain_compare(req: schemas.ChainCompareRequest):
    """A/B 快照对比：MSE / SNR / 相关系数。"""
    return _run_chain(chain_compare_mod.compare_signals,
                      req.a.model_dump(), req.b.model_dump())



# ---- 前端静态托管（无需单独启动前端服务） ----
# 注意：静态资源统一加 Cache-Control: no-store —— 彻底禁用浏览器缓存，
# 每次访问都从磁盘加载最新前端代码，根除"升级后看不到新界面"的缓存问题。
_NO_CACHE = {"Cache-Control": "no-store"}


class NoCacheStaticFiles(StaticFiles):
    """带 no-cache 响应头的静态文件服务（Starlette 1.6 的 StaticFiles 不支持
    headers 参数，故子类化覆盖 file_response 统一注入）。"""

    def file_response(self, *args, **kwargs):
        resp = super().file_response(*args, **kwargs)
        resp.headers["Cache-Control"] = "no-store"
        return resp


if (FRONTEND_DIR / "vendor").is_dir():
    app.mount("/vendor", NoCacheStaticFiles(directory=FRONTEND_DIR / "vendor"), name="vendor")
if (FRONTEND_DIR / "assets").is_dir():
    app.mount("/assets", NoCacheStaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONTEND_DIR / "index.html", headers=_NO_CACHE)
