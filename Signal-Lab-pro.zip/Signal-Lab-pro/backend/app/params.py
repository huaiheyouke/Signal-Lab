"""默认参数推导与参数校验。

需求规则：
- 用户不填参数时自动推导：
  采样率 >= 8 × 信号最高频率；时间窗口覆盖 3~5 个信号周期；
- 用户显式填写的参数必须满足奈奎斯特条件（fs >= 2×最高频率），否则报错；
  fs 低于建议值 8×最高频率时给出警告；
- 采样点数设保护上限，防止一次性请求过大。
"""
from __future__ import annotations

import math

from .errors import AnalysisError

# 无任何可识别频率成分时的兜底默认值（如纯多项式 t**2）
DEFAULT_FS = 1000.0
DEFAULT_WINDOW = (0.0, 1.0)

# 保护性上限：单次分析最大采样点数（防止内存/绘图爆炸）
MAX_POINTS = 2_000_000


def _nice_ceil(x: float) -> float:
    """向上取整到 1/2/2.5/5/8×10^n 这类"好看"的数。"""
    if x <= 0:
        return 1.0
    exp = math.floor(math.log10(x))
    base = 10.0 ** exp
    m = x / base
    for cand in (1, 2, 2.5, 5, 8, 10):
        if m <= cand:
            return cand * base
    return 10.0 * base


def derive_parameters(f_max_est, f0_est, t_start, t_end, fs):
    """推导并校验采样参数。

    参数：
        f_max_est: 信号最高频率估计（Hz），无可识别频率时为 None
        f0_est:    周期信号基频估计（Hz），未知时为 None
        t_start/t_end/fs: 用户显式给出的参数，None 表示缺省
    返回：
        {t_start, t_end, sampling_rate, n_points, warnings}
    """
    warnings: list[str] = []

    # ---------- 时间窗口 ----------
    if t_start is None or t_end is None:
        if f0_est:
            period = 1.0 / f0_est
            t_start, t_end = 0.0, 4.0 * period          # 覆盖 4 个周期（需求 3~5 周期）
        elif f_max_est:
            t_start, t_end = 0.0, 8.0 / f_max_est       # 非周期：覆盖 8 个载频周期
        else:
            t_start, t_end = DEFAULT_WINDOW
    if t_end <= t_start:
        raise AnalysisError(
            "时间窗口无效：t_end 必须大于 t_start",
            ["请检查 t_start / t_end 的取值"],
            "bad_window",
        )

    # ---------- 采样率 ----------
    if fs is None:
        if f_max_est:
            fs = max(64.0, _nice_ceil(8.0 * f_max_est))  # 需求：>= 8 × 最高频率
        else:
            fs = DEFAULT_FS
    if not math.isfinite(fs) or fs <= 0:
        raise AnalysisError("采样率必须为正数", ["请检查 sampling_rate 取值"], "bad_sampling_rate")

    # 奈奎斯特硬校验 + 建议值软警告
    if f_max_est and fs < 2.0 * f_max_est:
        raise AnalysisError(
            f"采样率过低：信号最高频率约 {f_max_est:g} Hz，"
            f"按奈奎斯特条件采样率必须 >= {2.0 * f_max_est:g} Hz（当前 {fs:g} Hz），否则频谱混叠",
            [f"建议采样率 >= {8.0 * f_max_est:g} Hz（本工具自动推导即采用该规则）"],
            "low_sampling_rate",
        )
    if f_max_est and fs < 8.0 * f_max_est:
        warnings.append(
            f"采样率（{fs:g} Hz）低于建议值 8×最高频率（{8.0 * f_max_est:g} Hz），"
            "高频谐波分量可能被截断"
        )

    # ---------- 点数保护 ----------
    dur = t_end - t_start
    n = int(round(dur * fs)) + 1  # 含端点，t_i = t_start + i/fs
    if n > MAX_POINTS:
        raise AnalysisError(
            f"采样点数过多（{n} > {MAX_POINTS:,}）：单次分析数据量过大",
            ["请减小时间窗口（t_end - t_start）或降低采样率"],
            "too_many_points",
        )
    if n < 4:
        raise AnalysisError("采样点数过少（< 4）", ["请增大时间窗口或提高采样率"], "too_few_points")

    return {
        "t_start": float(t_start),
        "t_end": float(t_end),
        "sampling_rate": float(fs),
        "n_points": n,
        "warnings": warnings,
    }
