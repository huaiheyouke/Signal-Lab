// 后端 API 封装：基础分析 + 通信链路模块的统一数据通道

async function postJSON(path, payload) {
  const resp = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    let detail = { error: '请求失败 (HTTP ' + resp.status + ')', suggestions: [] };
    try {
      const j = await resp.json();
      if (j && j.detail) {
        detail = typeof j.detail === 'string' ? { error: j.detail, suggestions: [] } : j.detail;
      }
    } catch (e) { /* 非 JSON 响应，保留默认信息 */ }
    const err = new Error(detail.error || '未知错误');
    err.suggestions = detail.suggestions || [];
    err.code = detail.code || '';
    throw err;
  }
  return await resp.json();
}

// 基础信号分析（表达式 + 参数）
export function runAnalysis(payload) {
  return postJSON('/api/analyze', payload);
}

// 通信链路模块（噪声/滤波/调制/信道/矩阵/Transformer/预设/数值分析/对比）
export function chainCall(path, payload) {
  return postJSON(path, payload);
}

