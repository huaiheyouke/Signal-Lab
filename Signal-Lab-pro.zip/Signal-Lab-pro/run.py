"""一键启动脚本（本地单机运行，无需联网）。

用法：
    python run.py                 # 启动并自动打开浏览器
    python run.py --port 9000     # 指定端口
    python run.py --no-browser    # 不自动打开浏览器
"""
import argparse
import socket
import sys
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))  # 保证 backend 包可从项目根目录导入

VENDOR_DIR = ROOT / "frontend" / "vendor"


def _check_vendor_files() -> None:
    """前端离线依赖检查（vue / plotly 已随仓库提供，缺省时给出引导）。"""
    missing = [f for f in ("vue.global.prod.js", "plotly.min.js") if not (VENDOR_DIR / f).is_file()]
    if missing:
        print("[警告] 前端离线依赖缺失: " + ", ".join(missing))
        print("       请先运行一次: python scripts/fetch_frontend_libs.py（需要联网一次）")
        print("       缺失时页面会给出引导提示，后端 API 不受影响。")


def _ensure_deps() -> None:
    """依赖检查：优先系统 fastapi；不可用时自动使用仓库内 .pylibs（免 pip 安装）。"""
    try:
        import fastapi  # noqa: F401
        return
    except ImportError as exc:
        detail = f"（{exc}）"
    libs = ROOT / ".pylibs"
    if libs.is_dir():
        sys.path.insert(0, str(libs))
        print(f"[信息] 系统未安装可用的 fastapi{detail}，已启用仓库内置依赖 .pylibs（纯 Python 包）")
        try:
            import fastapi  # noqa: F401
            return
        except ImportError as exc2:
            print(f"[错误] 内置依赖也无法导入：{exc2}")
            print("       请尝试执行: pip install -r requirements.txt 后重试")
            sys.exit(1)
    else:
        print("[错误] 未找到 fastapi。请先执行: pip install -r requirements.txt")
        sys.exit(1)


def _port_in_use(host: str, port: int) -> bool:
    """检查端口是否已被占用（防止重复启动导致绑定失败）。"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        try:
            s.bind((host, port))
            return False
        except OSError:
            return True


def main() -> None:
    parser = argparse.ArgumentParser(description="通信信号分析可视化教学工具（本地单机版）")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    parser.add_argument("--port", type=int, default=8000, help="监听端口（默认 8000）")
    parser.add_argument("--no-browser", action="store_true", help="启动后不自动打开浏览器")
    args = parser.parse_args()

    _check_vendor_files()
    _ensure_deps()
    url = f"http://{args.host}:{args.port}"

    # 端口占用检查：重复启动时给出明确提示而不是报绑定错误
    if _port_in_use(args.host, args.port):
        print(f"[提示] 端口 {args.port} 已被占用——SignalLab Pro 可能已经在运行。")
        print(f"       请直接访问 {url}；")
        print("       若无法访问，请先关闭其他 SignalLab Pro 窗口/进程后重新启动。")
        print("       按回车键退出...")
        input()
        sys.exit(1)
    print("=" * 60)
    print("  通信信号分析可视化教学工具  SignalLab Pro")
    print(f"  访问地址: {url}")
    print("  按 Ctrl+C 停止服务")
    print("=" * 60)

    if not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    try:
        import uvicorn
        uvicorn.run("backend.app.main:app", host=args.host, port=args.port, reload=False)
    except Exception as exc:  # 启动失败时给出清晰诊断，而不是静默退出
        print(f"[错误] 服务启动失败：{exc}")
        print("       可尝试：1) 检查端口是否被占用；2) pip install -r requirements.txt 重装依赖")
        input("按回车键退出...")
        sys.exit(1)


if __name__ == "__main__":
    main()
