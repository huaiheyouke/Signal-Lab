// 顶部总线状态条：当前信号信息 + A/B 快照 + 导出（CSV/报告）
import { bus, refreshAnalysis } from '../bus.js';
import { chainCall } from '../api.js';
import { busToCSV, reportToMarkdown, downloadText } from '../export.js';

export default {
  data() { return { bus, compareResult: null, showCompare: false }; },  // bus 挂到实例供模板使用
  computed: {
    info() {
      const s = bus.signal;
      if (!s) return null;
      return {
        label: bus.sourceLabel,
        n: s.t.length,
        fs: s.sampling_rate,
        type: bus.analysis ? (bus.analysis.signal_type === 'complex' ? '复信号' : '实信号') : '',
      };
    },
  },
  methods: {
    hasSignal() { return !!bus.signal; },
    fmtHz(x) {
      if (x >= 1e6) return (x / 1e6).toFixed(2) + ' MHz';
      if (x >= 1e3) return (x / 1e3).toFixed(2) + ' kHz';
      return x.toFixed(1) + ' Hz';
    },
    saveSnapshot(k) {
      if (!bus.signal) return;
      const snap = { signal: JSON.parse(JSON.stringify(bus.signal)), label: bus.sourceLabel };
      if (k === 'A') bus.snapshotA = snap; else bus.snapshotB = snap;
    },
    loadSnapshot(k) {
      const snap = k === 'A' ? bus.snapshotA : bus.snapshotB;
      if (!snap) return;
      bus.signal = JSON.parse(JSON.stringify(snap.signal));
      bus.sourceLabel = '快照' + k + '：' + snap.label;
      refreshAnalysis();
    },
    async compareAB() {
      if (!bus.snapshotA || !bus.snapshotB) { alert('请先分别保存快照 A 与 B'); return; }
      try {
        const r = await chainCall('/api/chain/compare', {
          a: { t: bus.snapshotA.signal.t, re: bus.snapshotA.signal.real, im: bus.snapshotA.signal.imag, sampling_rate: bus.snapshotA.signal.sampling_rate },
          b: { t: bus.snapshotB.signal.t, re: bus.snapshotB.signal.real, im: bus.snapshotB.signal.imag, sampling_rate: bus.snapshotB.signal.sampling_rate },
        });
        this.compareResult = r;
        this.showCompare = true;
      } catch (err) { alert('对比失败：' + err.message); }
    },
    exportCSV() {
      if (!bus.signal) return;
      downloadText('signallab_bus_' + Date.now() + '.csv', busToCSV(bus.signal), 'text/csv;charset=utf-8');
    },
    exportMD() {
      if (!bus.analysis) return;
      downloadText('signallab_report_' + Date.now() + '.md', reportToMarkdown(bus.analysis), 'text/markdown;charset=utf-8');
    },
  },
  template: `
  <div class="bus-bar">
    <div class="bus-info" v-if="info" :title="info.label">
      <span class="bus-dot"></span>
      <span class="bus-src">{{ info.label }}</span>
      <span class="bus-meta">{{ info.type }} · N={{ info.n }} · fs={{ fmtHz(info.fs) }}</span>
    </div>
    <div class="bus-info empty" v-else>总线为空：先运行基础分析或载入预设</div>
    <div class="bus-actions">
      <button class="tb" title="保存当前总线信号到快照 A" @click="saveSnapshot('A')">快照 A</button>
      <button class="tb" title="保存当前总线信号到快照 B" @click="saveSnapshot('B')">快照 B</button>
      <button class="tb" title="载入快照 A" @click="loadSnapshot('A')">载入 A</button>
      <button class="tb" title="载入快照 B" @click="loadSnapshot('B')">载入 B</button>
      <button class="tb" title="对比 A/B：MSE / SNR / 相关系数" @click="compareAB">A/B 对比</button>
      <button class="tb" title="导出总线信号为 CSV" :disabled="!hasSignal()" @click="exportCSV">导出 CSV</button>
      <button class="tb" title="导出分析报告为 Markdown" :disabled="!bus.analysis" @click="exportMD">导出报告</button>
    </div>
    <div v-if="showCompare" class="cmp-overlay" @click="showCompare=false"></div>
    <div v-if="showCompare && compareResult" class="compare-pop">
      <div class="compare-head">A/B 对比结果
        <button class="cmp-close" @click="showCompare=false">✕ 关闭</button>
      </div>
      <table>
        <tr><td>MSE（均方误差）</td><td>{{ compareResult.mse === null ? '—' : compareResult.mse.toExponential(3) }}</td></tr>
        <tr><td>SNR (dB)</td><td>{{ compareResult.snr_db === null ? '—' : (compareResult.snr_db === Infinity ? '∞（完全相同）' : compareResult.snr_db.toFixed(2)) }}</td></tr>
        <tr><td>相关系数</td><td>{{ compareResult.correlation === null ? '—' : compareResult.correlation.toFixed(4) }}</td></tr>
        <tr><td>比对长度</td><td>{{ compareResult.n_compared }} 点</td></tr>
      </table>
      <div class="compare-note">{{ compareResult.note }}</div>
    </div>
  </div>
  `,
};
