// 通用工具：数组降采样与数值格式化

// 把长数组按固定步长降采样到 <= maxPoints 个点（绘图性能保护）
export function stride(arr, maxPoints) {
  const n = arr.length;
  const s = Math.max(1, Math.ceil(n / maxPoints));
  const out = new Array(Math.ceil(n / s));
  for (let i = 0, j = 0; i < n; i += s, j++) out[j] = arr[i];
  return out;
}

// 通用数值格式化（科学计数法 / 定点自适应）
export function fmt(x) {
  if (x === null || x === undefined || typeof x !== 'number' || !isFinite(x)) return '—';
  const a = Math.abs(x);
  if (a !== 0 && (a >= 1e5 || a < 1e-4)) return x.toExponential(4);
  return String(parseFloat(x.toPrecision(6)));
}

// 频率友好格式化（k/M 后缀）
export function fmtHz(x) {
  if (x === null || x === undefined || !isFinite(x)) return '—';
  if (x >= 1e6) return (x / 1e6).toFixed(3) + 'M';
  if (x >= 1e3) return (x / 1e3).toFixed(3) + 'k';
  return fmt(x);
}

// 谐波叠加曲线用配色（区分原始信号）
export const PALETTE = [
  '#e11d48', '#f59e0b', '#10b981', '#8b5cf6', '#06b6d4', '#f97316',
  '#84cc16', '#ec4899', '#14b8a6', '#6366f1', '#d946ef', '#a3e635',
];

export const PLOTLY_CONFIG = { displaylogo: false, responsive: true, scrollZoom: true };
