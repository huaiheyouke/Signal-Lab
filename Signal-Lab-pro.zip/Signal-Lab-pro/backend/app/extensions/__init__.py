"""扩展包。

默认不启用任何扩展。启用方式示例（取消注释并 import）：
    from .channel_model import AWGNChannelExtension
    register_extension(AWGNChannelExtension())

后续扩展规划（代码骨架见同目录文件）：
    channel_model.py        —— 信道建模（AWGN / 多径）
    transformer_channel.py  —— Transformer 等效信道
    constellation.py        —— 星座图（可直接复用谐波的复系数 c_k）
"""
from .base import AnalysisExtension, get_registry, register_extension

__all__ = ["AnalysisExtension", "get_registry", "register_extension"]
