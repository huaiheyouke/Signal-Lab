// ============================================================
// 全局信号总线（通信链路仿真工作台的核心）
// ------------------------------------------------------------
// 总线存放"当前正在被分析的信号对象"：
//   signal  = {t, real, imag, sampling_rate, t_start, t_end, n_points}
//   analysis= 该信号的完整分析结果（谐波/指标/频谱，与 /api/analyze 同构）
// 任何模块处理完成 -> 写回总线 -> 全部视图自动刷新（时域/频谱/3D/星座/报告）。
// ============================================================

export const bus = Vue.reactive({
  signal: null,         // 当前总线信号（复数采样序列）
  analysis: null,       // 总线信号的完整分析响应（驱动全部原有视图）
  sourceLabel: '（空）', // 信号来源说明（如"基础分析 cos(..)"、"QPSK 调制"）
  busy: false,          // 分析中标志
  error: null,          // 最近一次链路操作错误
  snapshotA: null,      // A/B 快照（{signal, label}）
  snapshotB: null,
  moduleResult: Vue.reactive({   // 各链路模块最近一次运行结果（面板写、视图读）
    noise: null, filter: null, mod: null, channel: null, matrix: null, transformer: null,
  }),
  sharedH: null,        // 多径信道导出的 H 矩阵（供矩阵工作台导入）
});

// 总线格式 -> 链路 API 传输格式（re/im 短名）
export function signalToPayload(sig) {
  return { t: sig.t, re: sig.real, im: sig.imag, sampling_rate: sig.sampling_rate };
}

// 链路 API 响应格式 -> 总线格式
export function signalFromResponse(s) {
  return {
    t: s.t, real: s.re, imag: s.im,
    sampling_rate: s.sampling_rate,
    t_start: s.t_start, t_end: s.t_end, n_points: s.n_points,
  };
}

// 把新信号写入总线并触发全量分析（驱动所有视图刷新）
export async function loadSignal(signal, label) {
  bus.signal = signal;
  bus.sourceLabel = label;
  bus.error = null;
  await refreshAnalysis();
}

// 对当前总线信号做数值全分析（周期/谐波/指标/频谱），结果存入 bus.analysis
export async function refreshAnalysis() {
  if (!bus.signal) return;
  bus.busy = true;
  try {
    const { chainCall } = await import('./api.js');
    const resp = await chainCall('/api/chain/analyze_signal', {
      signal: signalToPayload(bus.signal),
      max_harmonics: 200,
    });
    bus.analysis = resp;
  } catch (err) {
    bus.error = { message: err.message, suggestions: err.suggestions || [] };
  } finally {
    bus.busy = false;
  }
}
