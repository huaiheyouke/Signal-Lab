// 根组件（v2：通信链路仿真工作台）
// 布局：顶部全局 Tab 导航 + 总线状态条；中部左参数/右视图（可拖拽分隔条）；底部报告（可拖拽分隔条）。
// 全局状态：bus（见 ../bus.js）——任何模块处理完写回总线，全部视图自动刷新。
import { bus, refreshAnalysis } from '../bus.js';
import { chainCall, runAnalysis } from '../api.js';

export default {
  data() {
    return {
      bus,                     // ★ 模板作用域需要：Vue3 选项式组件模板不能直接访问
                               //   模块级 import 变量，必须挂到实例上（否则渲染崩溃）
      tab: 'analyze',          // analyze | noise | mod | channel | matrix | transformer
      leftWidth: 390,          // 左面板宽度（px，可拖拽）
      reportHeight: 300,       // 报告区高度（px，可拖拽）
      dragging: null,          // 拖拽状态 {kind, startX, startY, startLeft, startReport}
      presetExpr: '',           // 预设载入后回填到输入框的表达式
      presetNote: '',           // 预设说明
    };
  },
  computed: {
    leftStyle() { return { 'grid-template-columns': this.leftWidth + 'px 6px 1fr' }; },
    // ★ 布局关键：报告区高度必须驱动 grid 行高（之前只改 .report 的 height，
    //   grid 行高固定导致拖拽分隔条不生效）
    layoutStyle() { return { 'grid-template-rows': '48px 1fr 8px ' + this.reportHeight + 'px' }; },
  },
  methods: {
    // 基础分析：表达式 -> 后端 /api/analyze -> 结果写入全局总线（信号+全分析）
    onAnalyze(payload) {
      bus.busy = true;
      bus.error = null;
      runAnalysis(payload)
        .then(r => {
          bus.analysis = r;
          bus.signal = {
            t: r.time.t, real: r.time.real, imag: r.time.imag,
            sampling_rate: r.time.sampling_rate,
            t_start: r.time.t_start, t_end: r.time.t_end, n_points: r.time.n_points,
          };
          bus.sourceLabel = '基础分析：' + (payload.expression || '').slice(0, 60);
        })
        .catch(err => {
          bus.error = { message: err.message, suggestions: err.suggestions || [] };
        })
        .finally(() => { bus.busy = false; });
    },
    // 信号预设库：后端生成标准波形 -> 载入全局总线 -> 数值全分析刷新视图
    async onPreset(name) {
      bus.busy = true;
      bus.error = null;
      try {
        const r = await chainCall('/api/chain/preset', { name, params: {} });
        const s = r.signal;
        bus.signal = {
          t: s.t, real: s.re, imag: s.im,
          sampling_rate: s.sampling_rate,
          t_start: s.t_start, t_end: s.t_end, n_points: s.n_points,
        };
        bus.sourceLabel = '预设库：' + (name === 'barker13' ? 'Barker-13 扩频码' : name);
        this.presetExpr = r.expression_text || '';
        this.presetNote = r.note || '';
        await refreshAnalysis();          // 数值全分析（谐波/指标/频谱）驱动全部视图
      } catch (err) {
        bus.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        bus.busy = false;
      }
    },
    // ---- 可拖拽分隔条（Windows 风格窗口自定义大小） ----
    startResize(kind, e) {
      this.dragging = {
        kind,
        startX: e.clientX, startY: e.clientY,
        startLeft: this.leftWidth, startReport: this.reportHeight,
      };
      window.addEventListener('mousemove', this.onResize);
      window.addEventListener('mouseup', this.stopResize);
      document.body.style.cursor = kind === 'left' ? 'col-resize' : 'row-resize';
      document.body.style.userSelect = 'none';
    },
    onResize(e) {
      if (!this.dragging) return;
      if (this.dragging.kind === 'left') {
        this.leftWidth = Math.min(760, Math.max(280, this.dragging.startLeft + (e.clientX - this.dragging.startX)));
      } else {
        // 报告区：向上拖增大（从窗口底部向上算）
        this.reportHeight = Math.min(720, Math.max(140, this.dragging.startReport + (this.dragging.startY - e.clientY)));
      }
    },
    stopResize() {
      this.dragging = null;
      window.removeEventListener('mousemove', this.onResize);
      window.removeEventListener('mouseup', this.stopResize);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    },
  },
  template: `
  <div class="layout" :style="layoutStyle">
    <header class="topbar">
      <div class="brand">SignalLab Pro <span>通信链路仿真工作台</span></div>
      <nav class="main-tabs">
        <button :class="{active: tab==='analyze'}" @click="tab='analyze'">基础信号分析</button>
        <button :class="{active: tab==='noise'}" @click="tab='noise'">预处理：噪声与滤波</button>
        <button :class="{active: tab==='mod'}" @click="tab='mod'">数字调制与星座图</button>
        <button :class="{active: tab==='channel'}" @click="tab='channel'">传统多径信道</button>
        <button :class="{active: tab==='matrix'}" @click="tab='matrix'">矩阵算子工作台</button>
        <button :class="{active: tab==='transformer'}" @click="tab='transformer'">Transformer等效信道</button>
      </nav>
      <bus-bar></bus-bar>
    </header>

    <div class="body" :style="leftStyle">
      <aside class="left">
        <input-panel v-if="tab==='analyze'" :preset-expr="presetExpr" :preset-note="presetNote"
          @analyze="onAnalyze" @preset="onPreset"></input-panel>
        <noise-filter-panel v-else-if="tab==='noise'"></noise-filter-panel>
        <modulation-panel v-else-if="tab==='mod'"></modulation-panel>
        <channel-panel v-else-if="tab==='channel'"></channel-panel>
        <matrix-panel v-else-if="tab==='matrix'"></matrix-panel>
        <transformer-panel v-else-if="tab==='transformer'"></transformer-panel>
      </aside>
      <div class="vsplit" title="↔ 拖拽调整左面板宽度" @mousedown="startResize('left', $event)"></div>
      <main class="main">
        <plot-tabs v-if="tab==='analyze'" :result="bus.analysis" :busy="bus.busy"></plot-tabs>
        <noise-views v-else-if="tab==='noise'"></noise-views>
        <mod-views v-else-if="tab==='mod'"></mod-views>
        <channel-views v-else-if="tab==='channel'"></channel-views>
        <matrix-views v-else-if="tab==='matrix'"></matrix-views>
        <transformer-views v-else-if="tab==='transformer'"></transformer-views>
      </main>
    </div>

    <div class="hsplit" title="↕ 拖拽调整报告区高度" @mousedown="startResize('report', $event)"></div>
    <section class="report" :style="reportStyle">
      <report-panel :result="bus.analysis" :error="bus.error" :busy="bus.busy"></report-panel>
    </section>
  </div>
  `,
};

