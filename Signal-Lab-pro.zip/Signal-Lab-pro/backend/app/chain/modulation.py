"""数字调制模块：生成数字调制复基带信号（I/Q）。

输入：调制方式 / 符号速率 / 每符号采样点数 / 载波频偏 / 相位偏移 / 符号数 / 滚降系数。
运算逻辑：
  1. 随机比特 -> Gray 星座映射（平均功率归一化到 1）；
  2. 零阶保持上采样（每符号 samples_per_symbol 点）；
  3. 根升余弦（RRC）成型滤波（rolloff>0 时）；
  4. 叠加载波频偏 e^{j2πΔf·t} 与相位偏移 e^{jφ}。
输出对象：
  - signal：完整复基带信号（写回全局总线，刷新全部视图）；
  - visuals.constellation_ideal：理想星座点（I/Q），供星座图叠加对比；
  - info：符号数/比特数/成型参数等说明。

科学说明：成型滤波抑制频谱旁瓣；频偏在星座图上表现为整体旋转，
噪声表现为散点弥散 —— 这正是教学对比点。
"""
from __future__ import annotations

import numpy as np

from ..errors import AnalysisError
from . import CHAIN_MAX_POINTS

MODULATIONS = ("bpsk", "qpsk", "8psk", "16qam", "64qam")
_BITS_PER = {"bpsk": 1, "qpsk": 2, "8psk": 3, "16qam": 4, "64qam": 6}


def constellation_map(modulation: str) -> np.ndarray:
    """返回平均功率归一化为 1 的星座点（复数数组）。"""
    m = modulation.lower()
    if m == "bpsk":
        pts = np.array([1.0, -1.0])
    elif m == "qpsk":  # Gray 编码：00,01,11,10 -> 1+j,-1+j,-1-j,1-j
        pts = np.array([1 + 1j, -1 + 1j, -1 - 1j, 1 - 1j]) / np.sqrt(2.0)
    elif m == "8psk":
        pts = np.exp(1j * (2 * np.pi * np.arange(8) / 8.0 + np.pi / 8.0))
    elif m in ("16qam", "64qam"):
        side = 4 if m == "16qam" else 8
        # 标准方形星座（Gray 顺序近似：逐行/逐列交替），幅度线性取值
        vals = np.arange(-(side - 1), side, 2)
        iq = np.array([a + 1j * b for a in vals for b in vals])
        # 平均功率归一化
        pts = iq / np.sqrt(np.mean(np.abs(iq) ** 2))
    else:
        raise AnalysisError(f"未知调制方式：{modulation}", [f"可选：{'/'.join(MODULATIONS)}"], "bad_modulation")
    return pts.astype(complex)


def rrc_taps(beta: float, sps: int, span: int) -> np.ndarray:
    """根升余弦（RRC）成型滤波器抽头。

    公式：h(t) = (4β/√T·π) · [cos((1+β)πt/T) + sin((1-β)πt/T)/(4βt/T)] / (1-(4βt/T)²)
    边界 t=0 与 t=±T/(4β) 单独处理，避免除零。
    """
    if beta < 0 or beta > 1:
        raise AnalysisError("滚降系数必须位于 0~1 之间", [], "bad_rolloff")
    T = float(sps)
    n = span * sps
    idx = np.arange(-n, n + 1)
    t = idx / T
    taps = np.zeros_like(t, dtype=float)
    mask0 = np.abs(t) < 1e-12                       # t=0 奇点
    regular = ~mask0
    tt = t[regular]
    with np.errstate(divide="ignore", invalid="ignore"):
        denom = 1.0 - (4.0 * beta * tt) ** 2
        vals = (4.0 * beta / np.pi) * (
            np.cos((1.0 + beta) * np.pi * tt)
            + np.sin((1.0 - beta) * np.pi * tt) / (4.0 * beta * tt)
        ) / denom
        taps[regular] = np.where(np.abs(denom) < 1e-12, np.nan, vals)
    taps[mask0] = 1.0 - beta + 4.0 * beta / np.pi
    # t = ±1/(4β) 处的极限值
    if beta > 0:
        tb = 1.0 / (4.0 * beta)
        taps[np.abs(np.abs(t) - tb) < 1e-9] = (beta / np.sqrt(2.0)) * (
            (1.0 + 2.0 / np.pi) * np.sin(np.pi / (4.0 * beta))
            + (1.0 - 2.0 / np.pi) * np.cos(np.pi / (4.0 * beta))
        )
    taps = np.nan_to_num(taps)
    # 标准 RRC 缩放：连续脉冲 g_c(0) = (1-β+4β/π)/√T，抽样后 Σh² ≈ sps。
    # 与"零填充上采样"配合时输出功率 = E|a|²·(Σh²/sps) = E|a|²（见 generate_signal）。
    taps = taps / np.sqrt(T)
    return taps


def generate_signal(modulation: str, symbol_rate: float, samples_per_symbol: int,
                    freq_offset: float, phase_offset: float, num_symbols: int,
                    rolloff: float = 0.35, seed: int = 42) -> dict:
    """生成数字调制复基带信号。"""
    m = modulation.lower()
    if m not in _BITS_PER:
        raise AnalysisError(f"未知调制方式：{modulation}", [f"可选：{'/'.join(MODULATIONS)}"], "bad_modulation")
    symbol_rate = float(symbol_rate)
    sps = int(samples_per_symbol)
    num_symbols = int(num_symbols)
    if symbol_rate <= 0:
        raise AnalysisError("符号速率必须为正数", [], "bad_symbol_rate")
    if sps < 2:
        raise AnalysisError("每符号采样点数必须 >= 2", [], "bad_sps")
    if not (1 <= num_symbols <= 50000):
        raise AnalysisError("符号数必须在 1 ~ 50000 之间", [], "bad_num_symbols")
    fs = symbol_rate * sps
    if freq_offset is None or abs(float(freq_offset)) >= fs / 2.0:
        raise AnalysisError(f"载波频偏必须满足 |Δf| < fs/2 = {fs / 2:g} Hz",
                            ["频偏过大会导致频谱混叠"], "bad_freq_offset")
    n = num_symbols * sps
    if n > CHAIN_MAX_POINTS:
        raise AnalysisError(f"生成点数 {n} 超过链路上限 {CHAIN_MAX_POINTS:,}",
                            ["减少符号数或每符号采样点数"], "too_many_points")

    bps = _BITS_PER[m]
    rng = np.random.default_rng(seed)
    bits = rng.integers(0, 2, num_symbols * bps)
    # 比特 -> 符号序号（按 Gray 顺序取星座点）
    pts = constellation_map(m)
    sym_idx = bits.reshape(-1, bps).dot(1 << np.arange(bps - 1, -1, -1))
    symbols = pts[sym_idx]

    # 上采样：零填充（每符号 sps 个采样中仅 1 个非零点）。
    # 数学依据：y[n] = Σ a_k·h[n-k·sps]，输出功率 = E|a|²·Σh²/sps = E|a|²。
    up = np.zeros(n, dtype=complex)
    up[::sps] = symbols
    # RRC 成型滤波（卷积，保持输出长度与输入一致）。
    # 零填充 + RRC 后平均功率 = E|a|²/sps，乘 √sps 补偿使输出平均功率归一化到 1
    # （对应连续时间信号功率 E|a|²/T 的离散等价，符号时刻峰值幅度 ≈ 1）。
    if rolloff is not None and rolloff > 1e-3:
        taps = rrc_taps(float(rolloff), sps, span=8)
        y = np.convolve(up, taps, mode="same") * np.sqrt(sps)
    else:
        # 滚降为 0：近似矩形成型（零阶保持），平均功率同样为 E|a|²
        y = np.repeat(symbols, sps)
    # 载波频偏 + 相位偏移
    t = np.arange(n) / fs
    y = y * np.exp(1j * (2 * np.pi * float(freq_offset) * t + float(phase_offset)))

    out_signal = {
        "t": [float(x) for x in t],
        "re": [float(x) for x in y.real],
        "im": [float(x) for x in y.imag],
        "sampling_rate": float(fs),
        "t_start": 0.0,
        "t_end": float(t[-1]),
        "n_points": int(n),
    }
    visuals = {
        "constellation_ideal": [
            {"i": float(p.real), "q": float(p.imag), "label": f"符号 {k}"}
            for k, p in enumerate(pts)
        ],
    }
    info = {
        "modulation": m.upper(), "symbol_rate": float(symbol_rate),
        "samples_per_symbol": sps, "num_symbols": num_symbols,
        "bits": int(num_symbols * bps), "freq_offset_hz": float(freq_offset),
        "phase_offset_rad": float(phase_offset), "rolloff": float(rolloff),
        "fs": float(fs), "note": "星座图可观察噪声弥散与频偏旋转（见总线信号散点）。",
    }
    return {"signal": out_signal, "visuals": visuals, "info": info}
