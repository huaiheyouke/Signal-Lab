"""【预留】星座图扩展骨架。

原理：对 M 进制数字调制信号 s(t)=Σ a_n·g(t-nT)，谐波/频谱分析后
在符号时刻 t=nT 采样复包络，即可绘制 I/Q 星座图。

可直接复用 pipeline 的输出：
    - ctx["harmonics"] 的复系数 c_k（coeff_re/coeff_im）做频域星座分析；
    - ctx["s"] 采样序列做时域符号采样。

输出约定：ctx["extras"]["constellation"] = {i: [...], q: [...], labels: [...]}，
前端用 Plotly scatter 渲染星座散点。
"""
from __future__ import annotations

from .base import AnalysisExtension


class ConstellationExtension(AnalysisExtension):
    """星座图（骨架，待实现）。"""

    name = "constellation"
    description = "星座图（预留骨架）"

    def on_end(self, ctx: dict) -> None:
        # TODO: 在符号时刻采样复包络，输出 I/Q 星座点
        pass
