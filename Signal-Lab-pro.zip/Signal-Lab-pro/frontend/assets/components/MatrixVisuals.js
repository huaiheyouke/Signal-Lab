// 矩阵可视化组件（矩阵算子工作台 / Transformer 等效信道共用）
// 渲染：①矩阵热力图 ②特征值柱状谱 ③测试向量三维变换（v -> Mv）
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  props: ['heatmap', 'eig', 'vec3d', 'matrixTitle', 'eigTitle'],
  mounted() { this.render(); },
  watch: {
    heatmap: { deep: true, handler() { this.render(); } },
    eig: { deep: true, handler() { this.render(); } },
    vec3d: { deep: true, handler() { this.render(); } },
  },
  beforeUnmount() {
    for (const ref of ['hm', 'eig', 'vec']) if (this.$refs[ref]) Plotly.purge(this.$refs[ref]);
  },
  methods: {
    render() {
      const base = { paper_bgcolor: '#fff', plot_bgcolor: '#fff' };

      // ① 热力图
      if (this.heatmap) {
        const n = this.heatmap.length;
        const z = this.heatmap;
        Plotly.react(this.$refs.hm, [{
          z, type: 'heatmap', colorscale: 'Viridis',
          colorbar: { title: '值' },
          hovertemplate: '行=%{y}<br>列=%{x}<br>值=%{z:.4g}<extra></extra>',
        }], Object.assign({
          title: this.matrixTitle || '矩阵热力图',
          xaxis: { title: '列' }, yaxis: { title: '行', autorange: 'reversed' },
          margin: { t: 44, l: 56, r: 60, b: 46 },
          annotations: n <= 12 ? z.map((row, i) => row.map((v, j) => ({
            x: j, y: i, text: v.toFixed(2), showarrow: false, font: { size: 9, color: '#111827' },
          }))).flat() : [],
        }, base), PLOTLY_CONFIG);
      }
      // ② 特征值柱状谱
      if (this.eig && this.eig.length) {
        Plotly.react(this.$refs.eig, [{
          x: this.eig.map(e => e.index), y: this.eig.map(e => e.magnitude),
          type: 'bar', marker: { color: '#8b5cf6' },
          hovertemplate: '特征值 #%{x}<br>|λ| = %{y:.4g}<extra></extra>',
        }], Object.assign({
          title: this.eigTitle || '特征值谱（|λ| 降序）',
          xaxis: { title: '特征值序号' }, yaxis: { title: '|λ|' },
          margin: { t: 44, l: 56, r: 16, b: 46 },
        }, base), PLOTLY_CONFIG);
      }
      // ③ 3D 向量变换（v 与 Mv，从原点出发）
      if (this.vec3d) {
        const v = this.vec3d.v, Mv = this.vec3d.Mv;
        const mk = (p, color, name) => ({
          type: 'scatter3d', mode: 'lines+markers',
          x: [0, p[0]], y: [0, p[1]], z: [0, p[2]],
          line: { width: 5, color }, marker: { size: 6, color },
          name, hovertemplate: name + '：(%{x:.4g}, %{y:.4g}, %{z:.4g})<extra></extra>',
        });
        Plotly.react(this.$refs.vec, [mk(v, '#2563eb', 'v'), mk(Mv, '#f97316', 'M@v')], {
          title: '向量三维变换（蓝=v，橙=M@v）',
          scene: {
            xaxis: { title: 'x' }, yaxis: { title: 'y' }, zaxis: { title: 'z' },
            aspectmode: 'cube',
          },
          margin: { l: 0, r: 0, t: 44, b: 0 },
          paper_bgcolor: '#fff',
        }, PLOTLY_CONFIG);
      }
    },
  },
  template: `
  <div class="matrix-visuals">
    <float-card v-if="heatmap" :title="matrixTitle || '矩阵热力图'" export-name="heatmap.png"
      help="矩阵数值热力图：颜色越亮数值越大。观察矩阵结构（如多径信道 H 的 Toeplitz 结构、Transformer 注意力权重的行归一化特性）。">
      <div ref="hm" class="plot"></div>
    </float-card>
    <float-card v-if="eig && eig.length" :title="eigTitle || '特征值谱'" export-name="eigspectrum.png"
      help="特征值柱状谱：按 |λ| 降序排列。特征值分布反映矩阵性质（奇异矩阵出现零特征值；条件数大则特征值跨度大）。">
      <div ref="eig" class="plot"></div>
    </float-card>
    <float-card v-if="vec3d" title="向量三维变换（v → M@v）" export-name="vec3d.png"
      help="测试向量 v（蓝）经矩阵变换后的结果 M@v（橙），从原点出发的三维可视化。直观感受矩阵对向量的旋转、缩放与拉伸。">
      <div ref="vec" class="plot-tall"></div>
      <div class="axis-note">{{ vec3d.note || '' }}</div>
    </float-card>
  </div>
  `,
};
