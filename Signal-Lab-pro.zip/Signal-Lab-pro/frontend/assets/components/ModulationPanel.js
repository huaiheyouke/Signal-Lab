// Tab2 数字调制面板：生成复基带 I/Q 信号 + 理想星座点
// 输入：随机比特；输出：调制信号写回总线，星座图同步刷新（可观察噪声/信道造成的弥散与旋转）。
import { bus, loadSignal, signalFromResponse } from '../bus.js';
import { chainCall } from '../api.js';

export default {
  data() {
    return {
      modulation: 'qpsk', symbolRate: 1000, sps: 32,
      freqOffset: 0, phaseOffset: 0, numSymbols: 128, rolloff: 0.35,
      error: null, busy: false,
    };
  },
  methods: {
    async apply() {
      this.error = null;
      this.busy = true;
      try {
        const r = await chainCall('/api/chain/modulate', {
          modulation: this.modulation, symbol_rate: this.symbolRate,
          samples_per_symbol: this.sps, freq_offset: this.freqOffset,
          phase_offset: this.phaseOffset, num_symbols: this.numSymbols,
          rolloff: this.rolloff, seed: 42,
        });
        await loadSignal(signalFromResponse(r.signal), '调制：' + this.modulation.toUpperCase() + ' @' + this.symbolRate + ' Bd');
        bus.moduleResult.mod = r;
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="panel">
    <div class="panel-title-row"><h2>② 数字调制与星座图</h2>
      <help-btn title="数字调制（发射机）" text="生成数字调制复基带信号：随机比特 → 星座映射（Gray 编码，平均功率归一化为 1）→ 零填充上采样 → 根升余弦（RRC）成型 → 载波频偏/相位偏移。
参数说明：符号速率 Bd、每符号采样点数（>=2）、载波频偏（星座整体旋转）、相位偏移、滚降系数（频谱带宽控制）。
点【生成调制信号】后信号写入全局总线：本页星座图显示理想星座点（黄）与信号采样点（蓝）；切到多径信道 Tab 可观察信道造成的星座弥散与旋转。"></help-btn>
    </div>
    <p class="panel-desc">生成数字调制复基带信号（随机比特 → 星座映射 → 上采样 → RRC 成型 → 频偏/相偏）。
    信号写回总线；星座图可观察后续噪声/信道带来的散点弥散与旋转。</p>

    <div class="param-grid">
      <div class="field-inline"><label>调制方式</label>
        <select v-model="modulation">
          <option value="bpsk">BPSK</option>
          <option value="qpsk">QPSK</option>
          <option value="8psk">8PSK</option>
          <option value="16qam">16QAM</option>
          <option value="64qam">64QAM</option>
        </select>
      </div>
      <div class="field-inline"><label>符号速率 (Bd)</label>
        <input v-model.number="symbolRate" type="number" min="1" step="any" />
      </div>
      <div class="field-inline"><label>每符号采样点</label>
        <input v-model.number="sps" type="number" min="2" step="1" />
      </div>
      <div class="field-inline"><label>载波频偏 (Hz)</label>
        <input v-model.number="freqOffset" type="number" step="any" />
      </div>
      <div class="field-inline"><label>相位偏移 (rad)</label>
        <input v-model.number="phaseOffset" type="number" step="any" />
      </div>
      <div class="field-inline"><label>符号数</label>
        <input v-model.number="numSymbols" type="number" min="1" max="50000" step="1" />
      </div>
      <div class="field-inline"><label>滚降系数 β</label>
        <input v-model.number="rolloff" type="number" min="0" max="1" step="0.05" />
      </div>
    </div>

    <button class="primary" :disabled="busy" @click="apply">{{ busy ? '生成中…' : '▶ 生成调制信号' }}</button>
    <div v-if="error" class="error-box"><div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions.length"><li v-for="(s,i) in error.suggestions" :key="i">{{ s }}</li></ul>
    </div>
  </div>
  `,
};
