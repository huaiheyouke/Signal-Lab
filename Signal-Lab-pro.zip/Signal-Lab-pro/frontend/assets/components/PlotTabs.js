// 右侧图形区：三个 Tab —— 时域波形 / 频谱集合 / 三维轨迹
export default {
  props: ['result', 'busy'],
  data() { return { tab: 'time' }; },
  template: `
  <div class="plot-tabs">
    <div class="tab-bar">
      <button :class="{active: tab==='time'}" @click="tab='time'">时域波形</button>
      <button :class="{active: tab==='spectrum'}" @click="tab='spectrum'">频谱集合</button>
      <button :class="{active: tab==='3d'}" @click="tab='3d'">三维轨迹</button>
    </div>
    <div class="tab-body">
      <time-plot v-if="tab==='time' && result" :result="result"></time-plot>
      <spectrum-plots v-else-if="tab==='spectrum' && result" :result="result"></spectrum-plots>
      <trajectory-plot v-else-if="tab==='3d' && result" :result="result"></trajectory-plot>
      <div v-else class="placeholder">
        <p v-if="busy">正在分析…</p>
        <p v-else>在左侧输入信号表达式，点击「运行分析」。<br/>
        结果将以 5 张交互式图形展示：时域波形 / 幅度谱 / 相位谱 / 功率谱密度 / 三维轨迹，<br/>
        支持缩放、拖拽、旋转与悬浮查看数值。</p>
      </div>
    </div>
  </div>
  `,
};
