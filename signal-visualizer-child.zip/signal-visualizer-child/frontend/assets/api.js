// 后端 API 封装：唯一的数据通道（POST /api/analyze）

export async function runAnalysis(payload) {
  const resp = await fetch('/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    let detail = { error: '请求失败 (HTTP ' + resp.status + ')', suggestions: [] };
    try {
      const j = await resp.json();
      if (j && j.detail) {
        detail = typeof j.detail === 'string' ? { error: j.detail, suggestions: [] } : j.detail;
      }
    } catch (e) { /* 非 JSON 响应，保留默认信息 */ }
    const err = new Error(detail.error || '未知错误');
    err.suggestions = detail.suggestions || [];
    err.code = detail.code || '';
    throw err;
  }
  return await resp.json();
}
