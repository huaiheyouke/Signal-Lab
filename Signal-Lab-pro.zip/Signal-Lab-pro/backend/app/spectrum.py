"""频谱计算模块（scipy/numpy 数值 FFT）。

输出：幅度谱、相位谱、功率谱密度（Periodogram）+ 主要谱峰摘要 + 文字说明。

约定：
- 实信号：单边谱（0 ~ fs/2），幅度 = 2|X|/N（直流与奈奎斯特点不翻倍）；
- 复信号：双边谱（-fs/2 ~ fs/2），幅度 = |X|/N；
- PSD 用 scipy.signal.periodogram（density 标度，单位 V²/Hz）。
"""
from __future__ import annotations

import numpy as np
from scipy import signal as sps

MAX_SUMMARY_PEAKS = 5


def _find_major_peaks(f, mag, n_fft):
    """找幅度谱主要谱峰（幅度 >= 3% 峰值、间距 >= 2 个频点）。"""
    threshold = 0.03 * float(np.max(mag)) if len(mag) else 0.0
    peaks, _ = sps.find_peaks(mag, height=threshold, distance=2)
    order = sorted(peaks, key=lambda i: -mag[i])[:MAX_SUMMARY_PEAKS]
    return [
        {"frequency": float(f[i]), "magnitude": float(mag[i]),
         "description": f"{f[i]:.6g} Hz 处谱峰，幅度 {mag[i]:.6g}"}
        for i in order
    ]


def compute_spectrum(s: np.ndarray, fs: float, is_complex: bool) -> dict:
    """计算幅度谱 / 相位谱 / 功率谱密度，返回 dict 与说明文字。"""
    s = np.asarray(s, dtype=complex)
    n = len(s)
    resolution = fs / n

    if is_complex:
        # 双边谱
        X = np.fft.fftshift(np.fft.fft(s)) / n
        f = np.fft.fftshift(np.fft.fftfreq(n, 1.0 / fs))
        mag = np.abs(X)
        two_sided = True
    else:
        # 单边谱（实信号）
        X = np.fft.rfft(s.real)
        f = np.fft.rfftfreq(n, 1.0 / fs)
        mag = np.abs(X) * 2.0 / n
        mag[0] = np.abs(X[0]) / n                     # 直流不翻倍
        if n % 2 == 0 and n > 1:
            mag[-1] = np.abs(X[-1]) / n               # 奈奎斯特点不翻倍
        two_sided = False

    phase = np.angle(X)                                # 相位谱（弧度，主值）
    # 功率谱密度（V²/Hz）：实信号必须传实数数组，periodogram 才会返回
    # 单边谱（与 rfft 频率轴对齐）；传复数数组会返回双边谱导致长度不一致
    if is_complex:
        _, psd = sps.periodogram(s, fs, detrend=False)
    else:
        _, psd = sps.periodogram(s.real, fs, detrend=False)

    # 幅度谱阈值处理：低于峰值的 1e-9 压平，避免相位谱噪声
    mag_peak = float(np.max(mag)) if len(mag) else 0.0
    if mag_peak > 0:
        mag = np.where(mag < 1e-9 * mag_peak, 0.0, mag)

    summary = _find_major_peaks(f, mag, n)
    return {
        "frequency": [float(x) for x in f],
        "magnitude": [float(x) for x in mag],
        "phase": [float(x) for x in phase],
        "psd": [float(x) for x in psd],
        "two_sided": two_sided,
        "resolution_hz": float(resolution),
        "n_fft": int(n),
        "summary": summary,
    }


def build_spectrum_note(spec: dict, fs: float, is_complex: bool) -> str:
    """生成频谱简要说明（纯文本，前端直接展示）。"""
    n = spec["n_fft"]
    side = "双边" if spec["two_sided"] else "单边"
    lines = [
        f"FFT 数值频谱分析：N={n} 点，采样率 fs={fs:g} Hz，"
        f"频率分辨率 Δf={spec['resolution_hz']:.6g} Hz。",
        f"{side}幅度谱{'（复信号）' if is_complex else '（实信号）'}："
        f"实信号幅度=2|X|/N，复信号幅度=|X|/N。",
    ]
    if spec["summary"]:
        lines.append("主要谱峰：" + "；".join(p["description"] for p in spec["summary"]) + "。")
    else:
        lines.append("未检测到显著谱峰（信号接近直流或能量极低）。")
    lines.append("功率谱密度采用 Periodogram 估计（density 标度，单位 V²/Hz）。")
    return "\n".join(lines)
