"""通信链路仿真模块包（SignalLab Pro 扩展）。

设计约定（所有模块统一）：
- 输入：dict，包含 signal 字段 {t, re, im, sampling_rate}（全局总线信号快照）与模块参数；
- 运算：全部使用 numpy/scipy 数值运算（本包不做符号运算）；
- 输出：{signal: {t, re, im, sampling_rate, t_start, t_end, n_points},
        visuals: {...},   # 模块专属可视化数据（热力图/星座/冲激响应等）
        info: {...}}      # 文本说明/数值结果
- 每个模块独立可开关：禁用时前端直接旁路（不调用本模块）。

链路模式下信号点数上限（保护传输与绘图性能）。
"""
CHAIN_MAX_POINTS = 200_000
