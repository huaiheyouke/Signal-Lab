"""分析流水线：串联全部计算阶段，并在关键节点调用扩展钩子。

阶段顺序：
  1. 表达式解析（sympy，超时保护）
  2. 参数推导（采样率 >= 8×最高频率；窗口覆盖 3~5 周期）
  3. 数值采样
  4. 周期检测 + 复数傅里叶级数（符号/数值双路径）
  5. 示波器指标
  6. 频谱（幅度/相位/PSD）
  7. 扩展钩子（on_begin -> on_signal_parsed -> on_harmonics -> on_spectrum -> on_end）
"""
from __future__ import annotations

import threading

import numpy as np

from . import metrics as metrics_mod
from . import params as params_mod
from . import periodic as periodic_mod
from . import signal_parser as parser_mod
from . import spectrum as spectrum_mod
from .errors import AnalysisError
from .extensions import get_registry

PARSE_TIMEOUT = 15.0      # 符号解析超时（秒）
STAGE_TIMEOUT = 30.0      # 单阶段计算超时（秒）


def run_with_timeout(timeout: float, fn, *args, **kwargs):
    """在守护线程中执行 fn；超时抛出 AnalysisError（防止 sympy 卡死）。"""
    box: dict = {}

    def runner():
        try:
            box["v"] = fn(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001
            box["e"] = exc

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout)
    if th.is_alive():
        raise AnalysisError(
            "计算超时：表达式过于复杂，请简化后重试",
            ["尝试把表达式拆成多个简单信号分别分析", "减小采样点数或谐波上限"],
            "analysis_timeout",
        )
    if "e" in box:
        raise box["e"]
    return box["v"]


def analyze(req) -> dict:
    """执行一次完整分析，返回 AnalyzeResponse 所需的全部字段。"""
    warnings: list[str] = []
    registry = get_registry()
    ctx: dict = {"request": req.model_dump(), "warnings": warnings, "extras": {}}
    for ext in registry.items():
        ext.on_begin(ctx)

    # ---- 阶段 1：表达式解析 ----
    expr = run_with_timeout(PARSE_TIMEOUT, parser_mod.parse_signal_expression, req.expression)
    is_complex, re_expr, im_expr = parser_mod.classify_signal(expr)
    ctx.update(expr=expr, re_expr=re_expr, im_expr=im_expr, is_complex=is_complex)
    for ext in registry.items():
        ext.on_signal_parsed(ctx)

    # ---- 阶段 2：参数推导 ----
    f_max_est = periodic_mod.estimate_max_frequency(expr)
    f0_est = periodic_mod.estimate_fundamental(expr)
    params = params_mod.derive_parameters(f_max_est, f0_est,
                                          req.t_start, req.t_end, req.sampling_rate)
    warnings.extend(params["warnings"])
    t_start, t_end = params["t_start"], params["t_end"]
    fs, n = params["sampling_rate"], params["n_points"]

    # ---- 阶段 3：数值采样 ----
    sampler = parser_mod.build_sampler(expr)
    t = t_start + np.arange(n) / fs
    s = sampler(t)
    ctx.update(t=t, s=s, sampler=sampler, t_start=t_start, t_end=t_end, fs=fs)

    # ---- 阶段 4：周期检测 + 复数傅里叶级数 ----
    per = run_with_timeout(STAGE_TIMEOUT, periodic_mod.analyze_periodicity,
                           expr, parser_mod.VAR, sampler, is_complex, f_max_est,
                           req.max_harmonics)
    warnings.extend(per["warnings"])
    ctx.update(periodicity=per["periodicity"], harmonics=per["harmonics"],
               period=per["period"], fundamental_frequency=per["fundamental_frequency"])
    for ext in registry.items():
        ext.on_harmonics(ctx)

    # ---- 阶段 5：示波器指标 ----
    metrics = metrics_mod.compute_metrics(t, s, is_complex,
                                          per["period"], per["fundamental_frequency"])

    # ---- 阶段 6：频谱 ----
    spec = run_with_timeout(STAGE_TIMEOUT, spectrum_mod.compute_spectrum, s, fs, is_complex)
    ctx.update(spectrum=spec)
    for ext in registry.items():
        ext.on_spectrum(ctx)

    # ---- 阶段 7：扩展收尾 ----
    for ext in registry.items():
        ext.on_end(ctx)

    # ---- 组装响应 ----
    convention = (
        "实信号：单边约定 A_k=2|c_k|（k>0），c_k 为复傅里叶系数"
        if not is_complex else
        "复信号：双边约定 A_k=|c_k|（k∈ℤ）"
    ) + "；展开式 s(t)=Σ A_k·e^{j(2π f_k t + φ_k)}"

    return {
        "expression": req.expression,
        "normalized_expression": str(expr),
        "signal_type": "complex" if is_complex else "real",
        "periodicity": per["periodicity"],
        "period": per["period"],
        "fundamental_frequency": per["fundamental_frequency"],
        "harmonics": per["harmonics"],
        "harmonics_method": per["method"],
        "harmonics_convention": convention,
        "metrics": metrics,
        "spectrum": {k: v for k, v in spec.items() if k != "summary"},
        "spectrum_summary": spec["summary"],
        "spectrum_note": spectrum_mod.build_spectrum_note(spec, fs, is_complex),
        "time": {
            "t": [float(x) for x in t],
            "real": [float(x) for x in s.real],
            "imag": [float(x) for x in s.imag],
            "sampling_rate": float(fs),
            "t_start": float(t_start),
            "t_end": float(t_end),
            "n_points": int(n),
        },
        "parameters_used": {
            "t_start": float(t_start),
            "t_end": float(t_end),
            "sampling_rate": float(fs),
            "n_points": int(n),
            "frequency_resolution_hz": float(spec["resolution_hz"]),
        },
        "warnings": warnings,
        "extensions": ctx.get("extras", {}),
    }
