# -*- coding: utf-8 -*-
"""通信链路仿真模块冒烟测试。

运行：python backend/tests/chain_test.py
覆盖：预设 / 噪声 / 滤波 / 调制 / 多径信道 / 矩阵 / Transformer / 数值分析 / 对比。
"""
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from backend.app.chain import presets, noise_filter, modulation, multipath
from backend.app.chain import matrix_ops, transformer_eq, analyze_signal, compare
from backend.app.errors import AnalysisError

PASS = 0


def ok(label):
    global PASS
    PASS += 1
    print(f"[PASS] {label}")


def expect_error(fn, code, label):
    try:
        fn()
    except AnalysisError as exc:
        assert exc.code == code, f"{label}: code={exc.code} != {code}"
        ok(f"错误处理 {code}: {label}")
        return
    raise AssertionError(f"{label}: 应当抛出 AnalysisError({code})")


# ---------- 基础信号（余弦 + 方波总线） ----------
base = presets.generate_preset("sine", {"f": 100})
sig = base["signal"]
assert len(sig["t"]) == len(sig["re"]) == len(sig["im"]) > 0
ok("预设 sine 生成")

sq = presets.generate_preset("square", {"f": 100})["signal"]
tri = presets.generate_preset("triangle", {"f": 100})["signal"]
lfm = presets.generate_preset("lfm", {"f0": 100, "k": 400})["signal"]
bar = presets.generate_preset("barker13", {"rc": 100})["signal"]
ok("预设 square/triangle/lfm/barker13 生成")

expect_error(lambda: presets.generate_preset("nope", {}), "unknown_preset", "未知预设")

# ---------- 噪声 ----------
r = noise_filter.add_awgn(sig, 20.0)
y = r["signal"]
# SNR 近似验证（20dB 噪声功率 = 信号功率/100）
noise_power = r["info"]["noise_power"]
signal_power = sum(abs(a) ** 2 for a in
                   [complex(x, 0) for x in sig["re"]]) / len(sig["re"])
assert abs(noise_power - signal_power / 100.0) / (signal_power / 100.0) < 0.05, r["info"]
ok("AWGN 功率正确（SNR=20dB）")

# ---------- 滤波 ----------
r = noise_filter.apply_filter(sig, "lowpass", "iir", 8, 150.0, None)
assert len(r["signal"]["t"]) == len(sig["t"])
assert "freq_response" in r["visuals"]
# 通带/阻带增益验证（防归一化频率 bug）：100Hz 在通带内应保留，200Hz 应被抑制
fr = r["visuals"]["freq_response"]
h100 = max((m for f, m in zip(fr["frequency"], fr["magnitude"]) if 95 < f < 105), default=0)
h200 = max((m for f, m in zip(fr["frequency"], fr["magnitude"]) if 195 < f < 205), default=1)
assert h100 > 0.95, f"通带增益异常 {h100}"
assert h200 < 0.1, f"阻带抑制异常 {h200}"
ok(f"IIR 低通滤波 + 幅频响应（|H(100Hz)|={h100:.3f}, |H(200Hz)|={h200:.3f}）")
r = noise_filter.apply_filter(sig, "bandpass", "fir", 31, 80.0, 120.0)
assert "freq_response" in r["visuals"]
ok("FIR 带通滤波")
expect_error(lambda: noise_filter.apply_filter(sig, "lowpass", "iir", 8, 5000.0, None),
             "bad_cutoff", "截止频率超奈奎斯特")

# ---------- 调制 ----------
r = modulation.generate_signal("qpsk", 1000, 32, 0, 0, 64, 0.35)
assert r["signal"]["n_points"] == 64 * 32
assert len(r["visuals"]["constellation_ideal"]) == 4
# 平均功率 ≈ 1（RRC 归一化后）
ss = [complex(a, b) for a, b in zip(r["signal"]["re"], r["signal"]["im"])]
p = sum(abs(x) ** 2 for x in ss) / len(ss)
assert abs(p - 1.0) < 0.15, f"QPSK 平均功率 {p}"
ok("QPSK 生成 + 平均功率归一化")

for m, npts in [("bpsk", 2), ("8psk", 8), ("16qam", 16), ("64qam", 64)]:
    rr = modulation.generate_signal(m, 1000, 16, 0, 0, 32, 0.35)
    assert len(rr["visuals"]["constellation_ideal"]) == npts
ok("BPSK/8PSK/16QAM/64QAM 星座点数正确")

# 频偏旋转验证：星座散点质心应接近原点，且存在旋转
r = modulation.generate_signal("qpsk", 1000, 32, 0, 0.5, 64, 0.35)  # 相位偏移 0.5 rad
ok("相位偏移调制生成")

# ---------- 多径信道 ----------
taps = [
    {"delay_s": 0.0005, "gain_re": 0.8, "gain_im": 0.0, "doppler_hz": 10.0},
    {"delay_s": 0.0012, "gain_re": 0.5, "gain_im": 0.2, "doppler_hz": -5.0},
]
r = multipath.apply_channel(sig, taps, k_factor=3.0)
out = r["signal"]
assert len(out["t"]) == len(sig["t"])
assert len(r["visuals"]["cir"]) == 2
H = r["visuals"]["H"]
L = r["visuals"]["H_size"]
assert len(H) == L and len(H[0]) == L
# 功率校验：QPSK 宽带信号通过功率归一化信道后功率应近似守恒。
# 注意：单音正弦会产生频率选择性干涉（同频路径相干叠加），功率不守恒是物理现象；
# 白噪声小样本波动大且插值会破坏其统计特性，因此用真实调制信号测试。
qpsk_sig = modulation.generate_signal("qpsk", 1000, 32, 0, 0, 256, 0.35)["signal"]
r2 = multipath.apply_channel(qpsk_sig, taps, k_factor=3.0)
p_in = sum(abs(complex(a, b)) ** 2 for a, b in zip(qpsk_sig["re"], qpsk_sig["im"])) / len(qpsk_sig["re"])
p_out = sum(abs(complex(a, b)) ** 2 for a, b in zip(r2["signal"]["re"], r2["signal"]["im"])) / len(r2["signal"]["re"])
assert abs(p_out - p_in) / p_in < 0.05, f"QPSK 经莱斯信道功率变化 {p_out / p_in}"
ok("多径信道（莱斯 K=3）QPSK 功率守恒 + CIR/H 输出")
expect_error(lambda: multipath.apply_channel(sig, [{"delay_s": 10.0, "gain_re": 1.0}], 0),
             "bad_delay", "时延超出窗口")
expect_error(lambda: multipath.apply_channel(sig, [], 0), "no_taps", "无多径")

# 纯瑞利（K=0）
r0 = multipath.apply_channel(sig, taps, k_factor=0.0)
assert r0["visuals"]["k_factor"] == 0.0
ok("纯瑞利信道（K=0）")

# ---------- 矩阵算子 ----------
M = [[1, 2, 3], [4, 5, 6], [7, 8, 10]]
r = matrix_ops.analyze_matrix(M, [1, 0, 0], None, False)
mi = r["matrix_info"]
assert mi["rank"] == 3 and mi["is_square"]
assert abs(mi["determinant"] + 3.0) < 1e-9          # det([[1,2,3],[4,5,6],[7,8,10]]) = -3
assert mi["condition_number"] > 1
assert len(mi["eigenvalues"]) == 3
assert "heatmap" in r["visuals"] and "eig_spectrum" in r["visuals"] and "vec3d" in r["visuals"]
ok("矩阵分析：秩/行列式(-3)/条件数/特征值/热力图/3D向量")

# 奇异矩阵
M2 = [[1, 2], [2, 4]]
r = matrix_ops.analyze_matrix(M2, None, None, False)
assert r["matrix_info"]["rank"] == 1
assert abs(r["matrix_info"]["determinant"]) < 1e-9
ok("奇异矩阵识别（秩=1，行列式≈0）")

# 矩阵作用于总线信号
r = matrix_ops.analyze_matrix(M, None, sig, True)
assert r["signal"] is not None and r["signal"]["n_points"] == 3
ok("矩阵作用于总线信号（y=M@x[:3]）")
expect_error(lambda: matrix_ops.analyze_matrix([[1, 2, 3]], None, sig, True),
             "matrix_not_square", "非方阵作用于信号")

# ---------- Transformer 等效信道 ----------
Q = [[1.0, 0.0], [0.0, 1.0]]
K = [[1.0, 0.0], [0.0, 1.0]]
V = [[1.0, 0.5], [0.5, 1.0]]
r = transformer_eq.run_transformer(2, Q, K, V, None, False)
H_eq = r["visuals"]["heatmap"]
# softmax 性质：每行和为 1，元素非负
for row in H_eq:
    assert abs(sum(row) - 1.0) < 1e-9
    assert all(x >= 0 for x in row)
assert len(r["visuals"]["eig_spectrum"]) == 2
ok("Transformer：H_eq 行 softmax 性质 + 特征值谱")

# from_bus 模式（用点数充足的 QPSK 信号）
r = transformer_eq.run_transformer(8, None, None, None, qpsk_sig, True)
assert r["signal"] is not None and r["signal"]["n_points"] == 64
assert len(r["visuals"]["heatmap"]) == 8
ok("Transformer：从总线构造 Q=K=V（d=8）并写回总线")

# ---------- 数值信号分析（总线刷新核心） ----------
r = analyze_signal.analyze_numeric_signal(sig)
assert r["periodicity"] == "periodic"
assert abs(r["fundamental_frequency"] - 100.0) < 0.5, r["fundamental_frequency"]
assert r["harmonics"], "应检测到谐波"
assert len(r["time"]["t"]) == len(sig["t"])
assert r["metrics"]["peak"] > 0
ok("数值信号分析：余弦 100Hz 周期/谐波/指标")

r = analyze_signal.analyze_numeric_signal(bar)
assert r["periodicity"] == "aperiodic"
ok("数值信号分析：Barker 码非周期")

r = analyze_signal.analyze_numeric_signal(r_mod := modulation.generate_signal(
    "qpsk", 1000, 32, 0, 0, 64, 0.35)["signal"])
assert r["signal_type"] == "complex"
ok("数值信号分析：QPSK 复信号识别")

# ---------- A/B 对比 ----------
r = compare.compare_signals(sig, noise_filter.add_awgn(sig, 20.0)["signal"])
assert r["mse"] > 0 and 10 < r["snr_db"] < 30
assert 0 < r["correlation"] < 1
ok(f"A/B 对比：SNR≈{r['snr_db']:.1f}dB，相关系数≈{r['correlation']:.3f}")

print("=" * 60)
print(f"链路模块冒烟测试全部通过 ✔（{PASS} 项）")
print("=" * 60)
