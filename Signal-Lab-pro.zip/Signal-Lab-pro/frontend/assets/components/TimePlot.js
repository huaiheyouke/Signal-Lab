// 图1：时域示波器二维视图（原始信号 + 各谐波分量叠加）
// 复信号绘制 Re[s(t)] 与 Im[s(t)] 两条曲线；谐波曲线为 A_k·cos(2π f_k t + φ_k)
import { stride, fmtHz, PALETTE, PLOTLY_CONFIG } from '../utils.js';

export default {
  props: ['result'],
  mounted() { this.render(); },
  watch: { result: { deep: true, handler() { this.render(); } } },
  beforeUnmount() { if (this.$refs.el) Plotly.purge(this.$refs.el); },
  methods: {
    render() {
      const r = this.result;
      if (!r || !r.time) return;
      const t = stride(r.time.t, 40000);
      const re = stride(r.time.real, 40000);
      const im = stride(r.time.imag, 40000);

      const traces = [];
      if (r.signal_type === 'complex') {
        traces.push({ x: t, y: re, name: 'Re[s(t)]', mode: 'lines', line: { color: '#2563eb', width: 2 } });
        traces.push({ x: t, y: im, name: 'Im[s(t)]', mode: 'lines', line: { color: '#dc2626', width: 2 } });
      } else {
        traces.push({ x: t, y: re, name: 's(t)', mode: 'lines', line: { color: '#2563eb', width: 2 } });
      }

      // 周期信号：叠加各谐波分量（按幅度取前 30 项，避免图面过密）
      if (r.periodicity === 'periodic' && r.harmonics && r.harmonics.length) {
        const top = r.harmonics.filter(h => h.k !== 0)
          .sort((a, b) => b.amplitude - a.amplitude).slice(0, 30);
        top.forEach((h, idx) => {
          const y = t.map(x => h.amplitude * Math.cos(2 * Math.PI * h.frequency * x + h.phase));
          traces.push({
            x: t, y,
            name: '谐波 k=' + h.k + '（' + fmtHz(h.frequency) + ' Hz）',
            mode: 'lines',
            line: { dash: 'dot', width: 1.2, color: PALETTE[idx % PALETTE.length] },
            hoverinfo: 'skip',  // 谐波曲线仅作参考叠加，不参与悬浮（避免多曲线重叠显示）
          });
        });
      }

      const layout = {
        title: '图1 · 时域示波器视图（原始信号 + 谐波分量叠加）',
        xaxis: { title: 't (s)', gridcolor: '#e5e7eb' },
        yaxis: { title: 's(t)', gridcolor: '#e5e7eb' },
        margin: { t: 44, l: 56, r: 16, b: 46 },
        paper_bgcolor: '#fff', plot_bgcolor: '#fff',
        legend: { orientation: 'h', y: 1.12, font: { size: 11 } },
      };
      Plotly.react(this.$refs.el, traces, layout, PLOTLY_CONFIG);
    },
  },
  template: `
  <float-card title="图1 · 时域示波器（原始信号 + 谐波叠加）" export-name="time_domain.png"
    help="显示全局总线信号的时域波形；周期信号叠加各谐波分量（虚线）。复信号同时绘制实部与虚部。
用法：按住标题栏可拖出为自由浮动窗口并移动；右下角手柄缩放；双击标题最大化；⧉ 停靠/浮动切换；⤓ 导出 PNG；▾ 最小化。">
    <div ref="el" class="plot"></div>
  </float-card>
  `,
};
