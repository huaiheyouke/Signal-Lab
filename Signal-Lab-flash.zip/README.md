# 通信信号分析可视化教学工具 SignalLab（flash版）

本地单机运行的 Web 教学软件：输入时域信号表达式，后端（Python FastAPI + sympy/scipy/numpy）自动完成**信号解析、周期检测、复数傅里叶级数谐波分解、示波器指标、FFT 频谱分析**，前端（Vue3 + Plotly.js）在浏览器本地渲染 5 张**可交互矢量图**（缩放 / 拖拽 / 旋转 / 悬浮读数），并输出完整文本分析报告。全程无需联网、不调用任何外部绘图服务、不生成图片文件。

---

## 一、功能总览

| 模块 | 说明 |
| --- | --- |## 九、技术
| 表达式输入 | 自变量固定为 t；支持实信号与复信号（j / 1j 虚数单位、隐式乘法 2pi、100t、^ 乘方） |
| 参数面板 | t_start / t_end / sampling_rate 可留空，自动推导：**采样率 ≥ 8×最高频率，窗口覆盖 3~5 个周期** |
| 信号解析 | 实/复信号判别（复信号拆分 Re[s(t)]、Im[s(t)]）；周期/非周期/常数判别；周期 T、基频 f0 |
| 谐波分解 | 周期信号按**复数形式**展开 s(t)=Σ A_k·e^{j(2π f_k t+φ_k)}：符号路径精确提取（rewrite 复指数）；数值路径（方波/整流等）用每周期 FFT 求系数 |
| 示波器指标 | 直流分量、峰值、有效值 RMS、最大值/最小值、周期与基频、过零点序列 |
| 频谱分析 | scipy FFT：幅度谱、相位谱、功率谱密度（Periodogram）+ 主要谱峰摘要 |
| 图形输出 | 图1 时域示波器（谐波叠加）、图2 幅度谱、图3 相位谱、图4 功率谱密度、图5 三维轨迹 |
| 文本报告 | 表达式 / 类型 / 谐波表 / 指标 / 采样参数 / 频谱说明，一键复制 |
| 错误处理 | 非法表达式、未知符号、除零、采样率过低、奇异信号、计算超时 → 友好中文提示 + 修改建议 |
| 扩展接口 | AnalysisExtension 钩子体系，预留信道建模 / Transformer 等效信道 / 星座图骨架 |

---

## 二、目录结构

~~~text
signal-visualizer/
├── README.md                     # 本文档
├── requirements.txt              # 后端依赖清单
├── run.py                        # 一键启动脚本（自动打开浏览器）
├── backend/
│   ├── app/
│   │   ├── main.py               # FastAPI 入口 + 前端静态托管 + 错误转换
│   │   ├── schemas.py            # Pydantic 请求/响应模型
│   │   ├── errors.py             # AnalysisError 统一错误类型
│   │   ├── signal_parser.py      # 表达式解析 / 实复信号判别 / 数值采样
│   │   ├── periodic.py           # 周期检测 + 复数傅里叶级数（符号/数值双路径）
│   │   ├── metrics.py            # 示波器指标 + 过零点
│   │   ├── spectrum.py           # FFT 幅度/相位/PSD + 谱峰摘要
│   │   ├── params.py             # 默认参数推导 + 奈奎斯特校验
│   │   ├── pipeline.py           # 分析流水线（阶段编排 + 超时保护 + 扩展钩子）
│   │   └── extensions/           # ★ 扩展接口（预留模块）
│   │       ├── base.py           #   AnalysisExtension 基类 + 注册表
│   │       ├── channel_model.py        #   【预留】信道建模（含 AWGN 示例实现）
│   │       ├── transformer_channel.py  #   【预留】Transformer 等效信道
│   │       └── constellation.py        #   【预留】星座图
│   └── tests/
│       └── smoke_test.py         # 无服务器冒烟测试（21 项）
├── frontend/
│   ├── index.html                # 单页入口
│   ├── vendor/                   # ★ 离线前端依赖（vue 3.4 / plotly 2.35，已随仓库提供）
│   │   ├── vue.global.prod.js
│   │   └── plotly.min.js
│   └── assets/
│       ├── style.css             # 布局样式
│       ├── api.js                # 后端 API 封装
│       ├── main.js               # 应用入口（组件注册）
│       ├── utils.js              # 降采样 / 格式化工具
│       └── components/
│           ├── App.js            # 根组件（三区布局）
│           ├── InputPanel.js     # 表达式 + 参数面板 + 错误提示
│           ├── PlotTabs.js       # 时域 / 频谱集合 / 三维轨迹 Tab
│           ├── TimePlot.js       # 图1 时域示波器（含谐波叠加）
│           ├── SpectrumPlots.js  # 图2/3/4 幅度谱、相位谱、PSD
│           ├── TrajectoryPlot.js # 图5 三维轨迹（X=t, Y=Re, Z=Im）
│           └── ReportPanel.js    # 文本分析报告
└── scripts/
    └── fetch_frontend_libs.py    # 重新下载前端离线依赖（vendor 缺失时使用）
~~~

---

## 三、安装与启动

### 环境要求
- Python ≥ 3.9（开发验证于 3.13 / Anaconda）
- 浏览器：Chrome / Edge / Firefox（三维图需要 WebGL）

### 1. 安装依赖

~~~bash
pip install -r requirements.txt
~~~

前端依赖（vue / plotly）已存放在 frontend/vendor/，**无需联网即可运行**。
仅当 vendor 目录缺失或想升级版本时：

~~~bash
python scripts/fetch_frontend_libs.py
~~~

### 2. 启动

> 备选：如果 pip 安装受限（如无 site-packages 写权限），可把仓库内的 .pylibs
> （fastapi/starlette/uvicorn 纯 Python 包，随环境自动构建）加入搜索路径：
> Windows: set PYTHONPATH=.pylibs 后 python run.py；Linux/macOS: PYTHONPATH=.pylibs python run.py。

### 2. 启动

~~~bash
python run.py                # 一键启动，自动打开 http://127.0.0.1:8000
#或者
start.py                     #双击直接打开 http://127.0.0.1:8000
~~~

或手动指定端口 / 不自动开浏览器：

~~~bash
python run.py --port 9000 --no-browser
~~~

也可以直接用 uvicorn：

~~~bash
uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
~~~

浏览器访问 **http://127.0.0.1:8000** 即可使用。后端同时托管前端页面，无需单独启动前端服务。

### 3. 运行自检（可选）

~~~bash
python backend/tests/smoke_test.py
~~~

21 项冒烟测试覆盖符号路径 / 数值路径 / 非周期 / 常数 / 错误处理，全部通过即环境就绪。

---

## 四、测试用例（直接复制即可）

| # | 表达式 | 预期结果 |
| --- | --- | --- |
| 1 | cos(2*pi*100*t) | 实信号、周期 T=0.01s、基频 100Hz、唯一谐波 k=1（A=1, φ=0） |
| 2 | exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t) | 复信号、周期、基频 50Hz；谐波 k=1（A=1）、k=3（A=0.5）；三维轨迹为空间螺旋 |
| 3 | sign(sin(2*pi*100*t)) | 方波（数值路径）：基频 100Hz，奇次谐波 A_k=4/(πk) |
| 4 | cos(2*pi*100*t)+cos(2*pi*150*t) | 实信号、基频 **50Hz**（频率之 gcd）、谐波 k=2、k=3 |
| 5 | exp(-10*t)*cos(2*pi*50*t) | 衰减振荡：**非周期**，跳过傅里叶级数，直接数值频谱 |
| 6 | abs(sin(2*pi*50*t)) | 全波整流：周期、基频 100Hz（数值路径自动检测） |
| 7 | cos(2*pi*100*t)+cos(2*sqrt(2)*pi*100*t) | 频率不可通约：**非周期** |
| 8 | t**2 | 多项式：非周期 |
| 9 | 5 | 常数信号（直流 5） |
| 10 | cos(2*pi*100*t（少右括号） | 语法错误 + 修改建议 |

> 提示：点击输入面板中的「教学示例」按钮可快速填入常用信号。

---

## 五、数学约定（教学口径）

### 1. 谐波分解 —— 统一复数形式

~~~text
s(t) = Σ A_k · e^{j(2π f_k t + φ_k)}          （k ∈ ℤ）
复系数：c_k = A_k · e^{jφ_k}                  （coeff_re / coeff_im 给出）
~~~

- **实信号**：输出 k ≥ 0 的单边列表，k>0 时 **A_k = 2|c_k|**（负频率分量并入正频率，c_{-k}=conj(c_k)）；
- **复信号**：输出 k ∈ ℤ 的双边列表，**A_k = |c_k|**；
- 两种路径：**symbolic**（表达式可改写为有限复指数和时精确提取）与 **numeric**（方波 / 整流 / 阶跃等：FFT 检测基频 + 每周期 FFT 数值积分求系数，谐波数量上限默认 200）。

### 2. 频谱（FFT）

- 实信号：单边谱（0 ~ fs/2），幅度 = 2|X|/N（直流与奈奎斯特点不翻倍）；
- 复信号：双边谱（-fs/2 ~ fs/2），幅度 = |X|/N；
- 功率谱密度：scipy.signal.periodogram（density 标度，单位 V²/Hz）。

### 3. 三维轨迹坐标轴（硬性约束）

~~~text
X 轴 = t（时间）
Y 轴 = Re[s(t)]（实部）
Z 轴 = Im[s(t)]（虚部）
~~~

输入实信号时虚部恒为 0，轨迹自动落在 X-Y 平面；面板提供 X-Y / X-Z 平面投影开关。

---

## 六、错误处理

| 场景 | 返回 | 提示示例 |
| --- | --- | --- |
| 语法错误 / 括号不匹配 | 422 parse_error | 「表达式语法无法解析…」+ 修改建议 |
| 未知符号（如 x） | 422 unknown_symbol | 「表达式包含未定义符号：x，请只用 t」 |
| 除零 / 无穷大 | 422 parse_error | 「表达式包含无穷大或未定义值」 |
| 采样率过低（< 2×f_max） | 422 low_sampling_rate | 「不满足奈奎斯特条件，建议 ≥ 8×最高频率」 |
| 采样率低于建议值 | 200 + warnings | 「高频谐波分量可能被截断」（报告区黄色提示） |
| 信号发散（NaN/inf） | 422 singular_signal | 「请缩小时间窗口避开奇点」 |
| 计算超时 | 422 analysis_timeout | 「表达式过于复杂，请简化后重试」 |
| 点数超限（>200 万） | 422 too_many_points | 「请减小窗口或降低采样率」 |

所有错误统一为 {code, error, suggestions[]} JSON，前端红色面板展示。

---

## 七、扩展指南（信道建模 / Transformer 等效信道 / 星座图）

扩展接口位于 backend/app/extensions/。任何新模块只需继承 AnalysisExtension
并注册，即可自动接入分析流水线，**无需改动核心代码**：

~~~python
# backend/app/extensions/channel_model.py（骨架已提供，含 AWGN 完整示例）
from .base import AnalysisExtension

class MyChannelExtension(AnalysisExtension):
    name = "my_channel"                     # 唯一名称
    description = "自定义信道"

    def on_signal_parsed(self, ctx): ...    # 符号层：ctx["expr"] / ctx["re_expr"] / ctx["im_expr"]
    def on_harmonics(self, ctx): ...        # 谐波层：ctx["harmonics"]（含复系数 c_k）
    def on_spectrum(self, ctx): ...         # 频谱层：ctx["spectrum"]（可施加 H(f)）
    def on_end(self, ctx): ...              # 数据层：ctx["t"] / ctx["s"] / ctx["fs"]
        ctx["extras"]["my_channel"] = {...} # 输出随响应 extensions.my_channel 返回前端
~~~

启用扩展（在 extensions/__init__.py 中）：

~~~python
from .channel_model import AWGNChannelExtension
register_extension(AWGNChannelExtension(snr_db=30.0))
~~~

**规划中的三个模块**（骨架文件已就位，可直接填充）：

1. **信道建模** channel_model.py —— AWGN / 多径：在 on_end 对 ctx["s"] 加噪或卷积，输出加噪波形与信噪比；
2. **Transformer 等效信道** transformer_channel.py —— 在 on_spectrum 对频域施加信道频率响应 H(f)，输出幅频/相频特性；
3. **星座图** constellation.py —— 复用谐波复系数 c_k（coeff_re/coeff_im）或对 ctx["s"] 在符号时刻采样，输出 I/Q 星座点。

前端已预留：响应 extensions 字段透传；可在 ReportPanel.js 或新增 Tab 中渲染扩展数据。

---

## 八、常见问题

- **三维图黑屏 / 不显示？** 三维图使用 WebGL，请确认浏览器未禁用硬件加速；或刷新页面重试。
- **页面提示「前端依赖库缺失」？** 运行 python scripts/fetch_frontend_libs.py 下载 vue/plotly 到 frontend/vendor/。
- **采样率填多少合适？** 留空即可（自动 ≥ 8×最高频率）；手动填写时低于 2×最高频率会被拒绝，低于 8× 会警告。
- **窗口很大时页面卡？** 单次分析采样点数上限 200 万（超出报错）；前端对绘图数据自动降采样保证流畅。
- **谐波太多？** 默认上限 200 项（请求体 max_harmonics 可调 10~2000），图上叠加显示幅度最大的前 30 项。
- **科学计数法？** 2e3 会被解析为 2000.0；需要常数 e 请写 e（如 exp(-2*t)），需要 π 可写 pi 或 π。

---

## 九、技术栈

- 前端：Vue 3（全局构建，无构建步骤）+ Plotly.js（2D/3D WebGL），全部本地 vendor 离线加载
- 后端：Python FastAPI（静态托管 + REST API）
- 数学：sympy（符号解析 / 复指数改写）、numpy（采样 / 指标）、scipy（FFT / Periodogram / 峰值检测）
- 打包：requirements.txt 一键安装，python run.py 一键启动

---

## 十、关于版本更新

此次上传版本为幼年flash版，支持二次开发与插件改装，缺点在于有些优化需要二次定制。只保留了基本的
信号分析功能。后续将上传威力加强pro版，涵盖全通信链路与更自由与友好的交互格局
