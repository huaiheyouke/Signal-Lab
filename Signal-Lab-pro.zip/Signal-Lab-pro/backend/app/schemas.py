"""请求 / 响应数据模型（Pydantic v2）。

约定：
- 请求中 t_start / t_end / sampling_rate 均可缺省，缺省时后端自动推导；
- 响应为「一次完整分析」的全部数据：采样、谐波、指标、频谱、报告文本片段。
"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# 请求
# ---------------------------------------------------------------------------
class AnalyzeRequest(BaseModel):
    # 注意：不设 min_length —— 空字符串由解析器返回友好中文错误（empty_expression）
    expression: str = Field(..., max_length=2000,
                            description="以 t 为自变量的信号表达式，支持实/复信号")
    t_start: Optional[float] = Field(None, description="时间起点（秒），缺省自动推导")
    t_end: Optional[float] = Field(None, description="时间终点（秒），缺省自动推导")
    sampling_rate: Optional[float] = Field(None, description="采样率（Hz），缺省自动推导")
    max_harmonics: int = Field(200, ge=10, le=2000,
                               description="谐波分解最多保留的谐波个数")


# ---------------------------------------------------------------------------
# 响应
# ---------------------------------------------------------------------------
class HarmonicModel(BaseModel):
    """复数形式傅里叶级数的一项：s(t)=Σ A_k·e^{j(2π f_k t + φ_k)}。

    c_k = A_k·e^{jφ_k} 为复系数（coeff_re / coeff_im 给出实部虚部）。
    实信号约定 k>0 时 A_k=2|c_k|（单边幅度）；复信号约定 A_k=|c_k|（双边）。
    """
    k: int = Field(..., description="谐波序号")
    frequency: float = Field(..., description="频率 f_k（Hz）")
    amplitude: float = Field(..., description="幅度 A_k")
    phase: float = Field(..., description="相位 φ_k（弧度，主值 [-π, π]）")
    coeff_re: float = Field(..., description="复系数实部")
    coeff_im: float = Field(..., description="复系数虚部")


class TimeSeriesModel(BaseModel):
    t: list[float] = Field(..., description="采样时间轴（秒）")
    real: list[float] = Field(..., description="Re[s(t)] 采样序列")
    imag: list[float] = Field(..., description="Im[s(t)] 采样序列（实信号恒为 0）")
    sampling_rate: float
    t_start: float
    t_end: float
    n_points: int


class SpectrumModel(BaseModel):
    frequency: list[float] = Field(..., description="频率轴（Hz）")
    magnitude: list[float] = Field(..., description="幅度谱")
    phase: list[float] = Field(..., description="相位谱（弧度）")
    psd: list[float] = Field(..., description="功率谱密度（V²/Hz，Periodogram）")
    two_sided: bool = Field(..., description="True=双边谱（复信号），False=单边谱（实信号）")
    resolution_hz: float = Field(..., description="频率分辨率 Δf = fs / N")
    n_fft: int


class MetricsModel(BaseModel):
    dc_re: float
    dc_im: float
    peak: float = Field(..., description="峰值 = max|s(t)|")
    rms: float = Field(..., description="有效值 = sqrt(mean(|s|²))")
    max_re: float
    max_im: float
    min_re: float
    min_im: float
    period: Optional[float] = None
    fundamental_frequency: Optional[float] = None
    zero_crossings_re: list[float] = Field(..., description="Re[s(t)] 过零点序列")
    zero_crossings_im: list[float] = Field(..., description="Im[s(t)] 过零点序列（实信号为空）")


class SpectrumPeakModel(BaseModel):
    frequency: float
    magnitude: float
    description: str


class AnalyzeResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")  # 预留扩展字段（extensions.*）

    expression: str = Field(..., description="用户原始表达式")
    normalized_expression: str = Field(..., description="sympy 规范化后的表达式")
    signal_type: str = Field(..., description="real | complex")
    periodicity: str = Field(..., description="periodic | aperiodic | constant")
    period: Optional[float] = None
    fundamental_frequency: Optional[float] = None
    harmonics: list[HarmonicModel] = Field(..., description="谐波分解结果（非周期为空）")
    harmonics_method: str = Field(..., description="symbolic | numeric | none")
    harmonics_convention: str = Field(..., description="幅度/相位约定的文字说明")
    metrics: MetricsModel
    spectrum: SpectrumModel
    spectrum_summary: list[SpectrumPeakModel] = Field(..., description="主要谱峰（≤5 个）")
    spectrum_note: str = Field(..., description="频谱简要说明（纯文本）")
    time: TimeSeriesModel
    parameters_used: dict = Field(..., description="实际采用的采样参数")
    warnings: list[str] = Field(default_factory=list)
    extensions: dict = Field(default_factory=dict, description="扩展模块输出（预留）")


# ---------------------------------------------------------------------------
# 通信链路仿真（chain）请求模型
# ---------------------------------------------------------------------------
class ChainSignal(BaseModel):
    """全局信号总线的传输格式。"""
    t: list[float]
    re: list[float]
    im: list[float]
    sampling_rate: float = Field(..., gt=0, description="采样率（Hz）")


class ChainNoiseRequest(BaseModel):
    signal: ChainSignal
    snr_db: float = Field(20.0, description="信噪比（dB）")


class ChainFilterRequest(BaseModel):
    signal: ChainSignal
    filter_type: str = Field("lowpass", description="lowpass/highpass/bandpass/bandstop")
    kind: str = Field("iir", description="iir/fir")
    order: int = Field(8, ge=1, le=64)
    cutoff1: float = Field(..., gt=0, description="截止频率 1（Hz）")
    cutoff2: Optional[float] = Field(None, description="截止频率 2（带通/带阻，Hz）")


class ChainModulateRequest(BaseModel):
    modulation: str = Field("qpsk")
    symbol_rate: float = Field(1000.0, gt=0)
    samples_per_symbol: int = Field(32, ge=2)
    freq_offset: float = Field(0.0)
    phase_offset: float = Field(0.0)
    num_symbols: int = Field(64, ge=1, le=50000)
    rolloff: float = Field(0.35, ge=0, le=1)
    seed: int = Field(42)


class ChainTap(BaseModel):
    delay_s: float = Field(0.0, ge=0)
    gain_re: float = Field(1.0)
    gain_im: float = Field(0.0)
    doppler_hz: float = Field(0.0)


class ChainChannelRequest(BaseModel):
    signal: ChainSignal
    taps: list[ChainTap] = Field(..., min_length=1, max_length=8)
    k_factor: float = Field(0.0, ge=0)


class ChainMatrixRequest(BaseModel):
    matrix: list[list[float]] = Field(..., description="二维矩阵")
    vector: Optional[list[float]] = Field(None, description="测试向量（3 维）")
    signal: Optional[ChainSignal] = Field(None)
    apply_to_bus: bool = Field(False, description="将矩阵作用于总线信号")


class ChainTransformerRequest(BaseModel):
    d: int = Field(16, ge=2, le=256)
    q: Optional[list[list[float]]] = Field(None)
    k: Optional[list[list[float]]] = Field(None)
    v: Optional[list[list[float]]] = Field(None)
    signal: Optional[ChainSignal] = Field(None)
    from_bus: bool = Field(False)


class ChainAnalyzeRequest(BaseModel):
    signal: ChainSignal
    max_harmonics: int = Field(200, ge=10, le=2000)


class ChainPresetRequest(BaseModel):
    name: str
    params: dict = Field(default_factory=dict)


class ChainCompareRequest(BaseModel):
    a: ChainSignal
    b: ChainSignal

