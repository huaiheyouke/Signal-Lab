// 根组件：左侧输入面板 / 右侧图形 Tab / 底部文本报告
import { runAnalysis } from '../api.js';

export default {
  data() {
    return { result: null, error: null, busy: false };
  },
  methods: {
    // 用户点击「运行分析」：调用后端，成功后刷新全部图形与报告
    async onAnalyze(payload) {
      this.busy = true;
      this.error = null;
      try {
        this.result = await runAnalysis(payload);
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [], code: err.code || '' };
        this.result = null;
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="layout">
    <aside class="left">
      <header class="brand">
        <h1>SignalLab-flash <span>信号分析简易工具</span></h1>
      </header>
      <input-panel :busy="busy" :error="error" @analyze="onAnalyze"></input-panel>
    </aside>
    <main class="main">
      <plot-tabs :result="result" :busy="busy"></plot-tabs>
    </main>
    <section class="report">
      <report-panel :result="result" :error="error" :busy="busy"></report-panel>
    </section>
  </div>
  `,
};
