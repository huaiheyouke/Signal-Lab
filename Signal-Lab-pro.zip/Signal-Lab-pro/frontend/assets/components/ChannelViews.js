// Tab3 视图：冲激响应 + 时延-增益分布 + H 热力图 + 总线监视器
import { bus } from '../bus.js';
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  data() { return { bus }; },  // ★ watch 'bus.moduleResult.channel' 需要实例属性 bus
  mounted() { this.render(); },
  watch: {
    'bus.moduleResult.channel': { deep: true, handler() { this.render(); } },
  },
  beforeUnmount() {
    for (const ref of ['cir', 'dg', 'hm']) if (this.$refs[ref]) Plotly.purge(this.$refs[ref]);
  },
  computed: {
    ch() { return bus.moduleResult.channel || null; },
  },
  methods: {
    render() {
      const ch = this.ch;
      if (!ch || !ch.visuals) return;
      const v = ch.visuals;
      const base = { paper_bgcolor: '#fff', plot_bgcolor: '#fff' };

      // 冲激响应（幅度条 + 相位标注）
      Plotly.react(this.$refs.cir, [{
        x: v.cir.map(t => t.delay_s * 1000), y: v.cir.map(t => t.magnitude),
        type: 'bar', marker: { color: '#2563eb' },
        customdata: v.cir.map(t => t.phase_deg),
        text: v.cir.map(t => t.phase_deg.toFixed(0) + '°'),
        textposition: 'outside',
        hovertemplate: 'τ=%{x:.4g} ms<br>|h|=%{y:.4g}<br>相位=%{customdata:.1f}°<extra></extra>',
      }], Object.assign({
        title: '信道冲激响应（幅度 + 相位标注）',
        xaxis: { title: '时延 τ (ms)' }, yaxis: { title: '|h(τ)|' },
        margin: { t: 44, l: 56, r: 16, b: 46 },
      }, base), PLOTLY_CONFIG);

      // 时延-增益分布
      Plotly.react(this.$refs.dg, [{
        x: v.delay_gain.map(t => t.delay_s * 1000), y: v.delay_gain.map(t => t.magnitude),
        type: 'scatter', mode: 'markers+lines',
        marker: { size: 10, color: '#f97316' }, line: { width: 1, dash: 'dot', color: '#fdba74' },
        hovertemplate: 'τ=%{x:.4g} ms<br>增益=%{y:.4g}<extra></extra>',
      }], Object.assign({
        title: '时延-增益分布（功率延迟谱）',
        xaxis: { title: '时延 τ (ms)' }, yaxis: { title: '路径增益' },
        margin: { t: 44, l: 56, r: 16, b: 46 },
      }, base), PLOTLY_CONFIG);

      // H 矩阵热力图（128×128 幅度）
      Plotly.react(this.$refs.hm, [{
        z: v.H, type: 'heatmap', colorscale: 'Viridis',
        colorbar: { title: '|H|' },
        hovertemplate: '行=%{y}<br>列=%{x}<br>|H|=%{z:.4g}<extra></extra>',
      }], Object.assign({
        title: '离散等效卷积矩阵 H（' + v.H_size + '×' + v.H_size + '，Toeplitz 结构）',
        xaxis: { title: '列' }, yaxis: { title: '行', autorange: 'reversed' },
        margin: { t: 44, l: 56, r: 60, b: 46 },
      }, base), PLOTLY_CONFIG);
    },
  },
  template: `
  <div class="chain-views">
    <div v-if="ch" class="info-box">
      信道：{{ ch.visuals.cir.length }} 径 · 莱斯 K={{ ch.visuals.k_factor }} · 直射增益 g₀={{ ch.info.los_gain.toFixed(4) }} ·
      散射功率 {{ ch.info.scatter_power.toFixed(4) }} · H 矩阵 {{ ch.info.H_size }}×{{ ch.info.H_size }}（已可导入矩阵工作台）
    </div>
    <float-card v-if="ch" title="信道冲激响应（幅度 + 相位）" export-name="cir.png"
      help="多径信道冲激响应：每个柱代表一条路径，高度为路径增益幅度，柱顶标注相位。反映信道对信号的多径扩展结构。">
      <div ref="cir" class="plot"></div>
    </float-card>
    <float-card v-if="ch" title="时延-增益分布（功率延迟谱）" export-name="delay_gain.png"
      help="各路径时延与增益分布。时延扩展越大，频率选择性衰落越明显（可对比单音与宽带信号经过信道后的差异）。">
      <div ref="dg" class="plot"></div>
    </float-card>
    <float-card v-if="ch" title="信道矩阵 H 热力图（Toeplitz）" export-name="channel_H.png"
      help="离散等效卷积矩阵 H（时不变近似，忽略多普勒）。对角带状结构即卷积特征；可在矩阵算子工作台导入分析其秩与条件数。">
      <div ref="hm" class="plot"></div>
    </float-card>
    <bus-monitor></bus-monitor>
  </div>
  `,
};
