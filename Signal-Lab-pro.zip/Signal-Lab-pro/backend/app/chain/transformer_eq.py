"""Transformer 等效信道模块（数学等效仿真）。

重要说明（界面需展示）：Attention 算子类比为时变信道 ——
等效信道矩阵 H_eq = softmax(Q @ Kᵀ / √d) 由输入 Q、K 决定，
输入变化，信道随之改变（与时不变的传统多径信道形成对比）。

输入：
  - d：注意力维度；
  - 模式一 from_bus=False：手动填入 Q、K、V（d×d 矩阵）；
  - 模式二 from_bus=True：取总线信号前 d×d 点重排为 d×d 矩阵 X，
    Q = K = V = X（自注意力）。
运算逻辑：
  H_eq = softmax(Q @ Kᵀ / √d)         （按行 softmax）
  Y    = H_eq @ V                     （等效信道畸变后的 token 序列）
输出对象：
  - visuals.heatmap：H_eq 注意力权重热力图；
  - visuals.eig_spectrum：H_eq 特征值谱（复用矩阵工作台绘图组件）；
  - signal：Y 重排回一维信号写回全局总线（from_bus 模式时）。
"""
from __future__ import annotations

import numpy as np

from ..errors import AnalysisError


def _softmax_rows(X: np.ndarray) -> np.ndarray:
    e = np.exp(X - X.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


def _parse_square(data, name: str, d: int) -> np.ndarray:
    try:
        M = np.asarray(data, dtype=float)
    except (TypeError, ValueError) as exc:
        raise AnalysisError(f"{name} 矩阵格式无法解析", ["请输入数值嵌套列表"], "bad_matrix") from exc
    if M.shape != (d, d):
        raise AnalysisError(f"{name} 矩阵必须为 {d}×{d}", ["请检查矩阵尺寸与维度 d 一致"], "bad_matrix")
    return M


def run_transformer(d: int, q_data, k_data, v_data, signal=None, from_bus: bool = False) -> dict:
    """执行 Transformer 等效信道仿真。"""
    d = int(d)
    if not (2 <= d <= 256):
        raise AnalysisError("注意力维度 d 必须在 2 ~ 256 之间", [], "bad_d")

    if from_bus:
        if signal is None:
            raise AnalysisError("总线为空：请先载入信号", [], "empty_bus")
        n = len(signal["t"])
        if n < d * d:
            raise AnalysisError(f"总线信号点数 {n} 不足 d×d = {d * d}",
                                ["请增大窗口/采样率，或减小 d"], "bus_too_short")
        X = np.asarray(signal["re"], dtype=float)[: d * d].reshape(d, d)             + 1j * np.asarray(signal["im"], dtype=float)[: d * d].reshape(d, d)
        # 复信号取实部构造注意力（教学简化，界面说明中注明）
        Xr = X.real
        Q = K = V = Xr
        source_note = f"自注意力模式：Q=K=V=总线信号前 {d}×{d} 点重排（取实部）。"
    else:
        Q = _parse_square(q_data, "Q", d)
        K = _parse_square(k_data, "K", d)
        V = _parse_square(v_data, "V", d)
        source_note = "手动矩阵模式：H_eq 由输入 Q、K 决定，输入变化信道随之改变。"

    H_eq = _softmax_rows(Q @ K.T / np.sqrt(d))       # 等效信道（注意力权重）
    Y = H_eq @ V                                     # 等效信道输出（token 序列）

    ev = np.linalg.eigvals(H_eq)
    visuals = {
        "heatmap": [[float(x) for x in row] for row in H_eq],
        "eig_spectrum": [
            {"index": i + 1, "magnitude": float(m)}
            for i, m in enumerate(sorted([float(abs(x)) for x in ev], reverse=True))
        ],
        "d": d,
    }
    out_signal = None
    if from_bus:
        y = Y.ravel()
        t = np.asarray(signal["t"], dtype=float)[: d * d]
        out_signal = {
            "t": [float(x) for x in t],
            "re": [float(x) for x in y],
            "im": [float(x) for x in np.zeros_like(y)],
            "sampling_rate": float(signal["sampling_rate"]),
            "t_start": 0.0, "t_end": float(t[-1]), "n_points": int(d * d),
        }
    info = {
        "d": d, "mode": "from_bus" if from_bus else "manual",
        "source_note": source_note,
        "note": "H_eq = softmax(QKᵀ/√d)：Attention 算子类比为时变信道，权重随输入变化。",
    }
    return {"visuals": visuals, "signal": out_signal, "info": info}
