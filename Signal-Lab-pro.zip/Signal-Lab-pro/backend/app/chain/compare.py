"""A/B 快照对比模块。

输入：两组总线信号快照 {a, b}（可长度不同）。
运算逻辑：截取共同长度，计算 MSE、SNR(dB)、相关系数（时域）。
输出对象：{mse, snr_db, correlation, n_compared, note}。
"""
from __future__ import annotations

import numpy as np


def compare_signals(a: dict, b: dict) -> dict:
    sa = np.asarray(a["re"], dtype=float) + 1j * np.asarray(a["im"], dtype=float)
    sb = np.asarray(b["re"], dtype=float) + 1j * np.asarray(b["im"], dtype=float)
    n = min(len(sa), len(sb))
    if n < 2:
        return {"mse": None, "snr_db": None, "correlation": None, "n_compared": 0,
                "note": "两个快照长度过短，无法对比。"}
    x, y = sa[:n], sb[:n]
    err = x - y
    mse = float(np.mean(np.abs(err) ** 2))
    power = float(np.mean(np.abs(x) ** 2))
    snr_db = float(10 * np.log10(power / (mse + 1e-30))) if mse > 1e-30 else float("inf")
    corr = float(abs(np.vdot(x, y)) / (np.linalg.norm(x) * np.linalg.norm(y) + 1e-30))
    note = f"共同长度 {n} 点。MSE 越小 / SNR 越高 / 相关系数越接近 1，两信号越相似。"
    return {"mse": mse, "snr_db": snr_db, "correlation": corr, "n_compared": int(n), "note": note}
