"""无服务器冒烟测试：直接调用分析流水线验证核心算法与错误处理。

运行：python backend/tests/smoke_test.py
"""
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from backend.app.errors import AnalysisError          # noqa: E402
from backend.app.pipeline import analyze              # noqa: E402
from backend.app.schemas import AnalyzeRequest        # noqa: E402

# (表达式, 信号类型, 周期性, 基频, 谐波数下限, 说明)
CASES = [
    ("cos(2*pi*100*t)", "real", "periodic", 100.0, 1, "单音余弦（符号路径）"),
    ("exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)", "complex", "periodic", 50.0, 2, "双音复信号（纯复指数=单边谱）"),
    ("cos(2*pi*50*t)+exp(1j*2*pi*150*t)", "complex", "periodic", 50.0, 3, "实余弦+复指数（k=-1,+1,+3）"),
    ("sign(sin(2*pi*100*t))", "real", "periodic", 100.0, 1, "方波（数值路径）"),
    ("cos(2*pi*100*t)+cos(2*pi*150*t)", "real", "periodic", 50.0, 2, "双音实信号"),
    ("abs(sin(2*pi*50*t))", "real", "periodic", 100.0, 1, "全波整流（数值路径）"),
    ("exp(-10*t)*cos(2*pi*50*t)", "real", "aperiodic", None, 0, "衰减振荡"),
    ("cos(2*pi*100*t)+cos(2*sqrt(2)*pi*100*t)", "real", "aperiodic", None, 0, "不可通约频率"),
    ("t**2", "real", "aperiodic", None, 0, "多项式"),
    ("5", "real", "constant", None, 0, "常数信号"),
]

ERROR_CASES = [
    ("cos(2*pi*100*t", "parse_error"),      # 括号不匹配
    ("x+1", "unknown_symbol"),              # 未知符号
    ("1/0", "parse_error"),                 # 除零
    ("", "empty_expression"),               # 空表达式
]


def approx(a, b, tol=1e-4):
    return abs(a - b) <= tol * max(1.0, abs(b))


def run_case(expr, sig_type, per_type, f0, min_h, note):
    r = analyze(AnalyzeRequest(expression=expr))
    assert r["signal_type"] == sig_type, f"{expr}: signal_type={r['signal_type']} != {sig_type}"
    assert r["periodicity"] == per_type, f"{expr}: periodicity={r['periodicity']} != {per_type}"
    if f0 is not None:
        # 数值路径（方波等）精度 ~0.1%，容差 1e-3；符号路径为精确值
        assert approx(r["fundamental_frequency"], f0, 1e-3), f"{expr}: f0={r['fundamental_frequency']} != {f0}"
    assert len(r["harmonics"]) >= min_h, f"{expr}: harmonics={len(r['harmonics'])} < {min_h}"
    assert len(r["time"]["t"]) == len(r["time"]["real"]) == len(r["time"]["imag"]) > 0
    assert len(r["spectrum"]["frequency"]) == len(r["spectrum"]["magnitude"]) > 0
    assert r["metrics"]["peak"] >= 0 and r["metrics"]["rms"] >= 0
    print(f"[PASS] {note}: {expr}")
    return r


def run_error_case(expr, code):
    try:
        analyze(AnalyzeRequest(expression=expr))
    except AnalysisError as exc:
        assert exc.code == code, f"{expr}: code={exc.code} != {code}"
        assert exc.message and exc.suggestions
        print(f"[PASS] 错误处理 {code}: {expr!r} -> {exc.message}")
        return
    raise AssertionError(f"{expr}: 应当抛出 AnalysisError({code})")


def main():
    print("=" * 64)
    print("SignalLab Pro 后端冒烟测试")
    print("=" * 64)
    results = {}
    for case in CASES:
        results[case[0]] = run_case(*case)

    # 精度校验：余弦谐波 A_1=1.0, φ_1=0
    r = results["cos(2*pi*100*t)"]
    k1 = [h for h in r["harmonics"] if h["k"] == 1][0]
    assert approx(k1["amplitude"], 1.0, 1e-6), f"A_1={k1['amplitude']}"
    assert approx(k1["phase"], 0.0, 1e-6), f"phi_1={k1['phase']}"
    print("[PASS] 余弦谐波 A_1=1.0, φ_1=0")

    # 纯复指数：只有正频率 k=1（A=1）与 k=3（A=0.5），负频率为 0
    r = results["exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)"]
    hs = {h["k"]: h for h in r["harmonics"]}
    assert approx(hs[1]["amplitude"], 1.0), hs
    assert approx(hs[3]["amplitude"], 0.5), hs
    assert -1 not in hs and -3 not in hs, hs
    print("[PASS] 纯复指数信号：单边谐波 k=1/3 幅度 1.0/0.5，无负频率")

    # 实余弦 + 复指数：k=-1（A=0.5）、k=+1（A=0.5）、k=+3（A=1.0）
    r = results["cos(2*pi*50*t)+exp(1j*2*pi*150*t)"]
    hs = {h["k"]: h for h in r["harmonics"]}
    assert approx(hs[-1]["amplitude"], 0.5) and approx(hs[1]["amplitude"], 0.5), hs
    assert approx(hs[3]["amplitude"], 1.0), hs
    assert set(hs) == {-1, 1, 3}, hs
    print("[PASS] 复信号双边谐波 k=-1/+1/+3 幅度正确")

    # 方波：基波幅度 4/π
    r = results["sign(sin(2*pi*100*t))"]
    a1 = next(h["amplitude"] for h in r["harmonics"] if h["k"] == 1)
    assert approx(a1, 4 / math.pi, 1e-2), f"方波 A_1={a1}"
    print("[PASS] 方波基波幅度 ≈ 4/π")

    # 低采样率必须被拒绝
    try:
        analyze(AnalyzeRequest(expression="cos(2*pi*100*t)", sampling_rate=10.0))
    except AnalysisError as exc:
        assert exc.code == "low_sampling_rate", exc.code
        print("[PASS] 低采样率被拒绝 (low_sampling_rate)")
    else:
        raise AssertionError("低采样率应当报错")

    # 用户指定参数的校验路径
    r = analyze(AnalyzeRequest(expression="cos(2*pi*100*t)",
                               t_start=0.0, t_end=0.05, sampling_rate=2000.0))
    assert r["time"]["n_points"] == 101, r["time"]["n_points"]
    print("[PASS] 用户指定参数生效 (N=101)")

    for expr, code in ERROR_CASES:
        run_error_case(expr, code)

    print("=" * 64)
    print("全部冒烟测试通过 ✔")
    print("=" * 64)


if __name__ == "__main__":
    main()
