// Tab1 预处理面板：噪声（AWGN）+ 数字滤波（FIR/IIR）—— 可独立开关
// 输入：全局总线信号；输出：处理后的信号写回总线，全部视图自动刷新。
import { bus, loadSignal, signalToPayload, signalFromResponse } from '../bus.js';
import { chainCall } from '../api.js';

export default {
  data() {
    return {
      bus,                     // ★ 模板使用了 bus.signal：必须挂到实例（Vue3 模板作用域）
      noiseEnabled: true, snrDb: 20,
      filterEnabled: false,
      filterType: 'lowpass', filterKind: 'iir', filterOrder: 8,
      cutoff1: 150, cutoff2: 300,
      error: null, busy: false,
    };
  },
  methods: {
    async apply() {
      this.error = null;
      if (!bus.signal) { this.error = { message: '总线为空：请先在「基础信号分析」运行一个信号或载入预设。', suggestions: [] }; return; }
      this.busy = true;
      try {
        let current = bus.signal;
        const labelParts = [];
        if (this.noiseEnabled) {
          const r = await chainCall('/api/chain/noise', { signal: signalToPayload(current), snr_db: this.snrDb });
          current = signalFromResponse(r.signal);
          bus.moduleResult.noise = r;
          labelParts.push('AWGN ' + this.snrDb + 'dB');
        }
        if (this.filterEnabled) {
          const r = await chainCall('/api/chain/filter', {
            signal: signalToPayload(current),
            filter_type: this.filterType, kind: this.filterKind, order: this.filterOrder,
            cutoff1: this.cutoff1, cutoff2: this.filterType === 'bandpass' || this.filterType === 'bandstop' ? this.cutoff2 : null,
          });
          current = signalFromResponse(r.signal);
          bus.moduleResult.filter = r;
          labelParts.push(this.filterKind.toUpperCase() + ' ' + this.filterType);
        }
        await loadSignal(current, '预处理：' + (labelParts.join(' + ') || '（未启用任何处理）'));
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="panel">
    <div class="panel-title-row"><h2>① 预处理：噪声与滤波</h2>
      <help-btn title="噪声与滤波（预处理）" text="对全局总线信号依次执行【加噪声 → 滤波】，两个处理可分别开关。
1. 噪声：勾选启用后按 SNR(dB) 叠加复高斯白噪声（功率按信号平均功率归一）；
2. 滤波：FIR（窗函数）/ IIR（Butterworth 零相位），低通/高通/带通/带阻，截止频率需小于 fs/2。
点【应用预处理】后处理结果写回全局总线，全部视图同步刷新；切回基础分析 Tab 可查看滤波前后的波形与频谱。"></help-btn>
    </div>
    <p class="panel-desc">对总线信号依次执行「加噪声 → 滤波」，可分别开关。处理结果写回总线，全部视图自动刷新。</p>

    <div class="switch-row">
      <label class="switch"><input type="checkbox" v-model="noiseEnabled" /> 启用高斯白噪声</label>
    </div>
    <div class="field-inline" :class="{disabled: !noiseEnabled}">
      <label>SNR (dB)</label>
      <input v-model.number="snrDb" type="number" step="1" min="0" max="60" :disabled="!noiseEnabled" />
    </div>

    <div class="switch-row">
      <label class="switch"><input type="checkbox" v-model="filterEnabled" /> 启用数字滤波</label>
    </div>
    <div class="param-grid" :class="{disabled: !filterEnabled}">
      <div class="field-inline"><label>类型</label>
        <select v-model="filterType" :disabled="!filterEnabled">
          <option value="lowpass">低通</option>
          <option value="highpass">高通</option>
          <option value="bandpass">带通</option>
          <option value="bandstop">带阻</option>
        </select>
      </div>
      <div class="field-inline"><label>实现</label>
        <select v-model="filterKind" :disabled="!filterEnabled">
          <option value="iir">IIR (Butterworth)</option>
          <option value="fir">FIR (窗函数)</option>
        </select>
      </div>
      <div class="field-inline"><label>阶数</label>
        <input v-model.number="filterOrder" type="number" min="1" max="64" :disabled="!filterEnabled" />
      </div>
      <div class="field-inline"><label>截止 f1 (Hz)</label>
        <input v-model.number="cutoff1" type="number" step="any" :disabled="!filterEnabled" />
      </div>
      <div v-if="filterType==='bandpass'||filterType==='bandstop'" class="field-inline"><label>截止 f2 (Hz)</label>
        <input v-model.number="cutoff2" type="number" step="any" :disabled="!filterEnabled" />
      </div>
    </div>

    <button class="primary" :disabled="busy || !bus.signal" @click="apply">{{ busy ? '处理中…' : '▶ 应用预处理' }}</button>
    <div v-if="error" class="error-box"><div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions.length"><li v-for="(s,i) in error.suggestions" :key="i">{{ s }}</li></ul>
    </div>
  </div>
  `,
};
