"""【预留】信道建模扩展骨架。

启用方式（在 extensions/__init__.py 中 import 并注册）：
    from .channel_model import AWGNChannelExtension
    register_extension(AWGNChannelExtension())

设计说明：
- 在 on_end 阶段对采样序列 s 施加信道效应（加性噪声 / 多径卷积）；
- 输出写入 ctx["extras"]["channel"]，随响应 extensions.channel 返回前端；
- 前端可在「扩展渲染区」展示信道参数与加噪后的波形。
"""
from __future__ import annotations

import numpy as np

from .base import AnalysisExtension


class AWGNChannelExtension(AnalysisExtension):
    """加性高斯白噪声信道（示例扩展：演示扩展接口的完整用法）。"""

    name = "awgn_channel"
    description = "加性高斯白噪声信道（示例：展示扩展接口用法）"

    def __init__(self, snr_db: float = 30.0):
        self.snr_db = snr_db

    def on_end(self, ctx: dict) -> None:
        s = ctx.get("s")  # 原始采样序列（complex ndarray）
        if s is None:
            return
        rng = np.random.default_rng(0)
        noise = rng.normal(0.0, 1.0, s.shape)
        signal_power = float(np.mean(np.abs(s) ** 2))
        noise = noise * np.sqrt(signal_power / (10.0 ** (self.snr_db / 10.0)))
        ctx.setdefault("extras", {})["channel"] = {
            "snr_db": self.snr_db,
            "noise_power": float(np.mean(np.abs(noise) ** 2)),
            "description": "示例扩展：AWGN 信道。前端可在此展示加噪波形 / 星座图。",
        }
