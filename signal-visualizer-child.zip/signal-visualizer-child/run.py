"""一键启动脚本（本地单机运行，无需联网）。

用法：
    python run.py                 # 启动并自动打开浏览器
    python run.py --port 9000     # 指定端口
    python run.py --no-browser    # 不自动打开浏览器
"""
import argparse
import sys
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))  # 保证 backend 包可从项目根目录导入

VENDOR_DIR = ROOT / "frontend" / "vendor"


def _check_vendor_files() -> None:
    """前端离线依赖检查（vue / plotly 已随仓库提供，缺省时给出引导）。"""
    missing = [f for f in ("vue.global.prod.js", "plotly.min.js") if not (VENDOR_DIR / f).is_file()]
    if missing:
        print("[警告] 前端离线依赖缺失: " + ", ".join(missing))
        print("       请先运行一次: python scripts/fetch_frontend_libs.py（需要联网一次）")
        print("       缺失时页面会给出引导提示，后端 API 不受影响。")


def main() -> None:
    parser = argparse.ArgumentParser(description="通信信号分析可视化教学工具（本地单机版）")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    parser.add_argument("--port", type=int, default=8000, help="监听端口（默认 8000）")
    parser.add_argument("--no-browser", action="store_true", help="启动后不自动打开浏览器")
    args = parser.parse_args()

    _check_vendor_files()
    url = f"http://{args.host}:{args.port}"
    print("=" * 60)
    print("  通信信号分析可视化教学工具  SignalLab")
    print(f"  访问地址: {url}")
    print("  按 Ctrl+C 停止服务")
    print("=" * 60)

    if not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    import uvicorn
    uvicorn.run("backend.app.main:app", host=args.host, port=args.port, reload=False)


if __name__ == "__main__":
    main()
