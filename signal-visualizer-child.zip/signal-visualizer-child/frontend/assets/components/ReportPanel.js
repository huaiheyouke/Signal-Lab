// 文本分析报告面板：信号表达式 / 类型 / 谐波表 / 示波器指标 / 采样参数 / 频谱说明
import { fmt, fmtHz } from '../utils.js';

export default {
  props: ['result', 'error', 'busy'],
  data() { return { copied: false }; },
  computed: {
    html() { return this.result ? this.buildHtml(this.result) : ''; },
    plain() { return this.result ? this.buildPlain(this.result) : ''; },
  },
  methods: {
    esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    },
    zcSummary(list) {
      if (!list || !list.length) return '无';
      const head = list.slice(0, 8).map(v => fmt(v)).join(', ');
      return head + (list.length > 8 ? ' …' : '') + '（共 ' + list.length + ' 个）';
    },
    buildHtml(r) {
      const h = [];
      const m = r.metrics;

      // ① 表达式
      h.push('<section><h3>① 信号表达式</h3>');
      h.push('<p>原始：<code>' + this.esc(r.expression) + '</code></p>');
      if (r.normalized_expression && r.normalized_expression !== r.expression) {
        h.push('<p>规范化：<code>' + this.esc(r.normalized_expression) + '</code></p>');
      }
      h.push('</section>');

      // ② 信号类型
      h.push('<section><h3>② 信号类型</h3>');
      const kind = r.signal_type === 'complex' ? '复信号' : '实信号';
      const perMap = { periodic: '周期信号', aperiodic: '非周期信号', constant: '常数信号' };
      h.push('<p>' + kind + ' / ' + (perMap[r.periodicity] || r.periodicity));
      if (r.periodicity === 'periodic' && r.period != null) {
        h.push('；周期 T = ' + fmt(r.period) + ' s；基频 f₀ = ' + fmtHz(r.fundamental_frequency) + ' Hz');
      }
      h.push('</p></section>');

      // ③ 谐波分解
      h.push('<section><h3>③ 谐波分解（复数形式 s(t)=Σ A_k·e^{j(2π f_k t + φ_k)}）</h3>');
      if (r.periodicity === 'periodic' && r.harmonics.length) {
        const method = { symbolic: '符号精确展开（rewrite 复数指数）', numeric: '数值积分（每周期 FFT）' }[r.harmonics_method] || r.harmonics_method;
        h.push('<p>分解方法：' + method + '；<span title="' + this.esc(r.harmonics_convention) + '">' + this.esc(r.harmonics_convention) + '</span>。共 ' + r.harmonics.length + ' 项：</p>');
        h.push('<table><thead><tr><th>k</th><th>f_k (Hz)</th><th>A_k</th><th>φ_k (rad)</th><th>φ_k (°)</th><th>c_k = A_k·e^{jφ_k}</th></tr></thead><tbody>');
        for (const hh of r.harmonics) {
          const deg = (hh.phase * 180 / Math.PI).toFixed(1);
          const sign = hh.coeff_im >= 0 ? '+' : '−';
          h.push('<tr><td>' + hh.k + '</td><td>' + fmt(hh.frequency) + '</td><td>' + fmt(hh.amplitude)
            + '</td><td>' + fmt(hh.phase) + '</td><td>' + deg + '°</td><td>'
            + fmt(hh.coeff_re) + ' ' + sign + ' ' + fmt(Math.abs(hh.coeff_im)) + 'j</td></tr>');
        }
        h.push('</tbody></table>');
      } else if (r.periodicity === 'periodic') {
        h.push('<p>周期信号，未分解出非零谐波（纯直流）。</p>');
      } else {
        h.push('<p>非周期信号：跳过傅里叶级数分解，直接进行数值频谱分析（FFT）。</p>');
      }
      h.push('</section>');

      // ④ 示波器指标
      h.push('<section><h3>④ 示波器测量指标</h3><table class="metrics">');
      const rows = [
        ['直流分量', fmt(m.dc_re) + (r.signal_type === 'complex' ? ' + ' + fmt(m.dc_im) + ' j' : '')],
        ['峰值 max|s(t)|', fmt(m.peak)],
        ['有效值 RMS', fmt(m.rms)],
        ['最大值', 'Re: ' + fmt(m.max_re) + (r.signal_type === 'complex' ? '，Im: ' + fmt(m.max_im) : '')],
        ['最小值', 'Re: ' + fmt(m.min_re) + (r.signal_type === 'complex' ? '，Im: ' + fmt(m.min_im) : '')],
      ];
      if (r.periodicity === 'periodic' && m.period != null) {
        rows.push(['周期 T', fmt(m.period) + ' s']);
        rows.push(['基频 f₀', fmtHz(m.fundamental_frequency) + ' Hz']);
      }
      rows.push(['过零点 (Re)', this.zcSummary(m.zero_crossings_re)]);
      if (r.signal_type === 'complex') rows.push(['过零点 (Im)', this.zcSummary(m.zero_crossings_im)]);
      for (const [k, v] of rows) h.push('<tr><td>' + k + '</td><td>' + v + '</td></tr>');
      h.push('</table></section>');

      // ⑤ 采样参数
      h.push('<section><h3>⑤ 采样参数（实际采用）</h3><table class="metrics">');
      const pu = r.parameters_used;
      h.push('<tr><td>时间窗口</td><td>[' + fmt(pu.t_start) + ', ' + fmt(pu.t_end) + '] s</td></tr>');
      h.push('<tr><td>采样率 fs</td><td>' + fmtHz(pu.sampling_rate) + ' Hz</td></tr>');
      h.push('<tr><td>采样点数 N</td><td>' + pu.n_points + '</td></tr>');
      h.push('<tr><td>频率分辨率 Δf</td><td>' + fmt(pu.frequency_resolution_hz) + ' Hz</td></tr>');
      h.push('</table></section>');

      // ⑥ 频谱说明
      h.push('<section><h3>⑥ 频谱简要说明</h3>');
      h.push('<p>' + this.esc(r.spectrum_note).replace(/\n/g, '<br/>') + '</p>');
      h.push('</section>');

      // 警告
      if (r.warnings && r.warnings.length) {
        h.push('<section class="warn"><h3>⚠ 提示</h3><ul>');
        for (const w of r.warnings) h.push('<li>' + this.esc(w) + '</li>');
        h.push('</ul></section>');
      }
      return h.join('');
    },
    buildPlain(r) {
      const L = [];
      L.push('══════════ 信号分析报告 ══════════');
      L.push('① 表达式: ' + r.expression + (r.normalized_expression && r.normalized_expression !== r.expression ? '  (规范化: ' + r.normalized_expression + ')' : ''));
      L.push('② 类型: ' + (r.signal_type === 'complex' ? '复信号' : '实信号') + ' / ' + (r.periodicity === 'periodic' ? '周期信号' : r.periodicity === 'constant' ? '常数信号' : '非周期信号'));
      if (r.periodicity === 'periodic' && r.period != null) L.push('   周期 T=' + fmt(r.period) + ' s, 基频 f0=' + fmtHz(r.fundamental_frequency) + ' Hz');
      if (r.periodicity === 'periodic' && r.harmonics.length) {
        L.push('③ 谐波分解 (' + r.harmonics.length + ' 项):');
        for (const hh of r.harmonics) L.push('   k=' + hh.k + '  f=' + fmt(hh.frequency) + ' Hz  A=' + fmt(hh.amplitude) + '  phi=' + fmt(hh.phase) + ' rad');
      } else {
        L.push('③ 谐波分解: 非周期信号，跳过傅里叶级数，直接数值频谱分析');
      }
      const m = r.metrics;
      L.push('④ 示波器指标: 直流=' + fmt(m.dc_re) + (r.signal_type === 'complex' ? '+' + fmt(m.dc_im) + 'j' : '')
        + '  峰值=' + fmt(m.peak) + '  RMS=' + fmt(m.rms) + '  最大=' + fmt(m.max_re) + '  最小=' + fmt(m.min_re)
        + '  过零点(Re)=' + m.zero_crossings_re.length + ' 个');
      const pu = r.parameters_used;
      L.push('⑤ 采样参数: 窗口=[' + fmt(pu.t_start) + ', ' + fmt(pu.t_end) + '] s  fs=' + fmtHz(pu.sampling_rate) + ' Hz  N=' + pu.n_points + '  df=' + fmt(pu.frequency_resolution_hz) + ' Hz');
      L.push('⑥ 频谱说明: ' + r.spectrum_note.replace(/\n/g, ' '));
      for (const w of (r.warnings || [])) L.push('⚠ ' + w);
      return L.join('\n');
    },
    copyPlain() {
      if (!this.result) return;
      navigator.clipboard.writeText(this.plain).then(() => {
        this.copied = true;
        setTimeout(() => { this.copied = false; }, 1500);
      }).catch(() => {});
    },
  },
  template: `
  <div class="report-panel">
    <div class="report-head">
      <span class="report-title">📄 文本分析报告</span>
      <button v-if="result" class="ghost small" @click="copyPlain">{{ copied ? '已复制 ✓' : '复制报告' }}</button>
    </div>
    <div class="report-body" v-if="result" v-html="html"></div>
    <div class="report-body empty" v-else-if="error">分析失败，请查看左侧的错误信息与修改建议。</div>
    <div class="report-body empty" v-else>{{ busy ? '正在分析…' : '运行分析后，完整分析报告将显示在这里。' }}</div>
  </div>
  `,
};
