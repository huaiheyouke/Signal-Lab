// 图5：复信号三维轨迹图
// 坐标轴严格定义（硬性约束，不可更改）：
//   X 轴 = t（时间）；Y 轴 = Re[s(t)]（实部）；Z 轴 = Im[s(t)]（虚部）
// 实信号虚部恒为 0，轨迹自动落在 X-Y 平面。
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  props: ['result'],
  data() { return { showXY: true, showXZ: false }; },
  mounted() { this.render(); },
  watch: {
    result: { deep: true, handler() { this.render(); } },
    showXY() { this.render(); },
    showXZ() { this.render(); },
  },
  beforeUnmount() { if (this.$refs.el) Plotly.purge(this.$refs.el); },
  methods: {
    render() {
      const r = this.result;
      if (!r || !r.time) return;
      const t = r.time.t, re = r.time.real, im = r.time.imag;
      const n = t.length;
      const s = Math.max(1, Math.floor(n / 8000));  // WebGL 线图降采样
      const X = [], Y = [], Z = [];
      for (let i = 0; i < n; i += s) { X.push(t[i]); Y.push(re[i]); Z.push(im[i]); }

      const traces = [{
        type: 'scatter3d', mode: 'lines',
        x: X, y: Y, z: Z,
        name: 's(t) 轨迹',
        line: { width: 5, color: X, colorscale: 'Viridis', showscale: false },  // 按时间着色
        hovertemplate: 't=%{x:.4g} s<br>Re[s(t)]=%{y:.4g}<br>Im[s(t)]=%{z:.4g}<extra></extra>',
      }];
      if (this.showXY) {  // 投影到 X-Y 平面（Z=0），即复平面轨迹
        traces.push({
          type: 'scatter3d', mode: 'lines', x: X, y: Y, z: X.map(() => 0),
          name: '投影 (X-Y 平面, Z=0)',
          line: { width: 2, color: 'rgba(148,163,184,0.7)', dash: 'dot' },
          hovertemplate: 't=%{x:.4g} s<br>Re=%{y:.4g}<extra></extra>',
        });
      }
      if (this.showXZ) {  // 投影到 X-Z 平面（Y=0）
        traces.push({
          type: 'scatter3d', mode: 'lines', x: X, y: X.map(() => 0), z: Z,
          name: '投影 (X-Z 平面, Y=0)',
          line: { width: 2, color: 'rgba(251,146,60,0.7)', dash: 'dot' },
          hovertemplate: 't=%{x:.4g} s<br>Im=%{z:.4g}<extra></extra>',
        });
      }

      const layout = {
        title: '图5 · 复信号三维轨迹（X=t, Y=Re[s(t)], Z=Im[s(t)]）',
        scene: {
          xaxis: { title: 't' },              // 硬性约束：X = t
          yaxis: { title: 'Re[s(t)]' },       // 硬性约束：Y = Re[s(t)]
          zaxis: { title: 'Im[s(t)]' },       // 硬性约束：Z = Im[s(t)]
          camera: { eye: { x: 1.7, y: 1.7, z: 0.9 } },
          aspectmode: 'auto',
        },
        margin: { l: 0, r: 0, t: 44, b: 0 },
      };
      Plotly.react(this.$refs.el, traces, layout, PLOTLY_CONFIG);
    },
  },
  template: `
  <div>
    <div class="check-row">
      <label><input type="checkbox" v-model="showXY" /> 显示 X-Y 平面投影（Z=0）</label>
      <label><input type="checkbox" v-model="showXZ" /> 显示 X-Z 平面投影（Y=0）</label>
    </div>
    <float-card title="图5 · 复信号三维轨迹（X=t, Y=Re[s(t)], Z=Im[s(t)]）" export-name="trajectory_3d.png"
      help="复信号随时间的空间轨迹。坐标轴严格定义：X=t（时间），Y=Re[s(t)]（实部），Z=Im[s(t)]（虚部）。
实信号虚部恒为 0，轨迹落在 X-Y 平面。可勾选平面投影观察；鼠标拖拽旋转视角、滚轮缩放。">
      <div ref="el" class="plot-tall"></div>
    </float-card>
    <div class="axis-note">
      坐标轴：X = t（时间），Y = Re[s(t)]（实部），Z = Im[s(t)]（虚部）。
      输入实信号时虚部恒为 0，轨迹落在 X-Y 平面（可用「X-Y 平面投影」观察）。
    </div>
  </div>
  `,
};
