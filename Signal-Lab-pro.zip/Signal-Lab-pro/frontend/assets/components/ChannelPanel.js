// Tab3 传统多径信道面板（瑞利 / 莱斯）
// 输入：总线信号；输出：信道畸变信号写回总线 + CIR/H 矩阵（可推送矩阵工作台）。
import { bus, loadSignal, signalToPayload, signalFromResponse } from '../bus.js';
import { chainCall } from '../api.js';

export default {
  data() {
    return {
      bus,                     // ★ 模板使用了 bus.signal：必须挂到实例（Vue3 模板作用域）
      kFactor: 0,
      taps: [
        { delay_s: 0.001, gain_re: 1.0, gain_im: 0.0, doppler_hz: 0.0 },
        { delay_s: 0.0025, gain_re: 0.6, gain_im: 0.0, doppler_hz: 8.0 },
      ],
      error: null, busy: false,
    };
  },
  methods: {
    addTap() { if (this.taps.length < 8) this.taps.push({ delay_s: 0.001, gain_re: 0.5, gain_im: 0.0, doppler_hz: 0.0 }); },
    removeTap(i) { if (this.taps.length > 1) this.taps.splice(i, 1); },
    async apply() {
      this.error = null;
      if (!bus.signal) { this.error = { message: '总线为空：请先载入信号。', suggestions: [] }; return; }
      this.busy = true;
      try {
        const r = await chainCall('/api/chain/channel', {
          signal: signalToPayload(bus.signal),
          taps: this.taps.map(t => ({ delay_s: t.delay_s, gain_re: t.gain_re, gain_im: t.gain_im, doppler_hz: t.doppler_hz })),
          k_factor: this.kFactor,
        });
        await loadSignal(signalFromResponse(r.signal),
          '多径信道：' + this.taps.length + ' 径' + (this.kFactor > 0 ? '（莱斯 K=' + this.kFactor + '）' : '（瑞利）'));
        bus.moduleResult.channel = r;
        bus.sharedH = { H: r.visuals.H, size: r.visuals.H_size };   // 供矩阵工作台导入
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="panel">
    <div class="panel-title-row"><h2>③ 传统多径信道（瑞利 / 莱斯）</h2>
      <help-btn title="传统多径信道" text="对总线信号施加时变多径衰落：y(t) = g0·x(t) + Σ gn·e^{j2πfdn·t}·x(t-τn)，功率已归一化（直射 g0=√(K/(K+1))，散射总功率 1/(K+1)）。
- 莱斯 K 因子：0=纯瑞利（无直射），K 越大直射分量越强；
- 每条路径：时延 τ（秒，须小于信号时长）、复增益（Re/Im）、多普勒频移（Hz）。
点【施加信道】后畸变信号写回总线；右侧显示冲激响应、时延-增益分布与信道矩阵 H；H 可到矩阵算子工作台导入分析。"></help-btn>
    </div>
    <p class="panel-desc">y(t) = g₀·x(t) + Σ gₙ·e^{j2πf_dn·t}·x(t−τₙ)，功率已归一化。
    输出畸变信号写回总线，并生成信道矩阵 H（供矩阵算子工作台调用）。</p>

    <div class="field-inline">
      <label>莱斯 K 因子（0 = 纯瑞利）</label>
      <input v-model.number="kFactor" type="number" min="0" step="0.5" />
    </div>

    <div class="tap-list">
      <div class="tap-row" v-for="(t, i) in taps" :key="i">
        <span class="tap-idx">径 {{ i + 1 }}</span>
        <label>时延 τ (s)</label><input v-model.number="t.delay_s" type="number" step="any" class="tap-input" />
        <label>增益 Re</label><input v-model.number="t.gain_re" type="number" step="any" class="tap-input" />
        <label>增益 Im</label><input v-model.number="t.gain_im" type="number" step="any" class="tap-input" />
        <label>多普勒 (Hz)</label><input v-model.number="t.doppler_hz" type="number" step="any" class="tap-input" />
        <button class="chip danger" @click="removeTap(i)" :disabled="taps.length<=1">✕</button>
      </div>
      <button class="chip" @click="addTap">＋ 添加路径</button>
    </div>

    <button class="primary" :disabled="busy || !bus.signal" @click="apply">{{ busy ? '信道仿真中…' : '▶ 施加信道' }}</button>
    <div v-if="error" class="error-box"><div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions.length"><li v-for="(s,i) in error.suggestions" :key="i">{{ s }}</li></ul>
    </div>
  </div>
  `,
};
