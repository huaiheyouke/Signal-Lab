"""示波器指标计算模块。

输出指标集合：直流分量、峰值、有效值、最大值、最小值；
周期信号附带周期、基频；过零点序列（线性插值）。
"""
from __future__ import annotations

import numpy as np

MAX_ZERO_CROSSINGS = 5000  # 过零点序列长度上限（保护 JSON 体积）


def _zero_crossings(t: np.ndarray, v: np.ndarray) -> list[float]:
    """线性插值求实序列 v 的过零点时刻（含恰好为 0 的点）。"""
    v = np.asarray(v, dtype=float)
    out: list[float] = []
    exact = np.where(v == 0.0)[0]
    for i in exact:                          # 恰好落在采样点上的零点
        out.append(float(t[i]))
    idx = np.where(np.diff(np.signbit(v)))[0]  # 相邻采样符号变化 -> 跨零
    for i in idx:
        dv = v[i + 1] - v[i]
        if dv != 0.0:
            out.append(float(t[i] - v[i] * (t[i + 1] - t[i]) / dv))
    out.sort()
    return out[:MAX_ZERO_CROSSINGS]


def compute_metrics(t: np.ndarray, s: np.ndarray, is_complex: bool,
                    period=None, fundamental=None) -> dict:
    """计算全部示波器指标。s 为复采样序列（实信号的虚部为 0）。"""
    s = np.asarray(s, dtype=complex)
    s_re = s.real
    s_im = s.imag

    dc = complex(np.mean(s))
    peak = float(np.max(np.abs(s)))
    rms = float(np.sqrt(np.mean(np.abs(s) ** 2)))

    # 最大值/最小值：复信号分别给出实部与虚部
    max_re, min_re = float(np.max(s_re)), float(np.min(s_re))
    max_im, min_im = float(np.max(s_im)), float(np.min(s_im))

    # 过零点：实信号看 s(t)；复信号分别看 Re 与 Im
    zc_re = _zero_crossings(t, s_re)
    zc_im = _zero_crossings(t, s_im) if is_complex else []

    return {
        "dc_re": float(dc.real),
        "dc_im": float(dc.imag),
        "peak": peak,
        "rms": rms,
        "max_re": max_re,
        "max_im": max_im,
        "min_re": min_re,
        "min_im": min_im,
        "period": float(period) if period else None,
        "fundamental_frequency": float(fundamental) if fundamental else None,
        "zero_crossings_re": zc_re,
        "zero_crossings_im": zc_im,
    }
