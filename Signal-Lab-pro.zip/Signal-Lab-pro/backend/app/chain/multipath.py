"""传统多径信道模块（瑞利 / 莱斯衰落）。

输入：总线信号 + 多径参数（每条：时延 τ、复增益 g、多普勒 f_d）+ 莱斯 K 因子。
运算逻辑：
  1. 功率归一化：直射分量（LOS）增益 g0 = sqrt(K/(K+1))；
     散射路径总功率 = 1/(K+1)，各路径复增益按比例归一化；
  2. 对每条路径：分数时延用线性插值实现 x(t-τ)，多普勒用 e^{j2π f_d t} 调制；
  3. y(t) = g0·x(t) + Σ g_n·e^{j2π f_dn t}·x(t-τ_n)。
输出对象：
  - signal：信道畸变后的复信号（写回全局总线）；
  - visuals.cir：离散冲激响应（时延-增益-相位-多普勒表）；
  - visuals.delay_gain：时延-增益分布（前端画图）；
  - visuals.H：时不变近似的离散等效卷积矩阵（Toeplitz，L×L），
    供矩阵算子工作台调用（H 忽略多普勒，仅刻画抽头时延结构）。
"""
from __future__ import annotations

import numpy as np

from ..errors import AnalysisError
from . import CHAIN_MAX_POINTS

MAX_TAPS = 8


def _interp_delay(x: np.ndarray, delay_samples: float) -> np.ndarray:
    """分数时延：线性插值实现 x(t-τ)。"""
    if delay_samples <= 0:
        return x
    idx = np.arange(len(x)) - delay_samples
    i0 = np.floor(idx).astype(int)
    frac = idx - i0
    valid = (i0 >= 0) & (i0 + 1 < len(x))
    out = np.zeros_like(x)
    i0c = np.clip(i0, 0, len(x) - 2)
    out[valid] = x[i0c[valid]] * (1.0 - frac[valid]) + x[i0c[valid] + 1] * frac[valid]
    return out


def apply_channel(signal: dict, taps: list[dict], k_factor: float) -> dict:
    """对总线信号施加多径时变信道。"""
    s = np.asarray(signal["re"], dtype=float) + 1j * np.asarray(signal["im"], dtype=float)
    n = len(s)
    if n < 4 or n > CHAIN_MAX_POINTS:
        raise AnalysisError(f"链路模式信号点数必须为 4 ~ {CHAIN_MAX_POINTS:,}（当前 {n}）",
                            ["请减小时间窗口或降低采样率"], "bad_chain_signal")
    fs = float(signal["sampling_rate"])
    duration = n / fs
    k = float(k_factor or 0.0)
    if k < 0 or k > 1000:
        raise AnalysisError("莱斯 K 因子必须在 0 ~ 1000 之间（0=纯瑞利）", [], "bad_k_factor")
    taps = list(taps or [])
    if not taps:
        raise AnalysisError("请至少配置一条多径路径", [], "no_taps")
    if len(taps) > MAX_TAPS:
        raise AnalysisError(f"多径数目最多 {MAX_TAPS} 条", [], "too_many_taps")

    t = np.arange(n) / fs
    # 归一化复增益
    gains = np.array([complex(tp.get("gain_re", 1.0), tp.get("gain_im", 0.0)) for tp in taps])
    delays = np.array([float(tp.get("delay_s", 0.0)) for tp in taps])
    dopplers = np.array([float(tp.get("doppler_hz", 0.0)) for tp in taps])
    if np.any(delays < 0) or np.any(delays >= duration):
        raise AnalysisError(f"路径时延必须位于 [0, {duration:g} s) 窗口内",
                            ["时延超过信号时长会导致无定义输出"], "bad_delay")
    if np.any(~np.isfinite(gains)) or np.all(np.abs(gains) < 1e-12):
        raise AnalysisError("路径复增益必须为非零有限值", [], "bad_gain")

    # 功率归一化（直射 + 散射）
    g_los = np.sqrt(k / (k + 1.0)) if k > 0 else 0.0
    p_scatter = 1.0 / (k + 1.0) if k > 0 else 1.0
    gains = gains / np.sqrt(np.sum(np.abs(gains) ** 2) + 1e-30) * np.sqrt(p_scatter)

    y = g_los * s
    for g, tau, fd in zip(gains, delays, dopplers):
        path = _interp_delay(s, tau * fs) * np.exp(1j * 2 * np.pi * fd * t)
        y = y + g * path

    # 冲激响应与 H 矩阵（时不变近似：把抽头放在采样网格上）
    h = np.zeros(n, dtype=complex)
    for g, tau in zip(gains, delays):
        d = tau * fs
        i0 = int(np.floor(d))
        frac = d - i0
        if i0 < n:
            h[i0] += g * (1.0 - frac)
        if i0 + 1 < n:
            h[i0 + 1] += g * frac
    L = min(n, 128)
    hL = h[:L]
    # Toeplitz 卷积矩阵：H[i, j] = h[i-j]
    H = np.zeros((L, L), dtype=complex)
    for i in range(L):
        for j in range(i + 1):
            H[i, j] = hL[i - j]

    cir = [
        {"delay_s": float(tau), "magnitude": float(abs(g)), "phase_deg": float(np.degrees(np.angle(g))),
         "doppler_hz": float(fd), "gain_re": float(g.real), "gain_im": float(g.imag)}
        for g, tau, fd in zip(gains, delays, dopplers)
    ]
    visuals = {
        "cir": cir,
        "delay_gain": [{"delay_s": float(tau), "magnitude": float(abs(g))} for g, tau in zip(gains, delays)],
        "H": [[float(abs(H[i, j])) for j in range(L)] for i in range(L)],
        "H_real": [[float(H[i, j].real) for j in range(L)] for i in range(L)],
        "H_imag": [[float(H[i, j].imag) for j in range(L)] for i in range(L)],
        "H_size": L,
        "k_factor": float(k),
    }
    info = {
        "k_factor": float(k), "los_gain": float(g_los), "scatter_power": float(p_scatter),
        "num_taps": len(taps), "H_size": L,
        "note": "H 为时不变近似（忽略多普勒）的离散等效卷积矩阵，已推送矩阵算子工作台可用。",
    }
    return {
        "signal": {
            "t": [float(x) for x in signal["t"]],
            "re": [float(x) for x in y.real],
            "im": [float(x) for x in y.imag],
            "sampling_rate": fs, "t_start": 0.0, "t_end": float(t[-1]), "n_points": n,
        },
        "visuals": visuals,
        "info": info,
    }
