// 通用 "?" 帮助按钮：点击弹出 tips 说明（用于左侧参数面板标题旁）
export default {
  props: {
    title: { type: String, default: '帮助' },
    text: { type: String, default: '' },
  },
  data() { return { show: false }; },
  methods: {
    toggle() { this.show = !this.show; },
  },
  template: `
  <span class="help-wrap" style="position:relative;display:inline-block;">
    <button class="tb2" :class="{active: show}" title="帮助：这个面板是干什么的、怎么用" @click.stop="toggle">?</button>
    <div v-if="show" class="help-pop" @click.stop>
      <div class="help-title">{{ title }}</div>
      <div class="help-text">{{ text }}</div>
      <button class="chip" @click="show = false">知道了</button>
    </div>
  </span>
  `,
};
