// Tab5 视图：等效信道说明 + H_eq 热力图/特征值谱 + 总线监视器
import { bus } from '../bus.js';

export default {
  computed: {
    res() { return bus.moduleResult.transformer || null; },
    info() { return this.res ? this.res.info : null; },
  },
  template: `
  <div class="chain-views">
    <div class="info-box">
      <b>⚠ 模块性质说明：</b>本模块是<b>数学等效仿真</b> —— Attention 算子类比为时变信道；
      等效信道矩阵 H_eq = softmax(Q·Kᵀ/√d) 由输入 Q、K 决定，输入变化，信道随之改变。
      每一行代表一个输出位置对各输入位置的注意力权重（行和为 1）。
    </div>
    <div v-if="info" class="info-box">
      模式：{{ info.mode === 'from_bus' ? '自注意力（Q=K=V=总线信号重排，取实部）' : '手动矩阵' }} · d={{ info.d }}
      <div class="muted">{{ info.source_note }}</div>
    </div>
    <matrix-visuals v-if="res" :heatmap="res.visuals.heatmap" :eig="res.visuals.eig_spectrum"
      matrix-title="H_eq 注意力权重热力图（等效信道矩阵）"
      eig-title="H_eq 特征值谱（|λ| 降序）"></matrix-visuals>
    <div v-if="res && !res.signal" class="placeholder"><p>手动矩阵模式下不写回总线；切换「从总线构造」并点击计算，可将等效信道输出写回总线。</p></div>
    <bus-monitor></bus-monitor>
  </div>
  `,
};
