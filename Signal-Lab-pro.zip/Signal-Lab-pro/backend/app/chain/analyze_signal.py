"""数值信号分析端点（全局总线刷新的核心）。

输入：总线信号 {t, re, im, sampling_rate}（无表达式，纯数值）。
运算逻辑：完全复用基础分析模块的数值路径 ——
  1. 实/复信号判别（虚部是否全零）；
  2. 周期检测（FFT 谱峰 + 连续时间校验，插值采样器）；
  3. 谐波分解（每周期 FFT 数值积分求复系数）；
  4. 示波器指标、FFT 幅度/相位/PSD（复用 metrics/spectrum 模块）。
输出对象：与 /api/analyze 完全同构的响应（expression 字段标注为数值信号），
因此前端现有全部视图（时域+谐波叠加/频谱/3D/文本报告）无需改动即可刷新。
"""
from __future__ import annotations

import numpy as np

from .. import metrics as metrics_mod
from .. import periodic as periodic_mod
from .. import spectrum as spectrum_mod
from ..errors import AnalysisError
from . import CHAIN_MAX_POINTS


def analyze_numeric_signal(signal: dict, max_harmonics: int = 200) -> dict:
    n = len(signal["t"])
    if n < 4 or n > CHAIN_MAX_POINTS:
        raise AnalysisError(f"链路模式信号点数必须为 4 ~ {CHAIN_MAX_POINTS:,}（当前 {n}）",
                            ["请减小时间窗口或降低采样率"], "bad_chain_signal")
    t = np.asarray(signal["t"], dtype=float)
    re = np.asarray(signal["re"], dtype=float)
    im = np.asarray(signal["im"], dtype=float)
    fs = float(signal["sampling_rate"])
    s = re + 1j * im
    is_complex = bool(np.any(im != 0.0))

    # 插值采样器：让周期检测/谐波分解在任意时刻求值（数值信号无解析式）。
    # 超出信号时间范围返回 NaN —— 检测窗口已被约束在信号时长内（max_window），
    # 若仍有越界则视为无定义，防止外推产生伪周期。
    t0, t1 = float(t[0]), float(t[-1])

    def sampler(tt: np.ndarray) -> np.ndarray:
        tt = np.asarray(tt, dtype=float)
        re_i = np.interp(tt, t, re)
        im_i = np.interp(tt, t, im)
        oob = (tt < t0) | (tt > t1)
        re_i = np.where(oob, np.nan, re_i)
        im_i = np.where(oob, np.nan, im_i)
        return re_i + 1j * im_i

    # ---- 周期检测（数值路径，窗口不超过信号时长） ----
    f0 = periodic_mod._verify_period_numeric(sampler, None, max_harmonics,
                                             max_window=(t1 - t0) * 0.9)
    warnings: list[str] = []
    if f0:
        coeffs = periodic_mod._numeric_fourier_series(sampler, f0, max_harmonics)
        harmonics, truncated = periodic_mod._harmonics_from_coeffs(coeffs, f0, is_complex, max_harmonics)
        if truncated:
            warnings.append(f"谐波数量超过上限 {max_harmonics}，已按幅度截断")
        periodicity, period, fundamental = "periodic", 1.0 / f0, f0
        method = "numeric"
    else:
        harmonics, periodicity, period, fundamental, method = [], "aperiodic", None, None, "none"
        warnings.append("数值周期检测未通过：信号可能确为非周期，或含噪声/滤波瞬态导致周期验证失败")

    # ---- 指标与频谱（复用基础模块） ----
    metrics = metrics_mod.compute_metrics(t, s, is_complex, period, fundamental)
    spec = spectrum_mod.compute_spectrum(s, fs, is_complex)

    convention = (
        "实信号：单边约定 A_k=2|c_k|（k>0）" if not is_complex else
        "复信号：双边约定 A_k=|c_k|（k∈ℤ）"
    ) + "；展开式 s(t)=Σ A_k·e^{j(2π f_k t + φ_k)}"

    return {
        "expression": f"（数值信号：{n} 点，fs={fs:g} Hz，来源见总线标签）",
        "normalized_expression": "（链路仿真输出信号，无符号表达式）",
        "signal_type": "complex" if is_complex else "real",
        "periodicity": periodicity,
        "period": period,
        "fundamental_frequency": fundamental,
        "harmonics": harmonics,
        "harmonics_method": method,
        "harmonics_convention": convention,
        "metrics": metrics,
        "spectrum": {k: v for k, v in spec.items() if k != "summary"},
        "spectrum_summary": spec["summary"],
        "spectrum_note": spectrum_mod.build_spectrum_note(spec, fs, is_complex),
        "time": {
            "t": [float(x) for x in t],
            "real": [float(x) for x in re],
            "imag": [float(x) for x in im],
            "sampling_rate": float(fs),
            "t_start": float(t[0]),
            "t_end": float(t[-1]),
            "n_points": int(n),
        },
        "parameters_used": {
            "t_start": float(t[0]), "t_end": float(t[-1]),
            "sampling_rate": float(fs), "n_points": int(n),
            "frequency_resolution_hz": float(spec["resolution_hz"]),
        },
        "warnings": warnings,
        "extensions": {},
    }
