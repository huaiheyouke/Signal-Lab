// Tab4 矩阵算子工作台面板
// 输入二选一：①手动输入矩阵；②从多径信道导入 H。可选作用于总线信号。
import { bus, loadSignal, signalFromResponse, signalToPayload } from '../bus.js';
import { chainCall } from '../api.js';

export default {
  data() {
    return {
      bus,                     // ★ 模板使用了 bus.sharedH：必须挂到实例（Vue3 模板作用域）
      matrixText: '1 2 3; 4 5 6; 7 8 10',
      vectorText: '1 0 0',
      applyToBus: false,
      error: null, busy: false,
    };
  },
  computed: {
    canImportH() { return !!bus.sharedH; },
  },
  methods: {
    // 解析文本矩阵："1 2 3; 4 5 6; 7 8 9"（分号分行，空格/逗号分隔）
    parseMatrixText(text) {
      return text.split(';')
        .map(row => row.trim().split(/[ ,\t]+/).filter(s => s !== '').map(Number))
        .filter(row => row.length > 0);
    },
    importH() {
      if (!bus.sharedH) return;
      const rows = bus.sharedH.H.map(row => row.map(v => v.toPrecision(4)).join(' '));
      this.matrixText = rows.join(';');
      this.applyToBus = false;
    },
    async apply() {
      this.error = null;
      this.busy = true;
      try {
        const matrix = this.parseMatrixText(this.matrixText);
        const vector = this.vectorText.trim() === '' ? null : this.vectorText.split(/[ ,\t]+/).filter(s => s !== '').map(Number);
        if (!matrix.length || matrix.some(r => r.length !== matrix[0].length)) {
          throw { message: '矩阵格式错误：请用分号分行、空格或逗号分隔数字，且每行长度一致。', suggestions: [] };
        }
        const r = await chainCall('/api/chain/matrix', {
          matrix,
          vector: vector && vector.length ? vector : null,
          signal: this.applyToBus && bus.signal ? signalToPayload(bus.signal) : null,
          apply_to_bus: this.applyToBus,
        });
        bus.moduleResult.matrix = r;
        if (r.signal) {
          await loadSignal(signalFromResponse(r.signal), '矩阵算子：y = H @ x（' + matrix.length + '×' + matrix[0].length + '）');
        }
      } catch (err) {
        this.error = { message: err.message, suggestions: err.suggestions || [] };
      } finally {
        this.busy = false;
      }
    },
  },
  template: `
  <div class="panel">
    <div class="panel-title-row"><h2>④ 矩阵算子工作台</h2>
      <help-btn title="矩阵算子工作台" text="矩阵分析与变换实验：
- 矩阵来源：手动输入（分号分行、空格或逗号分隔）或【从多径信道导入 H】；
- 输出：热力图、特征值谱、秩、条件数（奇异矩阵显示 ∞）、行列式；3 维测试向量可查看 v → M@v 的空间变换；
- 勾选【将矩阵作用于总线信号】：执行 y = H@x（x 取总线前 L 点），结果写回全局总线，全部视图刷新。"></help-btn>
    </div>
    <p class="panel-desc">矩阵可视化与矩阵变换实验：热力图 / 特征值谱 / 向量三维变换 / 秩·条件数·行列式。
    勾选「作用于总线信号」时执行 y = H @ x（x 取总线前 L 点），结果写回总线。</p>

    <div class="field-block">
      <label>矩阵 H（分号分行，空格或逗号分隔）</label>
      <textarea v-model="matrixText" rows="5" class="mono"></textarea>
    </div>
    <button class="chip" :disabled="!canImportH" @click="importH" title="从多径信道模块的结果导入 H 矩阵">
      ⇩ 从多径信道导入 H（{{ canImportH ? bus.sharedH.size + '×' + bus.sharedH.size : '暂无' }}）
    </button>

    <div class="field-inline">
      <label>测试向量 v（3 维，可空）</label>
      <input v-model="vectorText" type="text" class="mono" placeholder="1 0 0" />
    </div>
    <div class="switch-row">
      <label class="switch"><input type="checkbox" v-model="applyToBus" /> 将矩阵作用于总线信号（写回总线）</label>
    </div>

    <button class="primary" :disabled="busy" @click="apply">{{ busy ? '计算中…' : '▶ 执行矩阵分析' }}</button>
    <div v-if="error" class="error-box"><div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions.length"><li v-for="(s,i) in error.suggestions" :key="i">{{ s }}</li></ul>
    </div>
  </div>
  `,
};
