// 输入与参数控制面板：表达式 + 教学示例 + 信号预设库 + 采样参数 + 运行按钮 + 错误提示
export default {
  props: ['busy', 'error', 'presetExpr', 'presetNote'],
  data() {
    return {
      expression: 'cos(2*pi*100*t)',
      tStart: '',
      tEnd: '',
      samplingRate: '',
      presetSel: 'sine',
      presets: [
        { label: '单音余弦', expr: 'cos(2*pi*100*t)' },
        { label: '双音复信号', expr: 'exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)' },
        { label: '方波', expr: 'sign(sin(2*pi*100*t))' },
        { label: '双音实信号', expr: 'cos(2*pi*100*t)+cos(2*pi*150*t)' },
        { label: '衰减振荡(非周期)', expr: 'exp(-10*t)*cos(2*pi*50*t)' },
      ],
    };
  },
  watch: {
    // 预设载入后，把预设表达式自动填入输入框（Barker 码等无表达式时忽略）
    presetExpr(v) {
      if (v && v.includes('(') && !v.includes('预设')) {
        this.expression = v;
      }
    },
  },
  methods: {
    usePreset(p) { this.expression = p.expr; },
    clearParams() { this.tStart = ''; this.tEnd = ''; this.samplingRate = ''; },
    submit() {
      if (this.busy) return;
      const num = (v) => {
        const s = String(v ?? '').trim();
        if (s === '') return null;
        const x = Number(s);
        return Number.isFinite(x) ? x : null;
      };
      this.$emit('analyze', {
        expression: this.expression,
        t_start: num(this.tStart),
        t_end: num(this.tEnd),
        sampling_rate: num(this.samplingRate),
      });
    },
  },
  template: `
  <div class="input-panel">
    <div class="panel-title-row">
      <label for="expr" style="font-weight:700;color:#1e3a8a;">基础信号分析</label>
      <help-btn title="基础信号分析" text="输入以 t 为自变量的信号表达式（支持实/复信号、j/1j 虚数单位、隐式乘法如 2pi/100t、^ 乘方），采样参数可留空自动推导（采样率 ≥ 8×最高频率，窗口覆盖 3~5 周期）。
点【运行分析】后：①完成解析/周期检测/复数傅里叶级数/示波器指标/FFT 频谱；②结果写入全局信号总线，并驱动全部视图（时域/频谱/三维/报告）。
右侧「信号预设库」可一键载入正弦/方波/三角波/LFM/Barker13 到总线。"></help-btn>
    </div>
    <div class="field">
      <label for="expr">信号表达式 s(t)（自变量固定为 t，支持复信号）</label>
      <textarea id="expr" rows="2" v-model="expression"
        placeholder="例：cos(2*pi*100*t) 或 exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)"></textarea>
    </div>

    <div class="presets">
      <span class="preset-label">教学示例：</span>
      <button v-for="p in presets" :key="p.label" class="chip" @click="usePreset(p)" :title="p.expr">{{ p.label }}</button>
    </div>

    <div class="preset-row">
      <span class="preset-label">信号预设库：</span>
      <select v-model="presetSel">
        <option value="sine">正弦波</option>
        <option value="square">方波</option>
        <option value="triangle">三角波</option>
        <option value="lfm">LFM 线性调频</option>
        <option value="barker13">Barker-13 扩频码</option>
      </select>
      <button class="chip accent" @click="$emit('preset', presetSel)" :disabled="busy">载入预设 → 总线</button>
    </div>
    <div v-if="presetNote" class="hint">📦 {{ presetNote }}</div>

    <div class="params">
      <div class="param-row">
        <label>t_start（秒）</label>
        <input v-model="tStart" type="number" step="any" placeholder="自动推导" />
      </div>
      <div class="param-row">
        <label>t_end（秒）</label>
        <input v-model="tEnd" type="number" step="any" placeholder="自动推导" />
      </div>
      <div class="param-row">
        <label>采样率 sampling_rate（Hz）</label>
        <input v-model="samplingRate" type="number" step="any" placeholder="自动推导" />
      </div>
    </div>

    <div class="actions">
      <button class="primary" :disabled="busy" @click="submit">{{ busy ? '分析中…' : '▶ 运行分析' }}</button>
      <button class="ghost" @click="clearParams">清空参数</button>
    </div>

    <div class="hint">
      参数留空时后端自动推导：采样率 ≥ 8×信号最高频率，时间窗口覆盖 3~5 个周期。<br/>
      支持 j / 1j 虚数单位、隐式乘法（2pi、100t）、^ 乘方（t^2）。<br/>
      💡 运行分析后信号进入<b>全局总线</b>：可到右侧「噪声与滤波 / 多径信道 / 调制」等 Tab 继续仿真。
    </div>

    <div v-if="error" class="error-box">
      <div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions && error.suggestions.length">
        <li v-for="(s, i) in error.suggestions" :key="i">{{ s }}</li>
      </ul>
    </div>
  </div>
  `,
};

