// Tab2 视图：星座图 + 调制参数说明 + 总线信号监视器
import { bus } from '../bus.js';

export default {
  computed: {
    modInfo() { return (bus.moduleResult.mod && bus.moduleResult.mod.info) ? bus.moduleResult.mod.info : null; },
  },
  template: `
  <div class="chain-views">
    <div v-if="modInfo" class="info-box">
      {{ modInfo.modulation }} · {{ modInfo.symbol_rate }} Bd · {{ modInfo.samples_per_symbol }} 点/符号 ·
      {{ modInfo.num_symbols }} 符号（{{ modInfo.bits }} bit）· 滚降 β={{ modInfo.rolloff }} ·
      频偏 {{ modInfo.freq_offset_hz }} Hz · 相偏 {{ modInfo.phase_offset_rad }} rad
      <div class="muted">{{ modInfo.note }}</div>
    </div>
    <constellation-plot></constellation-plot>
    <bus-monitor></bus-monitor>
  </div>
  `,
};
