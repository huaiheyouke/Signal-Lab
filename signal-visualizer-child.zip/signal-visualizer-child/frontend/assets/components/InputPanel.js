// 输入与参数控制面板：表达式 + 教学示例 + 采样参数 + 运行按钮 + 错误提示
export default {
  props: ['busy', 'error'],
  data() {
    return {
      expression: 'cos(2*pi*100*t)',
      tStart: '',
      tEnd: '',
      samplingRate: '',
      presets: [
        { label: '单音余弦', expr: 'cos(2*pi*100*t)' },
        { label: '双音复信号', expr: 'exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)' },
        { label: '方波', expr: 'sign(sin(2*pi*100*t))' },
        { label: '双音实信号', expr: 'cos(2*pi*100*t)+cos(2*pi*150*t)' },
        { label: '衰减振荡(非周期)', expr: 'exp(-10*t)*cos(2*pi*50*t)' },
      ],
    };
  },
  methods: {
    usePreset(p) { this.expression = p.expr; },
    clearParams() { this.tStart = ''; this.tEnd = ''; this.samplingRate = ''; },
    submit() {
      if (this.busy) return;
      // 空字符串 -> null（后端自动推导）；非法数字 -> null 并提示
      const num = (v) => {
        const s = String(v ?? '').trim();
        if (s === '') return null;
        const x = Number(s);
        return Number.isFinite(x) ? x : null;
      };
      this.$emit('analyze', {
        expression: this.expression,
        t_start: num(this.tStart),
        t_end: num(this.tEnd),
        sampling_rate: num(this.samplingRate),
      });
    },
  },
  template: `
  <div class="input-panel">
    <div class="field">
      <label for="expr">信号表达式 s(t)（自变量固定为 t，支持复信号）</label>
      <textarea id="expr" rows="2" v-model="expression"
        placeholder="例：cos(2*pi*100*t) 或 exp(1j*2*pi*50*t)+0.5*exp(1j*2*pi*150*t)"></textarea>
    </div>

    <div class="presets">
      <span class="preset-label">教学示例：</span>
      <button v-for="p in presets" :key="p.label" class="chip" @click="usePreset(p)" :title="p.expr">{{ p.label }}</button>
    </div>

    <div class="params">
      <div class="param-row">
        <label>t_start（秒）</label>
        <input v-model="tStart" type="number" step="any" placeholder="自动推导" />
      </div>
      <div class="param-row">
        <label>t_end（秒）</label>
        <input v-model="tEnd" type="number" step="any" placeholder="自动推导" />
      </div>
      <div class="param-row">
        <label>采样率 sampling_rate（Hz）</label>
        <input v-model="samplingRate" type="number" step="any" placeholder="自动推导" />
      </div>
    </div>

    <div class="actions">
      <button class="primary" :disabled="busy" @click="submit">{{ busy ? '分析中…' : '▶ 运行分析' }}</button>
      <button class="ghost" @click="clearParams">清空参数</button>
    </div>

    <div class="hint">
      参数留空时后端自动推导：采样率 ≥ 8×信号最高频率，时间窗口覆盖 3~5 个周期。<br/>
      支持 j / 1j 虚数单位、隐式乘法（2pi、100t）、^ 乘方（t^2）；支持函数：
      sin cos exp sqrt abs sign Heaviside sinc 等。
    </div>

    <div v-if="error" class="error-box">
      <div class="error-title">⚠ {{ error.message }}</div>
      <ul v-if="error.suggestions && error.suggestions.length">
        <li v-for="(s, i) in error.suggestions" :key="i">{{ s }}</li>
      </ul>
    </div>
  </div>
  `,
};
