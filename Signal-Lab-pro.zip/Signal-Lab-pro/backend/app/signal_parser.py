"""信号表达式解析模块。

职责：
1. 把用户输入的字符串解析为 sympy 表达式（只允许 t 为自变量）；
2. 判断实信号 / 复信号，并拆出 Re[s(t)]、Im[s(t)]（符号形式）；
3. 提供统一的数值采样函数（sympy.lambdify 封装，numpy 后端）。

扩展说明：后续信道建模 / 星座图等模块可通过 pipeline 拿到本模块
产出的 expr / re_expr / im_expr，在符号层做变换后再重新采样。
"""
from __future__ import annotations

import re
import tokenize

import numpy as np
import sympy as sp
from sympy.parsing.sympy_parser import (
    convert_xor,
    implicit_multiplication_application,
    parse_expr,
    standard_transformations,
)

from .errors import AnalysisError

# 自变量固定为 t（实数）
VAR = sp.Symbol("t", real=True)

# 允许出现在表达式里的函数白名单（防注入 + 引导用户使用教学常用函数）
ALLOWED_FUNCTIONS = {
    # 三角 / 反三角
    "sin", "cos", "tan", "cot", "sec", "csc",
    "asin", "acos", "atan", "atan2",
    "sinh", "cosh", "tanh", "asinh", "acosh", "atanh",
    # 指数对数与通用
    "exp", "log", "ln", "sqrt", "abs", "sign",
    # 通信/信号处理常用
    "Heaviside", "DiracDelta", "sinc", "erf", "erfc", "floor", "ceiling",
    "Min", "Max", "re", "im", "arg", "conjugate", "factorial",
}

# 解析变换：标准变换 + 隐式乘法（2pi -> 2*pi，2t -> 2*t，2sin(t) -> 2*sin(t)）+ ^ 转 **
_TRANSFORMATIONS = standard_transformations + (
    implicit_multiplication_application,
    convert_xor,
)

# 常用常量的友好别名（e -> 欧拉数，π -> pi，j/i -> 虚数单位）
_LOCAL_DICT: dict = {
    "t": VAR,
    "pi": sp.pi,
    "π": sp.pi,
    "e": sp.E,
    "E": sp.E,
    "I": sp.I,
    "j": sp.I,
    "i": sp.I,
    "oo": sp.oo,
}
for _name in ALLOWED_FUNCTIONS:
    if hasattr(sp, _name):
        _LOCAL_DICT[_name] = getattr(sp, _name)

# lambdify 的自定义映射（sympy 的 re/im/arg/conjugate 等没有直接 numpy 对应）
_NUMPY_MODULES = [
    {
        "re": np.real,
        "im": np.imag,
        "arg": np.angle,
        "conjugate": np.conjugate,
        "sign": np.sign,
        "Heaviside": lambda x: np.heaviside(x, 0.5),
        "DiracDelta": lambda x: np.where(np.abs(x) < 1e-12, np.inf, 0.0),
    },
    "numpy",
]


def _suggest_for_text(text: str) -> list[str]:
    """根据原始文本给出常见语法错误的修改建议。"""
    sugg: list[str] = []
    if text.count("(") != text.count(")"):
        sugg.append("括号不匹配：请检查左右括号数量是否一致")
    if "**" not in text and "^" in text:
        sugg.append("已支持 ^ 作为乘方符号（例如 t^2）")
    unknown = sorted({
        m.group(1) for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", text)
        if m.group(1) not in ALLOWED_FUNCTIONS and m.group(1) not in ("pi", "π", "t", "e", "j", "i", "I")
    })
    if unknown:
        sugg.append("不支持的函数/标识符：" + "、".join(unknown) +
                    "（支持 sin/cos/exp/sqrt/abs/sign/Heaviside/sinc 等，见 README）")
    sugg.append("自变量固定为 t；复数请用 j 或 1j（例如 exp(1j*2*pi*50*t)）")
    return sugg


def parse_signal_expression(text: str) -> sp.Expr:
    """解析用户表达式，返回只含变量 t 的 sympy 表达式（已展开规范化）。"""
    text = (text or "").strip()
    if not text:
        raise AnalysisError("表达式为空", ["请输入形如 cos(2*pi*100*t) 的时域信号表达式"], "empty_expression")
    if len(text) > 2000:
        raise AnalysisError("表达式过长（超过 2000 字符）", ["请精简表达式"], "expression_too_long")

    try:
        expr = parse_expr(text, local_dict=_LOCAL_DICT, transformations=_TRANSFORMATIONS)
    except (SyntaxError, sp.SympifyError, TypeError, ValueError,
            ZeroDivisionError, AttributeError, tokenize.TokenError) as exc:
        raise AnalysisError(
            f"表达式语法无法解析：{exc}",
            _suggest_for_text(text),
            "parse_error",
        ) from exc

    # 规范化：代数展开（注意：这里不能用 expand_trig —— 它会把
    # cos(200*pi*t) 递归展开成 cos(pi*t)**200 的组合爆炸表达式；
    # 三角恒等式展开统一交给谐波分解阶段的 rewrite(exp) 处理）
    try:
        if expr.count_ops() < 3000:
            expr = sp.expand(expr)
    except Exception:  # 规范化失败不致命，保留原表达式
        pass

    # 表达式含无穷大/未定义值（如 1/0 -> zoo）直接拒绝，给出友好提示
    if expr.has(sp.zoo, sp.oo, -sp.oo, sp.nan):
        raise AnalysisError(
            "表达式包含无穷大或未定义值（如除零、正切极点）",
            ["检查是否存在分母为零的项", "tan 的极点处请改用其他函数或缩小时间范围"],
            "parse_error",
        )

    # 只允许 t 作为自由变量（pi/e/I 等常量不算自由变量）
    extra = expr.free_symbols - {VAR}
    if extra:
        names = ", ".join(sorted(str(s) for s in extra))
        raise AnalysisError(
            f"表达式包含未定义符号：{names}",
            ["本工具只支持以 t 为自变量",
             f"请把 {names} 替换为 t 或具体数值（例如 100*t、0.5*cos(2*pi*t)）"],
            "unknown_symbol",
        )
    return expr


def classify_signal(expr: sp.Expr):
    """判断实信号 / 复信号，返回 (is_complex, re_expr, im_expr)。

    - 表达式含虚数单位 I 且 Im[s(t)] 化简后不为 0 -> 复信号；
    - 否则为实信号（虚部表达式为 0）。
    """
    zero = sp.Integer(0)
    if expr.has(sp.I):
        im = sp.im(expr)
        if im.count_ops() < 800:  # 大表达式跳过 simplify 防止超时
            im = sp.simplify(im)
        if im == 0:
            return False, expr, zero
        re_part = sp.re(expr)
        if re_part.count_ops() < 800:
            re_part = sp.simplify(re_part)
        im = sp.simplify(im) if im.count_ops() < 800 else im
        return True, re_part, im
    return False, expr, zero


def build_sampler(expr: sp.Expr):
    """把符号表达式编译为 numpy 采样函数 sample(t_array) -> complex ndarray。"""
    try:
        f = sp.lambdify(VAR, expr, modules=_NUMPY_MODULES)
    except Exception as exc:  # pragma: no cover
        raise AnalysisError(
            f"表达式无法数值化：{exc}",
            ["请检查是否使用了本工具不支持的函数", "可尝试把表达式拆成多个简单信号分别分析"],
            "lambdify_error",
        ) from exc

    def sample(t: np.ndarray) -> np.ndarray:
        try:
            v = np.asarray(f(t), dtype=complex)
            # 常数表达式（如 "5"）的 lambdify 返回标量，广播成与 t 同形
            if v.ndim == 0 or v.shape != t.shape:
                v = np.broadcast_to(v, t.shape).copy()
        except Exception as exc:
            raise AnalysisError(
                f"数值采样失败：{exc}",
                ["请检查表达式在采样区间内是否定义良好"],
                "sampling_error",
            ) from exc
        if not np.all(np.isfinite(v)):
            bad = int(np.sum(~np.isfinite(v)))
            raise AnalysisError(
                f"信号在采样区间内出现 {bad} 个无穷大/NaN 点（可能发散或有奇点）",
                ["请缩小时间窗口（t_start / t_end）避开奇点",
                 "检查是否存在除零、tan 极点等奇异行为"],
                "singular_signal",
            )
        return v

    return sample
