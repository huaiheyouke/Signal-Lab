// ============================================================
// FloatCard 通用浮动窗口卡片（SystemView / CATIA 风格）
// ------------------------------------------------------------
// 功能：
//  - 拖拽标题栏：直接进入"浮动模式"并自由移动（松手即浮动）
//  - 浮动模式下右下角手柄自由缩放；双击标题最大化/还原
//  - ⧉ 按钮：浮动 ⇄ 停靠（回到原流式位置）
//  - ? 按钮：点击弹出该窗口的用途与使用说明（tips）
//  - ⤓ 按钮：导出内部 Plotly 图为 PNG（自动查找 .plot 元素）
//  - ▾/▸ 按钮：最小化（只留标题栏）/展开
// 停靠模式：正常参与父容器流式布局；浮动模式：position:fixed 自由层叠
// ============================================================

export default {
  props: {
    title: { type: String, default: '' },        // 窗口标题
    help: { type: String, default: '' },         // ? 帮助文本（干什么、怎么用）
    exportName: { type: String, default: 'chart.png' },
  },
  data() {
    return {
      floating: false,     // 浮动模式（fixed 自由定位）
      collapsed: false,    // 最小化（仅标题栏）
      maximized: false,    // 最大化（占满可视区）
      showHelp: false,     // 帮助浮层
      pos: { x: 80, y: 80 },
      size: { w: 560, h: 420 },
      drag: null,          // {mode:'move'|'resize', sx, sy, ox, oy, ow, oh}
    };
  },
  computed: {
    boxStyle() {
      if (!this.floating) return {};
      const s = {
        position: 'fixed',
        zIndex: 2000,
        background: '#fff',
        borderRadius: '10px',
        border: '1px solid #93c5fd',
        boxShadow: '0 14px 36px rgba(15, 23, 42, 0.30)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      };
      if (this.maximized) {
        s.left = '12px'; s.top = '56px'; s.right = '12px'; s.bottom = '12px';
      } else {
        s.left = this.pos.x + 'px'; s.top = this.pos.y + 'px';
        s.width = this.size.w + 'px'; s.height = this.size.h + 'px';
      }
      return s;
    },
  },
  methods: {
    // 标题栏按下：进入浮动并开始拖拽移动
    onHeadDown(e) {
      if (e.button !== 0) return;
      if (e.target.closest('button')) return;          // 不拦截按钮点击
      if (e.target.closest('.float-help')) return;     // 不拦截帮助浮层
      if (!this.floating) {
        // SystemView 风格：按住标题即浮动（位置=当前位置）
        this.floating = true;
        this.maximized = false;
        const r = this.$el.getBoundingClientRect();
        this.pos = { x: Math.round(r.left), y: Math.round(r.top) };
        this.size = { w: Math.max(Math.round(r.width), 360), h: Math.max(Math.round(r.height), 220) };
      }
      this.drag = { mode: 'move', sx: e.clientX, sy: e.clientY, ox: this.pos.x, oy: this.pos.y };
      window.addEventListener('mousemove', this.onDrag);
      window.addEventListener('mouseup', this.stopDrag);
      document.body.style.userSelect = 'none';
      document.body.style.cursor = 'move';
    },
    // 八方向缩放手柄（n/s/e/w/ne/nw/se/sw）
    onResizeStart(e, dir) {
      e.stopPropagation();
      if (!this.floating) {
        this.floating = true;
        const r = this.$el.getBoundingClientRect();
        this.pos = { x: Math.round(r.left), y: Math.round(r.top) };
        this.size = { w: Math.max(Math.round(r.width), 360), h: Math.max(Math.round(r.height), 220) };
      }
      this.drag = { mode: 'resize', dir, sx: e.clientX, sy: e.clientY, ox: this.pos.x, oy: this.pos.y, ow: this.size.w, oh: this.size.h };
      window.addEventListener('mousemove', this.onDrag);
      window.addEventListener('mouseup', this.stopDrag);
      document.body.style.userSelect = 'none';
    },
    onDrag(e) {
      if (!this.drag) return;
      const dx = e.clientX - this.drag.sx;
      const dy = e.clientY - this.drag.sy;
      if (this.drag.mode === 'move') {
        // 边界约束：保证标题栏始终在视口内（否则会被浏览器地址栏/搜索框挡住，
        // 导致窗口"卡"在屏幕顶部无法再操作）
        const vw = window.innerWidth || 1200;
        const vh = window.innerHeight || 800;
        this.pos = {
          x: Math.max(0, Math.min(this.drag.ox + dx, Math.max(0, vw - 120))),
          y: Math.max(0, Math.min(this.drag.oy + dy, Math.max(0, vh - 48))),
        };
        return;
      }
      // 八方向缩放：按方向调整尺寸与左上角坐标
      const d = this.drag.dir;
      let w = this.drag.ow, h = this.drag.oh, x = this.drag.ox, y = this.drag.oy;
      if (d.indexOf('e') !== -1) w = this.drag.ow + dx;
      if (d.indexOf('s') !== -1) h = this.drag.oh + dy;
      if (d.indexOf('w') !== -1) { w = this.drag.ow - dx; x = this.drag.ox + dx; }
      if (d.indexOf('n') !== -1) { h = this.drag.oh - dy; y = this.drag.oy + dy; }
      const minW = 340, minH = 220;
      if (w < minW) { if (d.indexOf('w') !== -1) x -= (minW - w); w = minW; }
      if (h < minH) { if (d.indexOf('n') !== -1) y -= (minH - h); h = minH; }
      // 尺寸不超过视口
      const vw = window.innerWidth || 1200;
      const vh = window.innerHeight || 800;
      w = Math.min(w, vw);
      h = Math.min(h, vh);
      this.size = { w, h };
      this.pos = { x, y };
    },
    stopDrag() {
      this.drag = null;
      window.removeEventListener('mousemove', this.onDrag);
      window.removeEventListener('mouseup', this.stopDrag);
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
      this.clampToViewport();   // 兜底：窗口任何部分越界则自动拉回
    },
    // 视口边界约束：保证标题栏与按钮始终可见可操作
    clampToViewport() {
      if (!this.floating) return;
      const vw = window.innerWidth || 1200;
      const vh = window.innerHeight || 800;
      this.pos.x = Math.max(0, Math.min(this.pos.x, Math.max(0, vw - 120)));
      this.pos.y = Math.max(0, Math.min(this.pos.y, Math.max(0, vh - 48)));
      this.size.w = Math.min(this.size.w, vw);
      this.size.h = Math.min(this.size.h, vh);
    },
    toggleFloat() { this.floating = !this.floating; this.showHelp = false; },
    toggleMax() { this.maximized = !this.maximized; },
    toggleCollapse() { this.collapsed = !this.collapsed; },
    exportPNG() {
      const body = this.$refs.body;
      const el = body ? body.querySelector('.plot, .plot-tall') : null;
      if (!el || !window.Plotly) return;
      Plotly.toImage(el, {
        format: 'png',
        width: Math.max(el.clientWidth * 2, 800),
        height: Math.max(el.clientHeight * 2, 500),
        scale: 2,
      }).then(url => {
        const a = document.createElement('a');
        a.href = url;
        a.download = this.exportName;
        document.body.appendChild(a);
        a.click();
        a.remove();
      }).catch(() => {});
    },
  },
  template: `
  <div class="float-card" :class="{floating: floating, collapsed: collapsed, maximized: maximized}" :style="boxStyle">
    <div class="float-head" @mousedown="onHeadDown" @dblclick="toggleMax" :title="floating ? '拖拽移动 · 双击最大化/还原' : '按住标题可浮动为自由窗口'">
      <span class="float-title">{{ title }}</span>
      <span class="float-tools" @mousedown.stop>
        <button class="tb2" :class="{active: showHelp}" title="帮助：这个窗口是干什么的、怎么用" @click="showHelp = !showHelp">?</button>
        <button class="tb2" title="导出 PNG" @click="exportPNG">⤓</button>
        <button class="tb2" :title="floating ? '停靠回原位' : '浮动（自由移动/缩放）'" @click="toggleFloat">⧉</button>
        <button class="tb2" title="最大化 / 还原" @click="toggleMax">▣</button>
        <button class="tb2" :title="collapsed ? '展开' : '最小化（收起内容）'" @click="toggleCollapse">{{ collapsed ? '▸' : '▾' }}</button>
      </span>
    </div>
    <div v-if="showHelp" class="float-help" @mousedown.stop>
      <div class="help-title">{{ title }}</div>
      <div class="help-text">{{ help }}</div>
      <button class="chip" @click="showHelp = false">知道了</button>
    </div>
    <div v-show="!collapsed" ref="body" class="float-body">
      <slot></slot>
    </div>
    <template v-if="floating">
      <div class="rz rz-n" @mousedown="onResizeStart($event, 'n')"></div>
      <div class="rz rz-s" @mousedown="onResizeStart($event, 's')"></div>
      <div class="rz rz-e" @mousedown="onResizeStart($event, 'e')"></div>
      <div class="rz rz-w" @mousedown="onResizeStart($event, 'w')"></div>
      <div class="rz rz-ne" @mousedown="onResizeStart($event, 'ne')"></div>
      <div class="rz rz-nw" @mousedown="onResizeStart($event, 'nw')"></div>
      <div class="rz rz-se" @mousedown="onResizeStart($event, 'se')"></div>
      <div class="rz rz-sw" @mousedown="onResizeStart($event, 'sw')"></div>
    </template>
  </div>
  `,
};
