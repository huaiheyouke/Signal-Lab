// 图2/3/4：幅度谱 / 相位谱 / 功率谱密度（同一 Tab 内三张图）
import { stride, PLOTLY_CONFIG } from '../utils.js';

export default {
  props: ['result'],
  mounted() { this.render(); },
  watch: { result: { deep: true, handler() { this.render(); } } },
  beforeUnmount() {
    for (const ref of ['mag', 'phase', 'psd']) {
      if (this.$refs[ref]) Plotly.purge(this.$refs[ref]);
    }
  },
  methods: {
    render() {
      const r = this.result;
      if (!r || !r.spectrum) return;
      const sp = r.spectrum;
      const f = stride(sp.frequency, 80000);
      const mag = stride(sp.magnitude, 80000);
      const phase = stride(sp.phase, 80000);
      const psd = stride(sp.psd, 80000);

      const side = sp.two_sided ? '双边谱' : '单边谱';
      const base = { paper_bgcolor: '#fff', plot_bgcolor: '#fff' };

      // 图2 幅度谱
      Plotly.react(this.$refs.mag, [{
        x: f, y: mag, type: 'scatter', mode: 'lines',
        line: { color: '#2563eb', width: 1.6 },
        hovertemplate: 'f=%{x:.6g} Hz<br>幅度=%{y:.6g}<extra></extra>',
      }], Object.assign({
        title: '图2 · 幅度谱（' + side + '）',
        xaxis: { title: '频率 (Hz)', gridcolor: '#e5e7eb' },
        yaxis: { title: '幅度', gridcolor: '#e5e7eb' },
        margin: { t: 44, l: 56, r: 16, b: 46 },
      }, base), PLOTLY_CONFIG);

      // 图3 相位谱（弧度）
      Plotly.react(this.$refs.phase, [{
        x: f, y: phase, type: 'scatter', mode: 'lines',
        line: { color: '#dc2626', width: 1.4 },
        hovertemplate: 'f=%{x:.6g} Hz<br>相位=%{y:.6g} rad<extra></extra>',
      }], Object.assign({
        title: '图3 · 相位谱（弧度）',
        xaxis: { title: '频率 (Hz)', gridcolor: '#e5e7eb' },
        yaxis: { title: '相位 (rad)', gridcolor: '#e5e7eb', range: [-Math.PI, Math.PI] },
        margin: { t: 44, l: 56, r: 16, b: 46 },
      }, base), PLOTLY_CONFIG);

      // 图4 功率谱密度（动态范围大时自动切对数轴）
      let ytype = 'linear';
      const pos = psd.filter(v => v > 0);
      if (pos.length > 1) {
        const pMax = Math.max(...pos), pMin = Math.min(...pos);
        if (pMin > 0 && pMax / pMin > 1000) ytype = 'log';
      }
      Plotly.react(this.$refs.psd, [{
        x: f, y: psd, type: 'scatter', mode: 'lines',
        line: { color: '#10b981', width: 1.4 },
        hovertemplate: 'f=%{x:.6g} Hz<br>PSD=%{y:.6g} V²/Hz<extra></extra>',
      }], Object.assign({
        title: '图4 · 功率谱密度（Periodogram，' + side + '）',
        xaxis: { title: '频率 (Hz)', gridcolor: '#e5e7eb' },
        yaxis: { title: '功率谱密度 (V²/Hz)', gridcolor: '#e5e7eb', type: ytype },
        margin: { t: 44, l: 56, r: 16, b: 46 },
      }, base), PLOTLY_CONFIG);
    },
  },
  template: `
  <div>
    <float-card title="图2 · 幅度谱" export-name="magnitude_spectrum.png"
      help="FFT 幅度谱。实信号为单边谱（幅度=2|X|/N，直流不翻倍）；复信号为双边谱（幅度=|X|/N）。用于查看信号的主要频率分量及其强度。">
      <div ref="mag" class="plot"></div>
    </float-card>
    <float-card title="图3 · 相位谱（弧度）" export-name="phase_spectrum.png"
      help="FFT 相位谱，单位弧度（主值 [-π, π]）。与幅度谱配合可完整描述信号频域特性；谐波初相可在此核对。">
      <div ref="phase" class="plot"></div>
    </float-card>
    <float-card title="图4 · 功率谱密度（Periodogram）" export-name="psd.png"
      help="功率谱密度估计（V²/Hz），反映信号功率随频率的分布；动态范围大时自动切换对数纵轴。">
      <div ref="psd" class="plot"></div>
    </float-card>
  </div>
  `,
};
