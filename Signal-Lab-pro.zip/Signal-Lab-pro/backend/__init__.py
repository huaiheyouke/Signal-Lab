"""后端包：backend.app 为应用代码，backend.tests 为冒烟测试。"""
