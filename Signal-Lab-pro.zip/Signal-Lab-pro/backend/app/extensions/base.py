"""扩展接口：所有后续模块（信道建模 / Transformer 等效信道 / 星座图）
通过继承 AnalysisExtension 并注册，即可自动接入分析流水线。
"""
from __future__ import annotations

from abc import ABC


class AnalysisExtension(ABC):
    """分析扩展基类。子类按需覆盖钩子。

    生命周期钩子（按 pipeline 执行顺序）：
      on_begin          分析开始（ctx 仅含请求参数）
      on_signal_parsed  表达式解析完成（ctx 含 expr/re_expr/im_expr/is_complex）
      on_harmonics      谐波分解完成（ctx 含 harmonics/periodicity 等）
      on_spectrum       频谱计算完成（ctx 含 spectrum 数据）
      on_end            分析结束（ctx 含 t/s/fs 等全部中间结果）

    ctx 为共享上下文 dict。扩展可用 ctx["extras"]["<模块名>"] = {...}
    输出自定义数据，该内容会出现在响应的 extensions.<模块名> 字段，
    前端可为其预留渲染区域（如星座图 / 眼图 / 信道参数表）。
    """
    name: str = "base"
    description: str = ""

    def on_begin(self, ctx: dict) -> None:  # noqa: B027
        """分析开始。"""

    def on_signal_parsed(self, ctx: dict) -> None:  # noqa: B027
        """信号解析完成。"""

    def on_harmonics(self, ctx: dict) -> None:  # noqa: B027
        """谐波分解完成。"""

    def on_spectrum(self, ctx: dict) -> None:  # noqa: B027
        """频谱计算完成。"""

    def on_end(self, ctx: dict) -> None:  # noqa: B027
        """分析结束。"""


class ExtensionRegistry:
    """扩展注册表：保持注册顺序，按序调用钩子。"""

    def __init__(self) -> None:
        self._extensions: list[AnalysisExtension] = []

    def register(self, ext: AnalysisExtension) -> None:
        if not any(e.name == ext.name for e in self._extensions):
            self._extensions.append(ext)

    def items(self) -> list[AnalysisExtension]:
        return list(self._extensions)


_registry = ExtensionRegistry()


def register_extension(ext: AnalysisExtension) -> None:
    """注册一个扩展实例（幂等，同名不重复注册）。"""
    _registry.register(ext)


def get_registry() -> ExtensionRegistry:
    return _registry
