"""FastAPI 入口：/api/analyze 分析接口 + 前端静态托管（本地单机运行）。"""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .errors import AnalysisError
from .pipeline import analyze, run_with_timeout
from .schemas import AnalyzeRequest, AnalyzeResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("signallab")

FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"

app = FastAPI(
    title="通信信号分析可视化教学工具 SignalLab",
    version="1.0.0",
    description=(
        "输入时域信号表达式，自动完成信号解析 / 谐波分解 / 示波器指标 / "
        "频谱分析；前端由 Plotly.js 在浏览器本地渲染 2D/3D 交互图。"
    ),
)

# 允许本地跨域（前端单独调试时使用；同源部署时无影响）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "signallab", "version": "1.0.0"}


@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze_endpoint(req: AnalyzeRequest):
    """核心分析接口：POST 表达式与参数 -> 完整分析 JSON。"""
    try:
        return run_with_timeout(45.0, analyze, req)
    except AnalysisError as exc:
        # 结构化错误：{code, error, suggestions}，前端直接展示
        raise HTTPException(status_code=422, detail=exc.to_dict()) from exc
    except Exception as exc:  # 兜底：未预期异常
        logger.exception("分析失败")
        raise HTTPException(
            status_code=500,
            detail={
                "code": "internal_error",
                "error": "服务器内部错误，请查看后端控制台日志",
                "suggestions": ["简化表达式后重试"],
            },
        ) from exc


# ---- 前端静态托管（无需单独启动前端服务） ----
if (FRONTEND_DIR / "vendor").is_dir():
    app.mount("/vendor", StaticFiles(directory=FRONTEND_DIR / "vendor"), name="vendor")
if (FRONTEND_DIR / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(FRONTEND_DIR / "index.html")
