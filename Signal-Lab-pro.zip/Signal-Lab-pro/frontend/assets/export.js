// 导出工具：图表 PNG / 总线信号 CSV / 分析报告 Markdown

// 导出 Plotly 图表为 PNG（浏览器本地渲染，无需联网）
export function downloadPlotPNG(el, filename) {
  if (!el || !window.Plotly) return;
  Plotly.toImage(el, {
    format: 'png',
    width: Math.max(el.clientWidth * 2, 800),
    height: Math.max(el.clientHeight * 2, 500),
    scale: 2,
  })
    .then(url => {
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
    })
    .catch(e => alert('导出 PNG 失败：' + e.message));
}

// 下载文本文件（CSV / Markdown 等）
export function downloadText(filename, text, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob(['\ufeff' + text], { type: mime });  // BOM 保证 Excel 中文不乱码
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

// 总线信号导出为 CSV（t, Re[s(t)], Im[s(t)] 三列）
export function busToCSV(signal) {
  if (!signal) return '';
  const lines = ['t(s),Re[s(t)],Im[s(t)]'];
  const n = signal.t.length;
  for (let i = 0; i < n; i++) {
    lines.push(signal.t[i].toPrecision(10) + ',' + signal.real[i].toPrecision(10) + ',' + signal.imag[i].toPrecision(10));
  }
  return lines.join('\n');
}

// 分析报告导出为 Markdown
export function reportToMarkdown(r) {
  if (!r) return '';
  const L = [];
  L.push('# 信号分析报告');
  L.push('');
  L.push('- **表达式**：' + r.expression);
  L.push('- **类型**：' + (r.signal_type === 'complex' ? '复信号' : '实信号')
    + ' / ' + (r.periodicity === 'periodic' ? '周期信号' : r.periodicity === 'constant' ? '常数信号' : '非周期信号')
    + (r.periodicity === 'periodic' && r.period != null
      ? '（周期 T=' + r.period.toPrecision(6) + ' s，基频 f₀=' + r.fundamental_frequency.toPrecision(6) + ' Hz）' : ''));
  L.push('');
  if (r.periodicity === 'periodic' && r.harmonics.length) {
    L.push('## 谐波分解（复数形式 s(t)=Σ A_k·e^{j(2πf_k t+φ_k)}）');
    L.push('');
    L.push('| k | f_k (Hz) | A_k | φ_k (rad) |');
    L.push('|---|----------|-----|-----------|');
    for (const h of r.harmonics) {
      L.push('| ' + h.k + ' | ' + h.frequency.toPrecision(6) + ' | ' + h.amplitude.toPrecision(6)
        + ' | ' + h.phase.toPrecision(6) + ' |');
    }
    L.push('');
  }
  const m = r.metrics;
  L.push('## 示波器指标');
  L.push('');
  L.push('- 直流分量：' + m.dc_re.toPrecision(6) + (r.signal_type === 'complex' ? ' + ' + m.dc_im.toPrecision(6) + ' j' : ''));
  L.push('- 峰值：' + m.peak.toPrecision(6) + '；有效值 RMS：' + m.rms.toPrecision(6));
  L.push('- 最大值：Re=' + m.max_re.toPrecision(6) + (r.signal_type === 'complex' ? '，Im=' + m.max_im.toPrecision(6) : ''));
  L.push('- 最小值：Re=' + m.min_re.toPrecision(6) + (r.signal_type === 'complex' ? '，Im=' + m.min_im.toPrecision(6) : ''));
  L.push('- 过零点：Re=' + m.zero_crossings_re.length + ' 个' + (r.signal_type === 'complex' ? '，Im=' + m.zero_crossings_im.length + ' 个' : ''));
  L.push('');
  L.push('## 频谱说明');
  L.push('');
  L.push(r.spectrum_note.replace(/\n/g, '\n\n'));
  for (const w of (r.warnings || [])) L.push('\n> ⚠ ' + w);
  return L.join('\n');
}
