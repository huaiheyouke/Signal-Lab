// 应用入口：注册全部组件并挂载
import App from './components/App.js';
import InputPanel from './components/InputPanel.js';
import PlotTabs from './components/PlotTabs.js';
import TimePlot from './components/TimePlot.js';
import SpectrumPlots from './components/SpectrumPlots.js';
import TrajectoryPlot from './components/TrajectoryPlot.js';
import ReportPanel from './components/ReportPanel.js';

// 离线依赖缺失时的引导提示（正常情况下不会出现）
const missing = [];
if (typeof window.Vue === 'undefined') missing.push('Vue (vue.global.prod.js)');
if (typeof window.Plotly === 'undefined') missing.push('Plotly (plotly.min.js)');

if (missing.length) {
  document.getElementById('app').innerHTML =
    '<div class="fatal">前端离线依赖库缺失：' + missing.join('、') +
    '。<br/>请先运行 <code>python scripts/fetch_frontend_libs.py</code>（需联网一次），' +
    '然后刷新本页面。</div>';
} else {
  const app = Vue.createApp(App);
  app.component('input-panel', InputPanel);
  app.component('plot-tabs', PlotTabs);
  app.component('time-plot', TimePlot);
  app.component('spectrum-plots', SpectrumPlots);
  app.component('trajectory-plot', TrajectoryPlot);
  app.component('report-panel', ReportPanel);
  app.mount('#app');
}
