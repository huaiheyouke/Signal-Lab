// Tab4 视图：矩阵数值结果 + 热力图/特征值/3D 向量
import { bus } from '../bus.js';

export default {
  computed: {
    res() { return bus.moduleResult.matrix || null; },
    mi() { return this.res ? this.res.matrix_info : null; },
  },
  template: `
  <div class="chain-views">
    <div v-if="mi" class="info-box matrix-stats">
      <span>形状 {{ mi.shape[0] }}×{{ mi.shape[1] }}</span>
      <span>秩 = {{ mi.rank }}</span>
      <span>行列式 = {{ mi.determinant === null ? '—（非方阵）' : mi.determinant.toExponential(3) }}</span>
      <span>条件数 = {{ mi.condition_number === null ? '—' : mi.condition_number.toExponential(3) }}</span>
      <span v-if="mi.condition_number !== null && mi.condition_number > 1e6" class="warn-text">⚠ 接近奇异</span>
      <div v-if="mi.applied_note" class="muted">{{ mi.applied_note }}</div>
    </div>
    <div v-else class="placeholder"><p>在左侧输入矩阵（或从多径信道导入 H），点击「执行矩阵分析」。</p></div>
    <matrix-visuals v-if="res" :heatmap="res.visuals.heatmap" :eig="res.visuals.eig_spectrum" :vec3d="res.visuals.vec3d"></matrix-visuals>
    <bus-monitor></bus-monitor>
  </div>
  `,
};
