// 总线监视器：复用全部原有绘图组件展示当前总线信号
// （时域+谐波叠加 / 幅度·相位·PSD / 三维轨迹），任何模块处理完自动刷新。
import { bus } from '../bus.js';
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  data() { return { bus, collapsed: false }; },  // bus 挂到实例供模板使用
  computed: {
    hasAnalysis() { return !!bus.analysis; },
  },
  methods: {
    fmt(x) {
      if (x == null || !isFinite(x)) return '—';
      return parseFloat(x.toPrecision(5)).toString();
    },
  },
  template: `
  <div class="bus-monitor">
    <div class="monitor-head" @click="collapsed = !collapsed">
      <span>📡 总线信号监视器（{{ bus.sourceLabel }}）</span>
      <span class="monitor-sub" v-if="bus.analysis">
        {{ bus.analysis.signal_type === 'complex' ? '复信号' : '实信号' }} ·
        {{ bus.analysis.periodicity === 'periodic' ? '周期 T=' + fmt(bus.analysis.period) + 's · f₀=' + fmt(bus.analysis.fundamental_frequency) + 'Hz' : bus.analysis.periodicity === 'constant' ? '常数信号' : '非周期信号' }}
      </span>
      <span class="monitor-toggle">{{ collapsed ? '▶ 展开' : '▼ 折叠' }}</span>
    </div>
    <div v-if="!collapsed" class="monitor-body">
      <div class="monitor-row">
        <time-plot :result="bus.analysis"></time-plot>
      </div>
      <div class="monitor-row">
        <spectrum-plots :result="bus.analysis"></spectrum-plots>
      </div>
      <div class="monitor-row">
        <trajectory-plot :result="bus.analysis"></trajectory-plot>
      </div>
    </div>
  </div>
  `,
};
