"""预处理模块：噪声与滤波。

子模块一：加性高斯白噪声（AWGN）
输入：总线信号 + SNR(dB)。
运算逻辑：按信号平均功率 P 计算噪声功率 P/10^(SNR/10)，
生成复高斯白噪声叠加（实信号时虚部噪声保持为 0，避免破坏实信号性）。
输出对象：加噪后的复信号。

子模块二：数字滤波器
输入：总线信号 + 滤波器参数（类型/阶数/FIR·IIR/截止频率）。
运算逻辑：scipy.signal 设计滤波器（IIR 用 butter+sosfilt 保证数值稳定，
FIR 用 firwin+ lfilter），并对信号滤波（零相位可选，默认 forward 滤波）。
输出对象：滤波后的复信号 + 滤波器幅频响应曲线（visuals.freq_response）。
"""
from __future__ import annotations

import numpy as np
from scipy import signal as sps

from ..errors import AnalysisError
from . import CHAIN_MAX_POINTS

FILTER_TYPES = ("lowpass", "highpass", "bandpass", "bandstop")


def add_awgn(signal: dict, snr_db: float) -> dict:
    """向信号叠加指定信噪比的复高斯白噪声。"""
    s = _to_complex(signal)
    snr_db = float(snr_db)
    if not np.isfinite(snr_db):
        raise AnalysisError("SNR 必须为有限数值（dB）", ["输入 0~60 之间的数值"], "bad_snr")
    power = float(np.mean(np.abs(s) ** 2))
    noise_power = power / (10.0 ** (snr_db / 10.0))
    rng = np.random.default_rng(0)
    noise = rng.normal(0.0, np.sqrt(noise_power / 2.0), s.shape)         + 1j * rng.normal(0.0, np.sqrt(noise_power / 2.0), s.shape)
    is_real = not np.any(np.imag(s) != 0)
    if is_real:
        noise = noise.real                     # 实信号保持实信号
    y = s + noise
    return _pack(signal, y, info={"snr_db": snr_db, "noise_power": float(noise_power)})


def design_filter_response(filter_type: str, kind: str, order: int,
                           cutoff1: float, cutoff2: float, fs: float) -> tuple:
    """设计数字滤波器，返回 (sos 或 (b,a), freqz 数据)。

    IIR：butterworth + sos（级联二阶节，数值稳定）；
    FIR：firwin 窗函数法（默认 hamming 窗）。
    """
    if filter_type not in FILTER_TYPES:
        raise AnalysisError(f"未知滤波器类型：{filter_type}",
                            [f"可选：{'/'.join(FILTER_TYPES)}"], "bad_filter_type")
    if kind not in ("iir", "fir"):
        raise AnalysisError("滤波器实现方式必须为 iir 或 fir", [], "bad_filter_kind")
    order = int(order)
    if not (1 <= order <= 64):
        raise AnalysisError("滤波器阶数必须在 1~64 之间", [], "bad_filter_order")
    nyq = fs / 2.0
    if cutoff1 is None or not (0.0 < cutoff1 < nyq):
        raise AnalysisError(f"截止频率必须满足 0 < f < fs/2 = {nyq:g} Hz",
                            ["请检查截止频率与采样率"], "bad_cutoff")
    if filter_type in ("bandpass", "bandstop"):
        if cutoff2 is None or not (cutoff1 < cutoff2 < nyq):
            raise AnalysisError(f"带通/带阻需要 f1 < f2 < fs/2 = {nyq:g} Hz",
                                ["请检查两个截止频率"], "bad_cutoff")
        Wn = [cutoff1 / nyq, cutoff2 / nyq]
    else:
        Wn = cutoff1 / nyq

    if kind == "iir":
        # 注意：Wn 为归一化频率（0~1），不能同时传 fs（否则会被当作物理 Hz）
        sos = sps.butter(order, Wn, btype=filter_type, output="sos")
        filt = ("sos", sos)
    else:
        numtaps = order if order % 2 == 1 else order + 1   # FIR 抽头数（奇数保证线性相位）
        b = sps.firwin(numtaps, Wn, window="hamming", pass_zero=(filter_type != "highpass"))
        filt = ("ba", (b, [1.0]))
    # 幅频响应（前端绘制滤波特性曲线）
    if filt[0] == "sos":
        w, h = sps.sosfreqz(filt[1], worN=2048, fs=fs)
    else:
        w, h = sps.freqz(filt[1][0], filt[1][1], worN=2048, fs=fs)
    return filt, {"frequency": [float(x) for x in w], "magnitude": [float(abs(x)) for x in h]}


def apply_filter(signal: dict, filter_type: str, kind: str, order: int,
                 cutoff1: float, cutoff2: float) -> dict:
    """对总线信号执行数字滤波。"""
    s = _to_complex(signal)
    fs = float(signal["sampling_rate"])
    filt, freq_resp = design_filter_response(filter_type, kind, order, cutoff1, cutoff2, fs)
    if filt[0] == "sos":
        # 零相位滤波（filtfilt）：不引入群时延，瞬态更短，适合教学对比"滤波前后"
        try:
            y = sps.sosfiltfilt(filt[1], s)
            zero_phase = True
        except ValueError:
            # 信号过短（filtfilt 要求 len(x) > padlen）时回退因果滤波
            y = sps.sosfilt(filt[1], s)
            zero_phase = False
    else:
        b, a = filt[1]
        try:
            y = sps.filtfilt(b, a, s)
            zero_phase = True
        except ValueError:
            y = sps.lfilter(b, a, s)
            zero_phase = False
    info = {"filter_type": filter_type, "kind": kind.upper(), "order": order,
            "cutoff1": float(cutoff1), "cutoff2": float(cutoff2) if cutoff2 else None,
            "zero_phase": zero_phase}
    return _pack(signal, y, info=info, visuals={"freq_response": freq_resp})


def _to_complex(signal: dict) -> np.ndarray:
    n = len(signal["t"])
    if n < 4 or n > CHAIN_MAX_POINTS:
        raise AnalysisError(f"链路模式信号点数必须为 4 ~ {CHAIN_MAX_POINTS:,}（当前 {n}）",
                            ["请减小时间窗口或降低采样率"], "bad_chain_signal")
    return np.asarray(signal["re"], dtype=float) + 1j * np.asarray(signal["im"], dtype=float)


def _pack(signal: dict, y: np.ndarray, info: dict, visuals: dict | None = None) -> dict:
    """按统一格式打包输出信号。"""
    t = np.asarray(signal["t"], dtype=float)
    fs = float(signal["sampling_rate"])
    out = {
        "signal": {
            "t": [float(x) for x in t],
            "re": [float(x) for x in np.real(y)],
            "im": [float(x) for x in np.imag(y)],
            "sampling_rate": fs,
            "t_start": float(t[0]),
            "t_end": float(t[-1]),
            "n_points": int(len(t)),
        },
        "info": info,
    }
    if visuals:
        out["visuals"] = visuals
    return out
