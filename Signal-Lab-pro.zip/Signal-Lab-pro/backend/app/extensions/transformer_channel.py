"""【预留】Transformer 等效信道扩展骨架。

背景：通信课程中常把线性时不变信道 + 均衡器建模为"Transformer 等效信道"
（频域乘法 / 冲激响应卷积）。本模块预留以下接口：

    1. 在 on_signal_parsed 阶段对符号表达式做频域变换（符号级）；
    2. 在 on_spectrum 阶段对数值频谱施加信道频率响应 H(f)；
    3. 输出 ctx["extras"]["transformer_channel"]，前端渲染信道幅频/相频特性。

实现时建议：
    class TransformerChannelExtension(AnalysisExtension):
        name = "transformer_channel"
        def on_spectrum(self, ctx):
            h = compute_channel_response(ctx["spectrum"]["frequency"])
            ctx["extras"]["transformer_channel"] = {...}
"""
from __future__ import annotations

from .base import AnalysisExtension


class TransformerChannelExtension(AnalysisExtension):
    """Transformer 等效信道（骨架，待实现）。"""

    name = "transformer_channel"
    description = "Transformer 等效信道（预留骨架）"

    def on_spectrum(self, ctx: dict) -> None:
        # TODO: 对 ctx["spectrum"] 的频率轴施加信道频率响应 H(f)
        pass
