"""统一错误类型。

所有分析错误一律抛 AnalysisError，由 main.py 统一转换为
HTTP 422 + {code, error, suggestions} 结构返回前端；
前端据此展示「错误信息 + 修改建议」。
"""
from __future__ import annotations


class AnalysisError(Exception):
    """携带用户友好信息与修改建议的分析错误。"""

    def __init__(self, message: str, suggestions: list[str] | None = None,
                 code: str = "analysis_error"):
        super().__init__(message)
        self.message = message
        self.suggestions = suggestions or []
        self.code = code

    def to_dict(self) -> dict:
        return {"code": self.code, "error": self.message, "suggestions": self.suggestions}
