// 星座图组件：I-Q 平面散点
// 理想星座点（星形）+ 当前总线信号散点云（可观察噪声弥散 / 频偏旋转 / 信道畸变）
import { bus } from '../bus.js';
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  data() { return { bus }; },  // ★ watch: { bus: ... } 需要实例属性 bus
  mounted() { this.render(); },
  watch: {
    bus: { deep: true, handler() { this.render(); } },
  },
  beforeUnmount() { if (this.$refs.el) Plotly.purge(this.$refs.el); },
  computed: {
    ideal() { return (bus.moduleResult.mod && bus.moduleResult.mod.visuals) ? bus.moduleResult.mod.visuals.constellation_ideal : null; },
  },
  methods: {
    render() {
      const traces = [];
      if (this.ideal && this.ideal.length) {
        traces.push({
          x: this.ideal.map(p => p.i), y: this.ideal.map(p => p.q),
          mode: 'markers', name: '理想星座点',
          marker: { symbol: 'star', size: 14, color: '#f59e0b', line: { color: '#92400e', width: 1 } },
          hovertemplate: 'I=%{x:.4g}<br>Q=%{y:.4g}<extra>理想星座</extra>',
        });
      }
      if (bus.signal) {
        const n = bus.signal.t.length;
        const s = Math.max(1, Math.floor(n / 6000));
        const X = [], Y = [];
        for (let i = 0; i < n; i += s) { X.push(bus.signal.real[i]); Y.push(bus.signal.imag[i]); }
        traces.push({
          x: X, y: Y, mode: 'markers', name: '总线信号采样点',
          marker: { size: 3.5, color: 'rgba(37,99,235,0.55)' },
          hovertemplate: 'I=%{x:.4g}<br>Q=%{y:.4g}<extra>总线信号</extra>',
        });
      }
      const layout = {
        title: '星座图（I-Q 平面）',
        xaxis: { title: 'I = Re[s(t)]', gridcolor: '#e5e7eb', zeroline: true, zerolinecolor: '#94a3b8' },
        yaxis: { title: 'Q = Im[s(t)]', gridcolor: '#e5e7eb', zeroline: true, zerolinecolor: '#94a3b8', scaleanchor: 'x', scaleratio: 1 },
        margin: { t: 44, l: 56, r: 16, b: 46 },
        paper_bgcolor: '#fff', plot_bgcolor: '#fff',
        legend: { orientation: 'h', y: 1.12, font: { size: 11 } },
      };
      Plotly.react(this.$refs.el, traces, layout, PLOTLY_CONFIG);
    },
  },
  template: `
  <float-card title="星座图（I-Q 平面）" export-name="constellation.png"
    help="I-Q 平面散点图：黄色星形为理想星座点，蓝色散点为全局总线信号采样点。
用于观察调制信号的星座结构，以及噪声（散点弥散）、频偏/多径信道（整体旋转与畸变）对星座的影响。">
    <div ref="el" class="plot"></div>
  </float-card>
  `,
};
