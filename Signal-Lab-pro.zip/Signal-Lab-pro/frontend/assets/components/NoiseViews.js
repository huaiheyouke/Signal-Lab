// Tab1 视图：滤波器幅频响应（可选）+ 总线信号监视器
import { bus } from '../bus.js';
import { PLOTLY_CONFIG } from '../utils.js';

export default {
  data() { return { bus }; },  // ★ watch 'bus.moduleResult.filter' 需要实例属性 bus
  mounted() { this.renderFilter(); },
  watch: {
    'bus.moduleResult.filter': { deep: true, handler() { this.renderFilter(); } },
  },
  beforeUnmount() { if (this.$refs.fresp) Plotly.purge(this.$refs.fresp); },
  computed: {
    filterResp() { return (bus.moduleResult.filter && bus.moduleResult.filter.visuals) ? bus.moduleResult.filter.visuals.freq_response : null; },
  },
  methods: {
    renderFilter() {
      if (!this.filterResp || !this.$refs.fresp) return;
      const fr = this.filterResp;
      Plotly.react(this.$refs.fresp, [{
        x: fr.frequency, y: fr.magnitude, type: 'scatter', mode: 'lines',
        line: { color: '#2563eb', width: 2 },
        hovertemplate: 'f=%{x:.4g} Hz<br>|H(f)|=%{y:.4g}<extra></extra>',
      }], {
        title: '滤波器幅频响应 |H(f)|（最近一次滤波）',
        xaxis: { title: '频率 (Hz)' }, yaxis: { title: '|H(f)|', range: [0, 1.1] },
        margin: { t: 44, l: 56, r: 16, b: 46 },
        paper_bgcolor: '#fff', plot_bgcolor: '#fff',
      }, PLOTLY_CONFIG);
    },
  },
  template: `
  <div class="chain-views">
    <float-card v-if="filterResp" title="滤波器幅频响应 |H(f)|" export-name="filter_response.png"
      help="最近一次数字滤波器的幅频响应。通带内 |H(f)|≈1（信号保留），阻带内 ≈0（信号被抑制）。用于核对滤波参数的设置效果。">
      <div ref="fresp" class="plot"></div>
    </float-card>
    <bus-monitor></bus-monitor>
  </div>
  `,
};
